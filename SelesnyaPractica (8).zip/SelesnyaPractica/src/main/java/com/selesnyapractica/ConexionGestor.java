package com.selesnyapractica;

import java.io.File;
import java.sql.SQLSyntaxErrorException;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class ConexionGestor {

    //Variables
    CargarRutas cr = new CargarRutas();
    ConexionMySQL cone = new ConexionMySQL();
	ConexionSqlite cone2 = new ConexionSqlite();

    String red = "\033[31m";
    String reset = "\u001B[0m";
    String cyan = "\033[36m";
    String gestor = "";
    boolean errorConexion = false;

    public Connection conexion() {
        cr.cargarRutas();
        gestor = (cr.getGestor()).toLowerCase();
        this.limpiarConsola();


        Connection conexionGestor = null;
        this.limpiarConsola();

        try {
            if (gestor.contains("mysql")) {
                System.out.println(cyan + "Conectando con base de datos de MYSQL...\n" + reset);
                //this.esperar();
                conexionGestor = cone.conexion();

							/*
							Si en el método conexion de la clase ConexionMySQL sale una excepcion, cambiará
							el valor del boolean "ErrorSQL" (Que está en esa clase) a true. Luego con un get
							obtenemos que valor tiene ese boolean. Si es true significa que ocurrió una excepcion,
							por lo tanto arrojaremos manualmente una nueva excepcion para que en el catch
							intente conectar con SQLite
							*/
                errorConexion = cone.getErrorSQL();

                if (errorConexion == true) {
                    conexionGestor = null;
                    throw new Exception("");
                }
            } else {
							/*
							Si gestor no es igual a mysql, entonces puede ser PostgreSQL o SQLite.
							En este caso no creo que agreguemos la de PostgreSQL, entonces si el gestor que
							se ingresó en el archivo de configuracion no es mysql, directamente conectará
							con sqlite. Para ahorrar código, arrojé una excepcion para que ejecute lo del catch
							(Que es básicamente conectarse a SQLite).
							*/
                throw new Exception("");
            }
        } catch (Exception e) {
            try {
                System.out.println(cyan + "\nConectando con base de datos de SQLite...\n" + reset);
							/*
							Ejemplo de como sería el código de conexion a SQLite
							(Se hará lo mismo que con lo de MySQL, pero en este caso si sale una excepcion,
							será error fatal y se terminará el programa)
							*/

                //coneSQLite.conexion();
                //errorConexion=coneSQLite.getErrorSQLite();
				conexionGestor=cone2.eseculai();
				errorConexion=cone2.getErrorConexion();
				
                if (errorConexion == true) {
                    throw new Exception("");
                }
            } catch (Exception f) {
                System.out.println(red + "\n[Error fatal] " + reset + "No se pudo conectar con un gestor de BD");
                System.exit(-2);
            }
        } finally {
            return conexionGestor;
        }
    }

    //Extras
    public void limpiarConsola() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception e) {
        }

    }

    public void esperar() {
        try {
            Thread.sleep(5 * 1000);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}