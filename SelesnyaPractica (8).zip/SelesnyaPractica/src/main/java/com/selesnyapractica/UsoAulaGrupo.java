package com.selesnyapractica;

public class UsoAulaGrupo {

    private String dia;
    private String espacioTiempo;
    private String idAula;
    private String clvGrupo;
    private String clvMateria;

    public UsoAulaGrupo(String dia, String espacioTiempo, String idAula, String clvGrupo, String clvMateria) {
        this.dia = dia;
        this.espacioTiempo = espacioTiempo;
        this.idAula = idAula;
        this.clvGrupo = clvGrupo;
        this.clvMateria = clvMateria;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getEspacioTiempo() {
        return espacioTiempo;
    }

    public void setEspacioTiempo(String espacioTiempo) {
        this.espacioTiempo = espacioTiempo;
    }

    public String getIdAula() {
        return idAula;
    }

    public void setIdAula(String idAula) {
        this.idAula = idAula;
    }

    public String getClvGrupo() {
        return clvGrupo;
    }

    public void setClvGrupo(String clvGrupo) {
        this.clvGrupo = clvGrupo;
    }

    public String getClvMateria() {
        return clvMateria;
    }

    public void setClvMateria(String clvMateria) {
        this.clvMateria = clvMateria;
    }
}
