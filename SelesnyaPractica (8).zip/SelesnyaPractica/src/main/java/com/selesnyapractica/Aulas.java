package com.selesnyapractica;

public class Aulas {
    private String idAula;
    private String nombre;
    private String tipo;
    private String capacidad;

    public Aulas(String idAula, String nombre, String tipo, String capacidad) {
        this.idAula = idAula;
        this.nombre = nombre;
        this.tipo = tipo;
        this.capacidad = capacidad;
    }

    public String getIdAula() {
        return idAula;
    }

    public void setIAula(String id_aula) {
        this.idAula = id_aula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(String capacidad) {
        this.capacidad = capacidad;
    }
}
