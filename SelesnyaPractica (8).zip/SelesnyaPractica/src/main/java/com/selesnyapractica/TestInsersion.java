package com.selesnyapractica;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class TestInsersion {

    //Para colores en consola
    private String red = "\033[31m";
    private String green = "\033[32m";
    private String yellow = "\033[33m";
    private String reset = "\u001B[0m";
    private String cyan = "\033[36m";
	private String purple="\033[35m";
	
    //Extras
    public void limpiarConsola() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception e) {
        }

    }

    public void esperar() {
        try {
            Thread.sleep(5 * 1000);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
	
	//Test
	
	public void insertarEnMateriaUsuario(Connection conect){
		String claveMateriaAIngresar="";
		String clavePlanAIngresar="";
		String claveUsuarioAIngresar="";
		String puntosConfianza="";
		String puntosDirector="";
		
		System.out.println("--------------------- TEST INGRESANDO EN MATERIA USUARIO ---------------------");
		Scanner entrada = new Scanner(System.in);
		//Intresar a la tabla materia_usuario
		boolean existe=false;
		try{
			existe=false;
			while(existe==false){ //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
				System.out.println(purple+"Ingrese clv_materia"+reset);
				claveMateriaAIngresar = entrada.nextLine();
				existe=compararSiExisteEseDato(conect, "materias", claveMateriaAIngresar, 2);
				
				if(existe==false){
					System.out.println(yellow + "\n[Advertencia] " + reset + "El valor "+cyan+claveMateriaAIngresar+reset+" NO existe en la BD. Compruebe sus registro.\n");
				}
			}
			
			existe=false;
			System.out.println("");
			while(existe==false){ //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido
				System.out.println(purple+"Ingrese clv_plan"+reset);
				clavePlanAIngresar = entrada.nextLine();
				existe=compararSiExisteEseDato(conect, "plan_estudios", clavePlanAIngresar, 1);
				
				if(existe==false){
					System.out.println(yellow + "\n[Advertencia] " + reset + "El valor "+cyan+clavePlanAIngresar+reset+" NO existe en la BD. Compruebe sus registro.\n");
				}
			}
			
			existe=false;
			System.out.println("");
			while(existe==false){ //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido
				System.out.println(purple+"Ingrese clv_usuario"+reset);
				claveUsuarioAIngresar = entrada.nextLine();
				existe=compararSiExisteEseDato(conect, "usuarios", claveUsuarioAIngresar, 1);
				
				if(existe==false){
					System.out.println(yellow + "\n[Advertencia] " + reset + "El valor "+cyan+claveUsuarioAIngresar+reset+" NO existe en la BD. Compruebe sus registro.\n");
				}
			}
			
			System.out.println("");
			System.out.println(purple+"Ingrese puntos de confianza"+reset);
			puntosConfianza = entrada.nextLine();
			
			System.out.println("");
			System.out.println(purple+"Ingrese puntos de director"+reset);
			puntosDirector = entrada.nextLine();
			
			//Aqui manda el conect y los datos que iran en cada una de las columnas
			this.insertarEnMateriaUsuarioConDatos(conect, claveMateriaAIngresar, clavePlanAIngresar, claveUsuarioAIngresar, puntosConfianza, puntosDirector);
		}catch(Exception e){
			System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
		}
		
	}
	
	/*
	Este metodo recibe como parametros el conect y cada uno de los datos que se insertaran en las columnas, de esta forma
	podemos utilizar este mismo método para insertar datos desde el crud, desde un excel y desde un txt.
	*/
	public void insertarEnMateriaUsuarioConDatos(Connection conect, String claveMateriaAIngresar, String clavePlanAIngresar, String claveUsuarioAIngresar, String puntosConfianza, String puntosDirector){
		String insersion="";
		boolean registroExistente=false;
		Statement s = null;
		
		try {
			
			//Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
			if(this.compararSiExisteEseDato(conect, "materias", claveMateriaAIngresar, 2)==true){
				if(this.compararSiExisteEseDato(conect, "plan_estudios", clavePlanAIngresar, 1)==true){
					if(this.compararSiExisteEseDato(conect, "usuarios", claveUsuarioAIngresar, 1)==true){
						s = conect.createStatement();
						//s.execute("use selesnyadb");
						ResultSet rs = s.executeQuery("select clv_materia, clv_plan, clv_usuario from materia_usuario");
						while (!String.valueOf(rs.next()).equals("false")) {
							
							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
							if(rs.getString(1).equals(claveMateriaAIngresar) && rs.getString(2).equals(clavePlanAIngresar) && rs.getString(3).equals(claveUsuarioAIngresar)){
								System.out.println(yellow+"[Advertencia] "+reset+"Un registro ingresado ya existe en la tabla");
								registroExistente=true;
							}
						}
						if(registroExistente==false){
							insersion="INSERT INTO `materia_usuario` (`clv_materia`, `clv_plan`, `clv_usuario`, `puntos_confianza`, `puntos_director`) VALUES ('"+claveMateriaAIngresar+"', '"+clavePlanAIngresar+"', '"+claveUsuarioAIngresar+"', '"+puntosConfianza+"', '"+puntosDirector+"');";
							s.execute(insersion);
							System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

						}
					} else {
						if(!claveUsuarioAIngresar.equals("")){
							System.out.println(yellow + "\n[Advertencia] " + reset + "El valor "+cyan+claveUsuarioAIngresar+reset+" NO existe en la BD. Compruebe sus registro.\n");
						}
					}
				} else {
					if(!clavePlanAIngresar.equals("")){
						System.out.println(yellow + "\n[Advertencia] " + reset + "El valor "+cyan+clavePlanAIngresar+reset+" NO existe en la BD. Compruebe sus registro.\n");

					}
				}
			} else {
				if(!claveMateriaAIngresar.equals("")){
					System.out.println(yellow + "\n[Advertencia] " + reset + "El valor "+cyan+claveMateriaAIngresar+reset+" NO existe en la BD. Compruebe sus registro.\n");
				}
			}

		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}

	}
	
	public boolean compararSiExisteEseDato(Connection conect, String tablaEnLaQueSeVaAComparar, String id_valorIngresado, int posicionColumnaEnLaQueSeInsertara) {
		boolean existeValorEnBD=false;
        try {
			
            Statement s = conect.createStatement();
			//s.execute("use selesnyadb");
            ResultSet rs = s.executeQuery("select * from "+tablaEnLaQueSeVaAComparar);
			
            while (!String.valueOf(rs.next()).equals("false")) {
				if(rs.getString(posicionColumnaEnLaQueSeInsertara).equals(id_valorIngresado)){
						existeValorEnBD=true;
				}
            }
			
        } catch (Exception e) {
			System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion: " + e);
        }
		return existeValorEnBD; //Retorna el boolean de si encontró coincidencia o no.
    }
}