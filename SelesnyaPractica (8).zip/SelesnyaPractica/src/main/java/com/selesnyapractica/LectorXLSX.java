package com.selesnyapractica;

import java.sql.SQLException;
import org.apache.poi.xssf.usermodel.XSSFRow;
import java.sql.Connection;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import javax.swing.*;
import java.io.*;
import java.util.Iterator;

public class LectorXLSX {

    //Variables
	CRUD t = new CRUD();
    private String rutaExcelData;
	private String materiaUsuarioXLSX;
	private String aulasXLSX;
    private String aulas_equipoXLSX;
    private String carreraXLSX;
    private String categorias_equipoXLSX;
    private String disponibilidadXLSX;
    private String equipoXLSX;
    private String grupo_materia_profesorXLSX;
    private String gruposXLSX;
    private String loginXLSX;
    private String materiasXLSX;
    private String plan_estudiosXLSX;
    private String uso_aula_grupoXLSX;
    private String usuariosXLSX;
    //Para colores en consola
    private String red="\033[31m";
    private String green="\033[32m";
    private String yellow="\033[33m";
    private String reset="\u001B[0m";
    private String cyan="\033[36m";

	public void insertarMateriaUsuario(Connection conec) {
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            this.materiaUsuarioXLSX=cr.getMateriaUsuarioXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(materiaUsuarioXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 5;
            String arrayMateriaUsuario[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayMateriaUsuario[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
						if(!arrayMateriaUsuario[0][0].equals("clv_materia")||!arrayMateriaUsuario[0][1].equals("clv_plan")||!arrayMateriaUsuario[0][2].equals("clv_usuario")||!arrayMateriaUsuario[0][3].equals("puntos_confianza")||!arrayMateriaUsuario[0][4].equals("puntos_director")||rows<=1){
							System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
							throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");

						}
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayMateriaUsuario[k][l]=this.arreglarFormato(arrayMateriaUsuario[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
				t.insertarEnMateriaUsuarioConDatos(conec,arrayMateriaUsuario[i][0],arrayMateriaUsuario[i][1],arrayMateriaUsuario[i][2],arrayMateriaUsuario[i][3],arrayMateriaUsuario[i][4]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }


    }
		
	public void insertarAulas(Connection conec){
        int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            aulasXLSX=cr.getAulasXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(aulasXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 4;
            String arrayAulas[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayAulas[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
						if(!arrayAulas[0][0].equals("id_aula")||!arrayAulas[0][1].equals("nombre")||!arrayAulas[0][2].equals("tipo")||!arrayAulas[0][3].equals("capacidad")||rows==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                        }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayAulas[k][l]=this.arreglarFormato(arrayAulas[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
				
                t.insertarEnAulasConDatos(conec,String.valueOf(Integer.parseInt(arrayAulas[i][0])),arrayAulas[i][1],arrayAulas[i][2],arrayAulas[i][3]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
			//JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
		}catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }

    }
   
	public void insertarAulasEquipo(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            aulas_equipoXLSX=cr.getAulas_equipoXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(aulas_equipoXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 3;
            String arrayAulasEquipo[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayAulasEquipo[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
						if(!arrayAulasEquipo[0][0].equals("id_equipo")||!arrayAulasEquipo[0][1].equals("id_aula")||!arrayAulasEquipo[0][2].equals("capacidad")||rows==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                        }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayAulasEquipo[k][l]=this.arreglarFormato(arrayAulasEquipo[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnAulaEquipoConDatos(conec,arrayAulasEquipo[i][0],arrayAulasEquipo[i][1],arrayAulasEquipo[i][2]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
	
    }
	
	public void insertarCarrera(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            carreraXLSX=cr.getCarreraXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(carreraXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 2;
            String arrayCarrera[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayCarrera[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
						if(!arrayCarrera[0][0].equals("idcarrera")||!arrayCarrera[0][1].equals("nombre_carrera")||rows==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                        }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayCarrera[k][l]=this.arreglarFormato(arrayCarrera[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnCarreraConDatos(conec,arrayCarrera[i][0],arrayCarrera[i][1]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		
    }
	
	public void insertarCategoriasEquipo(Connection conec){
		
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            categorias_equipoXLSX=cr.getCategorias_equipoXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(categorias_equipoXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 3;
            String arrayCategoriasEquipo[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayCategoriasEquipo[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
						if(!arrayCategoriasEquipo[0][0].equals("id_categoria")||!arrayCategoriasEquipo[0][1].equals("nombre_categoria")||!arrayCategoriasEquipo[0][2].equals("descripcion_categoria")||rows==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                        }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayCategoriasEquipo[k][l]=this.arreglarFormato(arrayCategoriasEquipo[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnCategoriasEquipoConDatos(conec,arrayCategoriasEquipo[i][0],arrayCategoriasEquipo[i][1],arrayCategoriasEquipo[i][2]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
    }
	
	public void insertarGrupoMateriaProfesor(Connection conec){
        int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            grupo_materia_profesorXLSX=cr.getGrupo_materia_profesorXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(grupo_materia_profesorXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 3;
            String arrayGrupoMateriaProfesor[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayGrupoMateriaProfesor[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
						if(!arrayGrupoMateriaProfesor[0][0].equals("clv_grupo")||!arrayGrupoMateriaProfesor[0][1].equals("clv_materia")||!arrayGrupoMateriaProfesor[0][2].equals("clv_usuario")||rows==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                        }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayGrupoMateriaProfesor[k][l]=this.arreglarFormato(arrayGrupoMateriaProfesor[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnGrupoMateriaProfesorConDatos(conec,arrayGrupoMateriaProfesor[i][0],arrayGrupoMateriaProfesor[i][1],arrayGrupoMateriaProfesor[i][2]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
    }
	
	public void insertarGrupos(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            gruposXLSX=cr.getGruposXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(gruposXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 2;
            String arrayGrupos[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayGrupos[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
					if(!arrayGrupos[0][0].equals("clv_grupo")||!arrayGrupos[0][1].equals("turno")||rows==1){
                        System.out.println("\n");
                        JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                         throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                    }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayGrupos[k][l]=this.arreglarFormato(arrayGrupos[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnGruposConDatos(conec,arrayGrupos[i][0],arrayGrupos[i][1]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
    }
	
	public void insertarEquipo(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            equipoXLSX=cr.getEquipoXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(equipoXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 4;
            String arrayEquipo[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayEquipo[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
					if(!arrayEquipo[0][0].equals("id_equipo")||!arrayEquipo[0][1].equals("nombre")||!arrayEquipo[0][2].equals("descripcion")||!arrayEquipo[0][3].equals("id_categoria")||rows==1){
                        System.out.println("\n");
                        JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                        throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                    }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayEquipo[k][l]=this.arreglarFormato(arrayEquipo[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnEquipoConDatos(conec,arrayEquipo[i][0],arrayEquipo[i][1],arrayEquipo[i][2],arrayEquipo[i][3]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
    }
	
	public void insertarDisponibilidad(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            disponibilidadXLSX=cr.getDisponibilidadXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(disponibilidadXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 4;
            String arrayDisponibilidad[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayDisponibilidad[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
					if(!arrayDisponibilidad[0][0].equals("dia")||!arrayDisponibilidad[0][1].equals("espacio_tiempo")||!arrayDisponibilidad[0][2].equals("clv_usuario")||rows==1){
                        System.out.println("\n");
                        JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                        throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                    }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayDisponibilidad[k][l]=this.arreglarFormato(arrayDisponibilidad[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnDisponibilidadConDatos(conec,arrayDisponibilidad[i][0],arrayDisponibilidad[i][1],arrayDisponibilidad[i][2]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
    }
	
	public void insertarLogin(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            loginXLSX=cr.getLoginXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(loginXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 3;
            String arrayLogin[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayLogin[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
					if(!arrayLogin[0][0].equals("clv_usuario")||!arrayLogin[0][1].equals("pass_usuario")||!arrayLogin[0][2].equals("tipo_usuario")||rows==1){
                        System.out.println("\n");
                        JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                        throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                    }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayLogin[k][l]=this.arreglarFormato(arrayLogin[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnLoginConDatos(conec,arrayLogin[i][0],arrayLogin[i][1],arrayLogin[i][2]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
    }
	
	public void insertarMaterias(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            materiasXLSX=cr.getMateriasXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(materiasXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 8;
            String arrayMaterias[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayMaterias[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
					if(!arrayMaterias[0][0].equals("nombre_materia")||!arrayMaterias[0][1].equals("clv_materia")||!arrayMaterias[0][2].equals("creditos")||!arrayMaterias[0][3].equals("cuatrimestre")||!arrayMaterias[0][4].equals("posicion")||!arrayMaterias[0][5].equals("clv_plan")||!arrayMaterias[0][6].equals("horas_x_semana")||!arrayMaterias[0][7].equals("tipo_materia")||rows==1){
                        System.out.println("\n");
                        JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                        throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                    }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayMaterias[k][l]=this.arreglarFormato(arrayMaterias[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnMateriasConDatos(conec,arrayMaterias[i][0],arrayMaterias[i][1],arrayMaterias[i][2],arrayMaterias[i][3],arrayMaterias[i][4],arrayMaterias[i][5],arrayMaterias[i][6],arrayMaterias[i][7]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
    }
	
	public void insertarPlanEstudios(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            plan_estudiosXLSX=cr.getPlan_estudiosXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(plan_estudiosXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 4;
            String arrayPlanEstudios[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayPlanEstudios[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
					if(!arrayPlanEstudios[0][0].equals("clv_plan")||!arrayPlanEstudios[0][1].equals("nombre_plan")||!arrayPlanEstudios[0][2].equals("nivel")||!arrayPlanEstudios[0][3].equals("idcarrera")||rows==1){
                        System.out.println("\n");
                        JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                        throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                    }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayPlanEstudios[k][l]=this.arreglarFormato(arrayPlanEstudios[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnPlanEstudiosConDatos(conec,arrayPlanEstudios[i][0],arrayPlanEstudios[i][1],arrayPlanEstudios[i][2],arrayPlanEstudios[i][3]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
	}
	
	public void insertarUsoAulaGrupos(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            uso_aula_grupoXLSX=cr.getUso_aula_grupoXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(uso_aula_grupoXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 5;
            String arrayUsoAulaGrupo[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayUsoAulaGrupo[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
					if(!arrayUsoAulaGrupo[0][0].equals("dia")||!arrayUsoAulaGrupo[0][1].equals("espacio_tiempo")||!arrayUsoAulaGrupo[0][2].equals("id_aula")||!arrayUsoAulaGrupo[0][3].equals("clv_grupo")||!arrayUsoAulaGrupo[0][4].equals("clv_materia")||rows==1){
                        System.out.println("\n");
                        JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                        throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                    }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayUsoAulaGrupo[k][l]=this.arreglarFormato(arrayUsoAulaGrupo[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnUsoAulaGrupoConDatos(conec,arrayUsoAulaGrupo[i][0],arrayUsoAulaGrupo[i][1],arrayUsoAulaGrupo[i][2],arrayUsoAulaGrupo[i][3],arrayUsoAulaGrupo[i][4]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
	}
	
	public void insertarUsuarios(Connection conec){
		int i;
        try{
            
            CargarRutas cr = new CargarRutas();
            cr.cargarRutas();
            usuariosXLSX=cr.getUsuariosXLSX();

            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(usuariosXLSX));
            XSSFSheet sheet = wb.getSheetAt(0);

            int rows = sheet.getLastRowNum()+1;
            int numColumnas = 5;
            String arrayUsuarios[][] = new String[rows][numColumnas];

            for (i = 0; i < rows; ++i) {
                XSSFRow row = sheet.getRow(i);
                for(int j=0;j<numColumnas;j++){
                    arrayUsuarios[i][j]=String.valueOf(row.getCell(j));
					
                }
				//Verifica si el formato es correcto, comparando que los nombres de las columnas sean los esperados
				if(i==0){
					if(!arrayUsuarios[0][0].equals("clv_usuario")||!arrayUsuarios[0][1].equals("idcarrera")||!arrayUsuarios[0][2].equals("nombre_usuario")||!arrayUsuarios[0][3].equals("nivel_ads")||!arrayUsuarios[0][4].equals("contrato")||rows==1){
                        System.out.println("\n");
                        JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
                        throw new ExceptionFormatoXLSXNoValido("Formato XLSX incorrecto. Verifique el archivo.");
                    }
				}

            }
			for(int k=0;k<rows;k++){
				for (int l=0;l<numColumnas;l++){
					arrayUsuarios[k][l]=this.arreglarFormato(arrayUsuarios[k][l]);
				}
			}
			for(i=1;i<rows;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnUsuariosConDatos(conec,arrayUsuarios[i][0],arrayUsuarios[i][1],arrayUsuarios[i][2],arrayUsuarios[i][3],arrayUsuarios[i][4]);
            }
            
        }catch(FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo excel");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch(NumberFormatException e){
            //JOptionPane.showMessageDialog(null, "Formato XLSX incorrecto. Verifique el archivo.");
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error");
            System.out.println(red+"[Error] "+reset+e);
        }
		//<------------------------------------------------------------------
	}
	
	public String arreglarFormato(String valor){
		if(valor.indexOf(".0")!=-1){
			valor=valor.substring(0,valor.indexOf("."));
			//System.out.println(red+valor+reset);
		}
		return valor;
	}
}
