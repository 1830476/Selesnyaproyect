package com.selesnyapractica;

import java.sql.Connection;
import java.util.Scanner;

public class MenuTXTyXLSX {
    private String red = "\033[31m";
    private String green = "\033[32m";
    private String yellow = "\033[33m";
    private String reset = "\u001B[0m";
    private String cyan = "\033[36m";
    private String purple = "\033[35m";

    public void menuLectura(Connection conec, String seleccion) {
        Scanner entrada = new Scanner(System.in);
        LectorXLSX xlsx = new LectorXLSX();
        LectorTXT txt = new LectorTXT();
        String seleccion2;

        System.out.println(purple + "A que tabla desea insertar datos desde archivo." + reset);
        System.out.println(yellow+"1) materia_usuario\n2) aulas\n3) aula_equipo\n4) carrera\n5) categorias_equipo\n6) grupo_materia_profesor\n7) grupos\n8) equipo\n9) disponibilidad\n10) login\n11) materias\n12) plan_estudios\n13) uso_aula_grupos\n14) usuarios\n0) Salir"+reset);

        try {
            do {
                System.out.print("\n\n> ");
                seleccion2 = entrada.nextLine();
                switch (seleccion2) {
                    case "1":
                        if (seleccion.equals("2")) {
                            xlsx.insertarMateriaUsuario(conec);
                        } else {
                            txt.insertarMateriaUsuario(conec);
                        }
                        break;
                    case "2":
                        if (seleccion.equals("2")) {
                            xlsx.insertarAulas(conec);
                        } else {
                            txt.insertarAulas(conec);
                        }
                        break;
                    case "3":
                        if (seleccion.equals("2")) {
                          xlsx.insertarAulasEquipo(conec);
                        } else {
                            txt.insertarAulasEquipo(conec);
                        }
                        break;
                    case "4":
                        if (seleccion.equals("2")) {
                            xlsx.insertarCarrera(conec);
                        } else {
                            txt.insertarCarrera(conec);
                        }
                        break;
                    case "5":
                        if (seleccion.equals("2")) {
                            xlsx.insertarCategoriasEquipo(conec);
                        } else {
                            txt.insertarCategoriasEquipo(conec);
                        }
                        break;
                    case "6":
                        if (seleccion.equals("2")) {
                            xlsx.insertarGrupoMateriaProfesor(conec);
                        } else {
                            txt.insertarGrupoMateriaProfesor(conec);
                        }
                        break;
                    case "7":
                        if (seleccion.equals("2")) {
                            xlsx.insertarGrupos(conec);
                        } else {
                            txt.insertarGrupos(conec);
                        }
                        break;
                    case "8":
                        if (seleccion.equals("2")) {
                            xlsx.insertarEquipo(conec);
                        } else {
                            txt.insertarEquipo(conec);
                        }
                        break;
                    case "9":
                        if (seleccion.equals("2")) {
                            xlsx.insertarDisponibilidad(conec);
                        } else {
                            txt.insertarDisponibilidad(conec);
                        }
                        break;
                    case "10":
                        if (seleccion.equals("2")) {
                            xlsx.insertarLogin(conec);
                        } else {
                            txt.insertarLogin(conec);
                        }
                        break;
                    case "11":
                        if (seleccion.equals("2")) {
                            xlsx.insertarMaterias(conec);
                        } else {
                            txt.insertarMaterias(conec);
                        }
                        break;
                    case "12":
                        if (seleccion.equals("2")) {
                            xlsx.insertarPlanEstudios(conec);
                        } else {
                            txt.insertarPlanEstudios(conec);
                        }
                        break;
                    case "13":
                        if (seleccion.equals("2")) {
                            xlsx.insertarUsoAulaGrupos(conec);
                        } else {
                            txt.insertarUsoAulaGrupos(conec);
                        }
                        break;
                    case "14":
                        if (seleccion.equals("2")) {
                            xlsx.insertarUsuarios(conec);
                        } else {
                            txt.insertarUsuarios(conec);
                        }
                        break;
					case "0":
						System.out.println(cyan + "[Finalizando] " + reset + " Proceso terminado correctamente.");
						break;
                    default:
                        System.out.println(yellow + "[Advertencia] " + reset + " Valor no válido, ingrese nuevamente.");
                        break;
                }

            } while (Integer.parseInt(seleccion2) != 0);
			//while (Integer.parseInt(seleccion2) < 1 && Integer.parseInt(seleccion2) > 14)
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion: " + e);
        }

    }

    //Extras
    public void limpiarConsola() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception e) {
        }

    }
}
