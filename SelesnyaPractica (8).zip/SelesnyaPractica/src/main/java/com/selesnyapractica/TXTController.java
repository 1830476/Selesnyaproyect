package com.selesnyapractica;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import javax.swing.*;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class TXTController implements Initializable {

    LectorTXT txt = new LectorTXT();
    ConexionGestor cone = new ConexionGestor();

    @FXML
    Button btn_grupos_materia_profesor, btn_aulas, btn_carreras, btn_categorias_equipo, btn_disponibilidad, btn_equipo, btn_grupos;
    @FXML
    Button btn_login, btn_materia_usuario, btn_materias, btn_plan_estudios, btn_uso_aula_grupo, btn_usuarios;

    @FXML
    Button btn_aula_equipos;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void Open_aula_equipos(){
        txt.insertarAulasEquipo(cone.conexion());
    }

    public void Open_grupos_materia_profesor(){
        txt.insertarGrupoMateriaProfesor(cone.conexion());
    }

    public void Open_aulas(){
        txt.insertarAulas(cone.conexion());
    }

    public void Open_login(){
        txt.insertarLogin(cone.conexion());
    }

    public void Open_carreras(){
        txt.insertarCarrera(cone.conexion());
    }

    public void Open_materia_usuario(){
        txt.insertarMateriaUsuario(cone.conexion());
    }

    public void Open_categorias_equipo(){
        txt.insertarCategoriasEquipo(cone.conexion());
    }

    public void Open_materias(){
        txt.insertarMaterias(cone.conexion());
    }

    public void Open_disponibilidad(){
        txt.insertarDisponibilidad(cone.conexion());
    }

    public void Open_plan_estudios(){
        txt.insertarPlanEstudios(cone.conexion());
    }

    public void Open_equipo(){
        txt.insertarEquipo(cone.conexion());
    }

    public void Open_uso_aula_grupo(){
        txt.insertarUsoAulaGrupos(cone.conexion());
    }

    public void Open_grupos(){
        txt.insertarGrupos(cone.conexion());
    }

    public void Open_usuarios(){
        txt.insertarUsuarios(cone.conexion());
    }
}
