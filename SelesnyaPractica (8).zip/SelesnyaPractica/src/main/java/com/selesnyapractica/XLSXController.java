package com.selesnyapractica;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import java.net.URL;
import java.util.ResourceBundle;

public class XLSXController implements Initializable {

    LectorXLSX xlsx = new LectorXLSX();
    ConexionGestor cone = new ConexionGestor();

    @FXML
    Button btn_grupos_materia_profesor, btn_aulas, btn_carreras, btn_categorias_equipo, btn_disponibilidad, btn_equipo, btn_grupos;
    @FXML
    Button btn_login, btn_materia_usuario, btn_materias, btn_plan_estudios, btn_uso_aula_grupo, btn_usuarios;

    @FXML
    Button btn_aula_equipos;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void Open_aula_equipos(){
        xlsx.insertarAulasEquipo(cone.conexion());
    }

    public void Open_grupos_materia_profesor(){
        xlsx.insertarGrupoMateriaProfesor(cone.conexion());
    }

    public void Open_aulas(){
        xlsx.insertarAulas(cone.conexion());
    }

    public void Open_login(){
        xlsx.insertarLogin(cone.conexion());
    }

    public void Open_carreras(){
        xlsx.insertarCarrera(cone.conexion());
    }

    public void Open_materia_usuario(){
        xlsx.insertarMateriaUsuario(cone.conexion());
    }

    public void Open_categorias_equipo(){
        xlsx.insertarCategoriasEquipo(cone.conexion());
    }

    public void Open_materias(){
        xlsx.insertarMaterias(cone.conexion());
    }

    public void Open_disponibilidad(){
        xlsx.insertarDisponibilidad(cone.conexion());
    }

    public void Open_plan_estudios(){
        xlsx.insertarPlanEstudios(cone.conexion());
    }

    public void Open_equipo(){
        xlsx.insertarEquipo(cone.conexion());
    }

    public void Open_uso_aula_grupo(){
        xlsx.insertarUsoAulaGrupos(cone.conexion());
    }

    public void Open_grupos(){
        xlsx.insertarGrupos(cone.conexion());
    }

    public void Open_usuarios(){
        xlsx.insertarUsuarios(cone.conexion());
    }
}
