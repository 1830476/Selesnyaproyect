package com.selesnyapractica;

public class Grupos {

    private String clvGrupo;
    private String turno;

    public Grupos(String clvGrupo, String turno) {
        this.clvGrupo = clvGrupo;
        this.turno = turno;
    }

    public String getClvGrupo() {
        return clvGrupo;
    }

    public void setClvGrupo(String clvGrupo) {
        this.clvGrupo = clvGrupo;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }
}
