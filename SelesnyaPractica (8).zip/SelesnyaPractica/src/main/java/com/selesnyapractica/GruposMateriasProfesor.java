package com.selesnyapractica;

public class GruposMateriasProfesor {

    private String clvGrupo;
    private String clvMateria;
    private String clvUsuario;

    public GruposMateriasProfesor(String clvGrupo, String clvMateria, String clvUsuario) {
        this.clvGrupo = clvGrupo;
        this.clvMateria = clvMateria;
        this.clvUsuario = clvUsuario;
    }

    public String getClvGrupo() {
        return clvGrupo;
    }

    public void setClvGrupo(String clvGrupo) {
        this.clvGrupo = clvGrupo;
    }

    public String getClvMateria() {
        return clvMateria;
    }

    public void setClvMateria(String clvMateria) {
        this.clvMateria = clvMateria;
    }

    public String getClvUsuario() {
        return clvUsuario;
    }

    public void setClvUsuario(String clvUsuario) {
        this.clvUsuario = clvUsuario;
    }
}
