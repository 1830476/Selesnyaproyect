package com.selesnyapractica;

public class Constr_aula_equipos {

    private String Id_equipo;
    private String Id_aula;
    private String Cantidad;


    public Constr_aula_equipos(String id_equipo, String id_aula, String cantidad) {
        Id_equipo = id_equipo;
        Id_aula = id_aula;
        Cantidad = cantidad;
    }

    public String getId_equipo() {
        return Id_equipo;
    }

    public void setId_equipo(String id_equipo) {
        Id_equipo = id_equipo;
    }

    public String getId_aula() {
        return Id_aula;
    }

    public void setId_aula(String id_aula) {
        Id_aula = id_aula;
    }

    public String getCantidad() {
        return Cantidad;
    }

    public void setCantidad(String cantidad) {
        Cantidad = cantidad;
    }
}
