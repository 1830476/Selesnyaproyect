package com.selesnyapractica;

public class Login {

    private String clvUsuario;
    private String passUsuario;
    private String tipoUsuario;

    public Login(String clvUsuario, String passUsuario, String tipoUsuario) {
        this.clvUsuario = clvUsuario;
        this.passUsuario = passUsuario;
        this.tipoUsuario = tipoUsuario;
    }

    public String getClvUsuario() {
        return clvUsuario;
    }

    public void setClvUsuario(String clvUsuario) {
        this.clvUsuario = clvUsuario;
    }

    public String getPassUsuario() {
        return passUsuario;
    }

    public void setPassUsuario(String passUsuario) {
        this.passUsuario = passUsuario;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
}
