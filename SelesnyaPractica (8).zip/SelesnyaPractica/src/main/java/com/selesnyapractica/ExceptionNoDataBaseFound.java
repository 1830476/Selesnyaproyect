package com.selesnyapractica;

public class ExceptionNoDataBaseFound extends Exception {

    public ExceptionNoDataBaseFound(){

    }
    public ExceptionNoDataBaseFound(String str){
        super(str);
    }
    //throw new ExceptionNoDataBaseFound(yellow+"ADVERTENCIA: "+reset+"No se encontró una base de datos. Creando una nueva...\n\n");
}
