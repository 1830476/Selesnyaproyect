package com.selesnyapractica;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ConexionSqlite {

	//Para colores en consola
    private String red = "\033[31m";
    private String green = "\033[32m";
    private String yellow = "\033[33m";
    private String reset = "\u001B[0m";
    private String cyan = "\033[36m";
	
	private boolean errorConexion;
    public Connection eseculai() {
		errorConexion=false;
		String rutaDBTemporal;
		CargarRutas cr = new CargarRutas();
		cr.cargarRutas();
		rutaDBTemporal=cr.getRutaBDTemporal();
		
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:"+rutaDBTemporal);
			System.out.println(green + "[Conexion establecida con la BD]\n\n" + reset);
        } catch (SQLException e) {
			errorConexion=true;
            System.out.println(e.getMessage());
        } finally {
			/*
            try {
                if (conn != null) {
                    //conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }*/
        }
        return conn;
    }
	public boolean getErrorConexion(){
		return this.errorConexion;
	}
}
