package com.selesnyapractica;

public class PlanEstudios {

    private String clvPlan;
    private String nombrePlan;
    private String nivel;
    private String idCarrera;

    public PlanEstudios(String clvPlan, String nombrePlan, String nivel, String idCarrera) {
        this.clvPlan = clvPlan;
        this.nombrePlan = nombrePlan;
        this.nivel = nivel;
        this.idCarrera = idCarrera;
    }

    public String getClvPlan() {
        return clvPlan;
    }

    public void setClvPlan(String clvPlan) {
        this.clvPlan = clvPlan;
    }

    public String getNombrePlan() {
        return nombrePlan;
    }

    public void setNombrePlan(String nombrePlan) {
        this.nombrePlan = nombrePlan;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public String getIdCarrera() {
        return idCarrera;
    }

    public void setIdCarrera(String idCarrera) {
        this.idCarrera = idCarrera;
    }
}
