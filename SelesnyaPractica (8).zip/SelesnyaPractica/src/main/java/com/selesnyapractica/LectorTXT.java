package com.selesnyapractica;

import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.util.Scanner;

public class LectorTXT {

    CRUD t = new CRUD();
    CargarRutas cr = new CargarRutas();
    //Variables
    private String materia_usuarioTXT;
    private String aulasTXT;
    private String aulas_equipoTXT;
    private String carreraTXT;
    private String categorias_equipoTXT;
    private String disponibilidadTXT;
    private String equipoTXT;
    private String grupo_materia_profesorTXT;
    private String gruposTXT;
    private String loginTXT;
    private String materiasTXT;
    private String plan_estudiosTXT;
    private String uso_aula_grupoTXT;
    private String usuariosTXT;

    Scanner entrada = null;
    Scanner entrada2 = null;
    //Para colores en consola
    private String red="\033[31m";
    private String green="\033[32m";
    private String yellow="\033[33m";
    private String reset="\u001B[0m";
    private String cyan="\033[36m";

    public void insertarMateriaUsuario(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0;
        try {

            cr.cargarRutas();
            materia_usuarioTXT=cr.getMateriaUsuarioTXT();
            File f = new File(materia_usuarioTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayMateriaUsuario[][]=new String[numFilas][5];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<5;j++){
                        pos=cadena.indexOf("|");
						
						//Aqui va guardando los valores al array
                        arrayMateriaUsuario[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
					if(i==0){
						if(!arrayMateriaUsuario[0][0].equals("clv_materia")||!arrayMateriaUsuario[0][1].equals("clv_plan")||!arrayMateriaUsuario[0][2].equals("clv_usuario")||!arrayMateriaUsuario[0][3].equals("puntos_confianza")||!arrayMateriaUsuario[0][4].equals("puntos_director")||numFilas==1){
							System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
						}
					}
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
				t.insertarEnMateriaUsuarioConDatos(conec,arrayMateriaUsuario[i][0],arrayMateriaUsuario[i][1],arrayMateriaUsuario[i][2],arrayMateriaUsuario[i][3],arrayMateriaUsuario[i][4]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
			System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }

    public void insertarAulas(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=4;
        try {

            cr.cargarRutas();
            aulasTXT=cr.getAulasTXT();
            File f = new File(aulasTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayAulas[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");

                        //Aqui va guardando los valores al array
                        arrayAulas[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayAulas[0][0].equals("id_aula")||!arrayAulas[0][1].equals("nombre")||!arrayAulas[0][2].equals("tipo")||!arrayAulas[0][3].equals("capacidad")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */

                t.insertarEnAulasConDatos(conec,arrayAulas[i][0],arrayAulas[i][1],arrayAulas[i][2],arrayAulas[i][3]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }

	public void insertarAulasEquipo(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=3;
        try {

            cr.cargarRutas();
            aulas_equipoTXT=cr.getAulas_equipoTXT();
            File f = new File(aulas_equipoTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayAulasEquipo[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						//arrayAulas
                        //Aqui va guardando los valores al array
                        arrayAulasEquipo[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayAulasEquipo[0][0].equals("id_equipo")||!arrayAulasEquipo[0][1].equals("id_aula")||!arrayAulasEquipo[0][2].equals("cantidad")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnAulaEquipoConDatos(conec,arrayAulasEquipo[i][0],arrayAulasEquipo[i][1],arrayAulasEquipo[i][2]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }

	public void insertarCarrera(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=2;
        try {

            cr.cargarRutas();
            carreraTXT=cr.getCarreraTXT();
            File f = new File(carreraTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayCarrera[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						//arrayAulasEquipo
                        //Aqui va guardando los valores al array
                        arrayCarrera[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayCarrera[0][0].equals("idcarrera")||!arrayCarrera[0][1].equals("nombre_carrera")||numFilas==1) {
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnCarreraConDatos(conec,arrayCarrera[i][0],arrayCarrera[i][1]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }
	
	public void insertarCategoriasEquipo(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=3;
        try {

            cr.cargarRutas();
            categorias_equipoTXT=cr.getCategorias_equipoTXT();
            File f = new File(categorias_equipoTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayCategoriasEquipo[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						//arrayCarrera
                        //Aqui va guardando los valores al array
                        arrayCategoriasEquipo[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayCategoriasEquipo[0][0].equals("id_categoria")||!arrayCategoriasEquipo[0][1].equals("nombre_categoria")||!arrayCategoriasEquipo[0][2].equals("descripcion_categoria")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnCategoriasEquipoConDatos(conec,arrayCategoriasEquipo[i][0],arrayCategoriasEquipo[i][1],arrayCategoriasEquipo[i][2]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }
	
	public void insertarGrupoMateriaProfesor(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=3;
        try {

            cr.cargarRutas();
            grupo_materia_profesorTXT=cr.getGrupo_materia_profesorTXT();
            File f = new File(grupo_materia_profesorTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayGrupoMateriaProfesor[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						
                        //Aqui va guardando los valores al array
                        arrayGrupoMateriaProfesor[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayGrupoMateriaProfesor[0][0].equals("clv_grupo")||!arrayGrupoMateriaProfesor[0][1].equals("clv_materia")||!arrayGrupoMateriaProfesor[0][2].equals("clv_usuario")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnGrupoMateriaProfesorConDatos(conec,arrayGrupoMateriaProfesor[i][0],arrayGrupoMateriaProfesor[i][1],arrayGrupoMateriaProfesor[i][2]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }

	public void insertarGrupos(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=2;
        try {

            cr.cargarRutas();
            gruposTXT=cr.getGruposTXT();
            File f = new File(gruposTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayGrupos[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						
                        //Aqui va guardando los valores al array
                        arrayGrupos[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayGrupos[0][0].equals("clv_grupo")||!arrayGrupos[0][1].equals("turno")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnGruposConDatos(conec,arrayGrupos[i][0],arrayGrupos[i][1]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }
	
	public void insertarEquipo(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=4;
        try {

            cr.cargarRutas();
            equipoTXT=cr.getEquipoTXT();
            File f = new File(equipoTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayEquipo[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						
                        //Aqui va guardando los valores al array
                        arrayEquipo[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayEquipo[0][0].equals("id_equipo")||!arrayEquipo[0][1].equals("nombre")||!arrayEquipo[0][2].equals("descripcion")||!arrayEquipo[0][3].equals("id_categoria")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnEquipoConDatos(conec,arrayEquipo[i][0],arrayEquipo[i][1],arrayEquipo[i][2],arrayEquipo[i][3]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }
	
	public void insertarDisponibilidad(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=3;
        try {

            cr.cargarRutas();
            disponibilidadTXT=cr.getDisponibilidadTXT();
            File f = new File(disponibilidadTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayDisponibilidad[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						
                        //Aqui va guardando los valores al array
                        arrayDisponibilidad[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayDisponibilidad[0][0].equals("dia")||!arrayDisponibilidad[0][1].equals("espacio_tiempo")||!arrayDisponibilidad[0][2].equals("clv_usuario")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnDisponibilidadConDatos(conec,arrayDisponibilidad[i][0],arrayDisponibilidad[i][1],arrayDisponibilidad[i][2]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }

	public void insertarLogin(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=3;
        try {

            cr.cargarRutas();
            loginTXT=cr.getLoginTXT();
            File f = new File(loginTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayLogin[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						
                        //Aqui va guardando los valores al array
                        arrayLogin[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayLogin[0][0].equals("clv_usuario")||!arrayLogin[0][1].equals("pass_usuario")||!arrayLogin[0][2].equals("tipo_usuario")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnLoginConDatos(conec,arrayLogin[i][0],arrayLogin[i][1],arrayLogin[i][2]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }
	
	public void insertarMaterias(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=8;
        try {

            cr.cargarRutas();
            materiasTXT=cr.getMateriasTXT();
            File f = new File(materiasTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayMaterias[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						
                        //Aqui va guardando los valores al array
                        arrayMaterias[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayMaterias[0][0].equals("nombre_materia")||!arrayMaterias[0][1].equals("clv_materia")||!arrayMaterias[0][2].equals("creditos")||!arrayMaterias[0][3].equals("cuatrimestre")||!arrayMaterias[0][4].equals("posicion")||!arrayMaterias[0][5].equals("clv_plan")||!arrayMaterias[0][6].equals("horas_x_semana")||!arrayMaterias[0][7].equals("tipo_materia")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnMateriasConDatos(conec,arrayMaterias[i][0],arrayMaterias[i][1],arrayMaterias[i][2],arrayMaterias[i][3],arrayMaterias[i][4],arrayMaterias[i][5],arrayMaterias[i][6],arrayMaterias[i][7]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        }finally {
            if (entrada != null) {
                entrada.close();
            }
        }
		
		
    }
	
	public void insertarPlanEstudios(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=4;
        try {

            cr.cargarRutas();
            plan_estudiosTXT=cr.getPlan_estudiosTXT();
            File f = new File(plan_estudiosTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayPlanEstudios[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						
                        //Aqui va guardando los valores al array
                        arrayPlanEstudios[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayPlanEstudios[0][0].equals("clv_plan")||!arrayPlanEstudios[0][1].equals("nombre_plan")||!arrayPlanEstudios[0][2].equals("nivel")||!arrayPlanEstudios[0][3].equals("idcarrera")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnPlanEstudiosConDatos(conec,arrayPlanEstudios[i][0],arrayPlanEstudios[i][1],arrayPlanEstudios[i][2],arrayPlanEstudios[i][3]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        }finally {
            if (entrada != null) {
                entrada.close();
            }
        }
		
	}
	
	public void insertarUsoAulaGrupos(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=5;
        try {

            cr.cargarRutas();
            uso_aula_grupoTXT=cr.getUso_aula_grupoTXT();
            File f = new File(uso_aula_grupoTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayUsoAulaGrupo[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						
                        //Aqui va guardando los valores al array
                        arrayUsoAulaGrupo[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayUsoAulaGrupo[0][0].equals("dia")||!arrayUsoAulaGrupo[0][1].equals("espacio_tiempo")||!arrayUsoAulaGrupo[0][2].equals("id_aula")||!arrayUsoAulaGrupo[0][3].equals("clv_grupo")||!arrayUsoAulaGrupo[0][4].equals("clv_materia")||numFilas==1){
                            System.out.println("\n");
                            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnUsoAulaGrupoConDatos(conec,arrayUsoAulaGrupo[i][0],arrayUsoAulaGrupo[i][1],arrayUsoAulaGrupo[i][2],arrayUsoAulaGrupo[i][3],arrayUsoAulaGrupo[i][4]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
	}
	
	public void insertarUsuarios(Connection conec){
        String linea="";
        String cadena="";

        int pos, i, j, numFilas=0, numColum=5;
        try {

            cr.cargarRutas();
            usuariosTXT=cr.getUsuariosTXT();
            File f = new File(usuariosTXT);

            entrada = new Scanner(f);

            //Esto lee el archivo solamente para saber cuantas filas tiene
            entrada2 = new Scanner(f);
            while (entrada2.hasNext()) {
                linea=entrada2.nextLine();
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    numFilas++;
                }

            }

            String arrayUsuarios[][]=new String[numFilas][numColum];
            i=0;

            //Aqui lee el archivo ahora si para guardar datos en el array
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                cadena=linea;
                pos=linea.substring(0,1).indexOf("-");
                if(pos==-1){
                    for (j=0;j<numColum;j++){
                        pos=cadena.indexOf("|");
						
                        //Aqui va guardando los valores al array
                        arrayUsuarios[i][j]=cadena.substring(0,pos);
                        cadena=cadena.substring(pos+1,cadena.length());
                    }
                    if(i==0){
                        if(!arrayUsuarios[0][0].equals("clv_usuario")||!arrayUsuarios[0][1].equals("idcarrera")||!arrayUsuarios[0][2].equals("nombre_usuario")||!arrayUsuarios[0][3].equals("nivel_ads")||!arrayUsuarios[0][4].equals("contrato")||numFilas==1){
                            System.out.println("\n");
                            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
                            throw new ExceptionFormatoTXTNoValido("Formato TXT incorrecto. Verifique el archivo.");
                        }
                    }
                    i++;
                }

            }
            for(i=1;i<numFilas;i++){
				/*
				Aquí manda el conect y cada uno de los valores que se ingresaran en la columna al método insertarEnMateriaUsuarioConDatos
				de la clase TestInsersion. Para verificar las forgein key y que el registro sea nuevo en la tabla.
                */
                t.insertarEnUsuariosConDatos(conec,arrayUsuarios[i][0],arrayUsuarios[i][1],arrayUsuarios[i][2],arrayUsuarios[i][3],arrayUsuarios[i][4]);
            }

        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se encontró el archivo");

        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
            JOptionPane.showMessageDialog(null, "Excepcion: No se seleccionó ningun archivo");

        } catch(StringIndexOutOfBoundsException e){
            System.out.println(red+"[Error] "+reset+"Formato TXT incorrecto. Verifique el archivo.");
            JOptionPane.showMessageDialog(null, "Formato TXT incorrecto. Verifique el archivo.");
        }catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
            JOptionPane.showMessageDialog(null, "Error");

        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
	}
	
}
