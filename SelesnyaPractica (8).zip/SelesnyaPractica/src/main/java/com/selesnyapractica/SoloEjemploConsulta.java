package com.selesnyapractica;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

public class SoloEjemploConsulta {

    //Para colores en consola
    private String red = "\033[31m";
    private String green = "\033[32m";
    private String yellow = "\033[33m";
    private String reset = "\u001B[0m";
    private String cyan = "\033[36m";

	public void mostrartablas(Connection conect){
		this.mostrarAulas(conect);
		this.mostrarAula_equipo(conect);
		
	}
	
	public void mostrarAulas(Connection conect) {
        try {
            Statement s = conect.createStatement();
			//s.execute("use selesnyadb");
            ResultSet rs = s.executeQuery("select * from aulas");
            System.out.println(yellow+"[TABLA AULAS]\n\n"+reset);
            System.out.println("id_aula\t\tnombre\t\ttipo\t\tcapacidad\n");
            while (!String.valueOf(rs.next()).equals("false")) {
                System.out.println(rs.getInt(1) + "\t\t" + rs.getString(2)+ "\t\t"+ rs.getString(3)+ "\t\t"+ rs.getInt(4));
            }
            System.out.println("\n\n");
        } catch (Exception e) {
			System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion: " + e);
        }
    }
	
    public void mostrarAula_equipo(Connection conect) {
        try {
            Statement s = conect.createStatement();
			//s.execute("use selesnyadb");
            ResultSet rs = s.executeQuery("select * from aula_equipo");
            System.out.println(yellow+"[TABLA AULA EQUIPOS]\n\n"+reset);
            System.out.println("id_equipo\t\tid_aula\t\tcantidad\n");
            while (!String.valueOf(rs.next()).equals("false")) {
                System.out.println(rs.getInt(1) + "\t\t" + rs.getInt(2)+ "\t\t" +rs.getInt(3));
            }
            System.out.println("\n\n");
        } catch (Exception e) {
			System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion: " + e);
        }
    }
	
    //Extras
    public void limpiarConsola() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception e) {
        }

    }

    public void esperar() {
        try {
            Thread.sleep(5 * 1000);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}