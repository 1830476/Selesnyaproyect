package com.selesnyapractica;

public class AulaEquipo {

    private String idEquipo;
    private String idAula;
    private String cantidad;

    public AulaEquipo(String idEquipo, String idAula, String cantidad) {
        this.idEquipo = idEquipo;
        this.idAula = idAula;
        this.cantidad = cantidad;
    }

    public String getIdEquipo() {
        return idEquipo;
    }

    public void setIdEquipo(String idEquipo) {
        this.idEquipo = idEquipo;
    }

    public String getIdAula() {
        return idAula;
    }

    public void setIdAula(String idAula) {
        this.idAula = idAula;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }
}
