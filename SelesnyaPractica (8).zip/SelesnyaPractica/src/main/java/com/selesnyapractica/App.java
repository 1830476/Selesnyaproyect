package com.selesnyapractica;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class App extends Application
{
    public static void main( String[] args ) throws SQLException {
		launch(args);
		System.out.println( "Hello World!" );
		//Menu m = new Menu();
		//m.iniciar();

    }

	@Override
	public void start(Stage stage) throws Exception {
		try{
			stage = FXMLLoader.load(getClass().getResource("/Elementos/inicio.fxml"));
			stage.show();
		} catch (IOException e){
			System.out.println("error: "+e);
		}
	}

	public void menu(){
		try{
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/listalistas.fxml"));
			op.show();
		} catch (IOException e){
			System.out.println("error: "+e);
		}
	}

	public void aula_equipo(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/aula_equipo.fxml"));
			op.show();

		} catch (IOException e) {
			System.out.println("error: "+e);

		}
	}

	public void aulas(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/aulas.fxml"));
			op.show();

		} catch (IOException e) {
			System.out.println("error: "+e);

		}
	}

	public void carreras(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/carreras.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void categorias_equipo(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/categorias_equipo.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void disponibilidad(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/disponibilidad.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void equipo(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/equipo.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void grupos(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/grupos.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void grupos_materias_profesor(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/grupos_materias_profesor.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void login(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/login.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void materia_usuario(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/materia_usuario.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void materias(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/materias.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void plan_estudios(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/plan_estudios.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void uso_aula_grupo(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/uso_aula_grupo.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}

	public void usuarios(){
		try {
			Stage op = FXMLLoader.load(getClass().getResource("/Elementos/usuarios.fxml"));
			op.show();

		} catch (IOException e) {

		}
	}


	public void txt(){
		try{
			Stage op = FXMLLoader.load(getClass().getResource("/txt/fxml/listalistas.fxml"));
			op.show();
		} catch (IOException e){
			System.out.println("error: "+e);
		}
	}

	public void xlsx(){
		try{
			Stage op = FXMLLoader.load(getClass().getResource("/xlsx/fxml/listalistas.fxml"));
			op.show();
		} catch (IOException e){
			System.out.println("error: "+e);
		}
	}

}
