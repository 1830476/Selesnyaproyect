package com.selesnyapractica;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.control.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class FXMLController implements Initializable {

    @FXML
    Button btn_grupos_materia_profesor, btn_aulas, btn_carreras, btn_categorias_equipo, btn_disponibilidad, btn_equipo, btn_grupos;
    @FXML
    Button btn_login, btn_materia_usuario, btn_materias, btn_plan_estudios, btn_uso_aula_grupo, btn_usuarios;

    @FXML
    Button btn_aula_equipos, btn_CRUD, btn_TablasSQL;



    @FXML
    Button btn_txt, btn_xlsx;

    //*************************************************

    /////////////AULA_EQUIPO
    @FXML
    Button btn_volver_aula_equipo;

    @FXML
    TextField labelidEquipoAE,labelidAulaAE,labelcantidadAE;

    @FXML
    TextField modificarIdEquipoAE,modificarIdAulaAE,modificarCantidadAE;

    ////////////AULAS
    @FXML
    Button btn_volver_aulas;

    @FXML
    TextField labelIdAulaA,labelNombreA,labelTipoA,labelCapacidadA;

    @FXML
    TextField modificarIdAulaA,modificarNombreA,modificarTipoA,modificarCapacidadA;
    ////////////carreras
    @FXML
    Button btn_volver_carreras;

    @FXML
    TextField modificarIdCarreraC,modificarNombreCarreraC;
    ////////////categorias equipo
    @FXML
    Button btn_volver_categorias_equipo;

    @FXML
    TextField modificarIdCategoriaCE,modificarNombreCategoriaCE,modificarDescripcionCategoriaCE;


    ////////////Disponibilidad
    @FXML
    Button btn_volver_disponibilidad;

    @FXML
    TextField modificarDiaD,modificarEspacioTiempoD,modificarClvUsuarioD;

    ////////////Equipo
    @FXML
    Button btn_volver_equipo;

    @FXML
    TextField modificarIdEquipoE,modificarNombreE,modificarDescripcionE,modificarIdCategoriaE;

    ////////////Grupos
    @FXML
    Button btn_volver_grupos;

    @FXML
    TextField modificarClvGrupoG,modificarTurnoG;

    ////////////Grupos materias profesor
    @FXML
    Button btn_volver_grupos_materias_profesor;

    @FXML
    TextField modificarClvGrupoGMP,modificarClvMateriaGMP,modificarClvUsuarioGMP;

    ////////////login
    @FXML
    Button btn_volver_login;

    @FXML
    TextField modificarClvUsuarioL,modificarPassUsuarioL,modificarTipoUsuarioL;

    ////////////Materia usuario
    @FXML
    Button btn_volver_materia_usuario;

    @FXML
    TextField modificarClvMateriaMU,modificarClvPlanMU,modificarClvUsuarioMU,modificarPuntosConfianzaMU,modificarPuntosDirectorMU;

    ////////////Materias
    @FXML
    Button btn_volver_materias;

    @FXML
    TextField modificarNombreMateriaM,modificarClvMateriaM,modificarCreditosM,modificarCuatrimestreM,modificarPosicionM,modificarClvPlanM,modificarHoraXSemanaM,modificarTipoMateriaM;
    ////////////Plan estudios
    @FXML
    Button btn_volver_plan_estudios;

    @FXML
    TextField modificarClvPlanPE,modificarNombrePlanPE,modificarNivelPE,modificarIdCarreraPE;

    ////////////Uso aula grupo
    @FXML
    Button btn_volver_uso_aula_grupo;

    @FXML
    TextField modificarDiaUAG,modificarEspacioTiempoUAG,modificarIdAulaUAG,modificarClvGrupoUAG,modificarClvMateriaUAG;

    ////////////Usuarios
    @FXML
    Button btn_volver_usuarios;

    @FXML
    TextField modificarClvUsuarioU,modificarIdCarreraU,modificarNombreUsuarioU,modificarNivelAdsU,modificarContratoU;


    //*************************************************

    //************************************************* TABLAS VIEW

    @FXML private TableView<AulaEquipo> tablaAE;
    @FXML private TableColumn<AulaEquipo,String>idEquipoAE;
    @FXML private TableColumn<AulaEquipo,String>idAulaAE;
    @FXML private TableColumn<AulaEquipo,String>cantidadAE;
    String idEquipoAulAEquipo = "",idAulaAulaEquipo = "",cantidadAulaEquipo = "";

    @FXML private TableView<Aulas> tablaA;
    @FXML private TableColumn<Aulas,String>idAulaA;
    @FXML private TableColumn<Aulas,String>nombreA;
    @FXML private TableColumn<Aulas,String>tipoA;
    @FXML private TableColumn<Aulas,String>capacidadA;
    String idAulaAula = "",nombreAula = "",tipoAula = "",capacidadAula = "";

    @FXML private TableView<Carrera> tablaC;
    @FXML private TableColumn<Carrera, String> idCarreraC;
    @FXML private TableColumn<Carrera, String> nombreCarreraC;
    String idCarreraCarrera = "",nombreCarreraCarrera = "";

    @FXML private TableView<CategoriasEquipo> tablaCE;
    @FXML private TableColumn<CategoriasEquipo, String> idCategoriaCE;
    @FXML private TableColumn<CategoriasEquipo, String> nombreCategoriaCE;
    @FXML private TableColumn<CategoriasEquipo, String> descripcionCategoriaCE;

    String idCategoriaCategoriasEquipo = "",nombreCategoriaCategoriasEquipo = "", descripcionCategoriaCategoriasEquipo = "";

    @FXML private TableView<Disponibilidad> tablaD;
    @FXML private TableColumn<Disponibilidad, String> diaD;
    @FXML private TableColumn<Disponibilidad, String> espacioTiempoD;
    @FXML private TableColumn<Disponibilidad, String> clvUsuarioD;

    String diaDisponibilidad = "", espacioTiempoDisponibilidad = "", clvUsuarioDisponibilidad = "";

    @FXML private TableView<Equipo> tablaE;
    @FXML private TableColumn<Equipo, String> idEquipoE;
    @FXML private TableColumn<Equipo, String> nombreE;
    @FXML private TableColumn<Equipo, String> descripcionE;
    @FXML private TableColumn<Equipo, String> idCategoriaE;

    String idEquipoEquipo = "", nombreEquipo = "", descripcionEquipo = "", idCategoriaEquipo = "";

    @FXML private TableView<Grupos> tablaG;
    @FXML private TableColumn<Grupos, String> clvGrupoG;
    @FXML private TableColumn<Grupos, String> turnoG;

    String clvGrupoGrupos = "", turnoGrupos = "";

    @FXML private TableView<GruposMateriasProfesor> tablaGMP;
    @FXML private TableColumn<GruposMateriasProfesor, String> clvGrupoGMP;
    @FXML private TableColumn<GruposMateriasProfesor, String> clvMateriaGMP;
    @FXML private TableColumn<GruposMateriasProfesor, String> clvUsuarioGMP;

    String clvGrupoGruposMateriasProfesor = "", clvMateriaGruposMateriasProfesor = "", clvUsuarioGruposMateriasProfesor = "";

    @FXML private TableView<Login> tablaL;
    @FXML private TableColumn<Login, String> clvUsuarioL;
    @FXML private TableColumn<Login, String> passUsuarioL;
    @FXML private TableColumn<Login, String> tipoUsuarioL;

    String clvUsuarioLogin = "", passUsuarioLogin = "", tipoUsuarioLogin = "";

    @FXML private TableView<MateriaUsuario> tablaMU;
    @FXML private TableColumn<MateriaUsuario, String> clvMateriaMU;
    @FXML private TableColumn<MateriaUsuario, String> clvPlanMU;
    @FXML private TableColumn<MateriaUsuario, String> clvUsuarioMU;
    @FXML private TableColumn<MateriaUsuario, String> puntosConfianzaMU;
    @FXML private TableColumn<MateriaUsuario, String> puntosDirectorMU;

    String clvMateriaMateriaUsuario = "", clvPlanMateriaUsuario = "", clvUsuarioMateriaUsuario = "", puntosConfianzaMateriaUsuario="", puntosDirectorMateriaUsuario="";

    @FXML private TableView<Materias> tablaM;
    @FXML private TableColumn<Materias, String> nombreMateriaM;
    @FXML private TableColumn<Materias, String> clvMateriaM;
    @FXML private TableColumn<Materias, String> creditosM;
    @FXML private TableColumn<Materias, String> cuatrimestreM;
    @FXML private TableColumn<Materias, String> posicionM;
    @FXML private TableColumn<Materias, String> clvPlanM;
    @FXML private TableColumn<Materias, String> horasXSemanaM;
    @FXML private TableColumn<Materias, String> tipoMateriaM;

    String nombreMateriaMateria = "", clvMateriaMateria = "", creditosMateria = "", cuatrimestreMateria="", posicionMateria="", clvPlanMateria="", horasXSemanaMateria="", tipoMateriaMateria="";

    @FXML private TableView<PlanEstudios> tablaPE;
    @FXML private TableColumn<PlanEstudios, String> clvPlanPE;
    @FXML private TableColumn<PlanEstudios, String> nombrePlanPE;
    @FXML private TableColumn<PlanEstudios, String> nivelPE;
    @FXML private TableColumn<PlanEstudios, String> idCarreraPE;

    String clvPlanPlanEstudios = "", nombrePlanPlanEstudios = "", nivelPlanEstudios = "", idCarreraPlanEstudios = "";

    @FXML private TableView<UsoAulaGrupo> tablaUAG;
    @FXML private TableColumn<UsoAulaGrupo, String> diaUAG;
    @FXML private TableColumn<UsoAulaGrupo, String> espacioTiempoUAG;
    @FXML private TableColumn<UsoAulaGrupo, String> idAulaUAG;
    @FXML private TableColumn<UsoAulaGrupo, String> clvGrupoUAG;
    @FXML private TableColumn<UsoAulaGrupo, String> clvMateriaUAG;

    String diaUsoAulaGrupo = "", espacioTiempoUsoAulaGrupo = "", idAulaUsoAulaGrupo = "", clvGrupoUsoAulaGrupo="", clvMateriaUsoAulaGrupo="";

    @FXML private TableView<Usuarios> tablaU;
    @FXML private TableColumn<Usuarios, String> clvUsuarioU;
    @FXML private TableColumn<Usuarios, String> idCarreraU;
    @FXML private TableColumn<Usuarios, String> nombreUsuarioU;
    @FXML private TableColumn<Usuarios, String> nivelAdsU;
    @FXML private TableColumn<Usuarios, String> contratoU;

    String clvUsuarioUsuario = "", idCarreraUsuario = "", nombreUsuarioUsuario = "", nivelAdsUsuario="", contratoUsuario="";




    //*************************************************


    //************************************************* TEXTFIELD

    @FXML TextField lidCarrera, lnombreCarrera; //Carrera

    @FXML TextField tf_idCategoriaCE, tf_nombreCategoriaCE, tf_descripcionCategoriaCE; //CategoriaEquipo

    @FXML TextField tf_diaD, tf_espacioTiempoD, tf_clvUsuarioD; //Disponibilidad

    @FXML TextField tf_idEquipoE, tf_nombreE, tf_descripcionE, tf_idCategoriaE; //Equipos

    @FXML TextField tf_clvGrupoG, tf_turnoG; //Grupos

    @FXML TextField tf_clvUsuarioL, tf_passUsuarioL, tf_tipoUsuarioL; //Login

    @FXML TextField tf_clvGrupoGMP, tf_clvMateriaGMP, tf_clvUsuarioGMP; //GruposMateriasProfesor

    @FXML TextField tf_clvMateriaMU, tf_clvPlanMU, tf_clvUsuarioMU, tf_puntosConfianzaMU, tf_puntosDirector2MU; //MateriaUsuario

    @FXML TextField tf_nombreMateriaM, tf_clvMateriaM, tf_creditosM, tf_cuatrimestreM, tf_posicionM, tf_clvPlanM, tf_horasXSemanaM, tf_tipoMateriaM; //Materias




    //*************************************************


    //************************************************* ARRAYS
    static ArrayList<AulaEquipo> arrayAulaEquipo= new ArrayList<>();
    static ArrayList<Aulas> arrayAulas= new ArrayList<>();
    static ArrayList<Carrera> arrayCarrera= new ArrayList<>();
    static ArrayList<CategoriasEquipo> arrayCategoriasEquipo= new ArrayList<>();
    static ArrayList<Disponibilidad> arrayDisponibilidad= new ArrayList<>();
    static ArrayList<Equipo> arrayEquipo= new ArrayList<>();
    static ArrayList<Grupos> arrayGrupos= new ArrayList<>();
    static ArrayList<GruposMateriasProfesor> arrayGruposMateriasProfesor= new ArrayList<>();
    static ArrayList<Login> arrayLogin= new ArrayList<>();
    static ArrayList<MateriaUsuario> arrayMateriaUsuario= new ArrayList<>();
    static ArrayList<Materias> arrayMaterias= new ArrayList<>();
    static ArrayList<PlanEstudios> arrayPlanEstudios= new ArrayList<>();
    static ArrayList<UsoAulaGrupo> arrayUsoAulaGrupo= new ArrayList<>();
    static ArrayList<Usuarios> arrayUsuarios= new ArrayList<>();




    App app = new App();
    CargarTablas cargarTablas = new CargarTablas();
    CRUD cru = new CRUD();

    static int opcion = 0;
    static String valor1 ="";





    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        if(opcion == 1){
            try{
                idEquipoAE.setCellValueFactory(new PropertyValueFactory<AulaEquipo, String>("idEquipo"));
                idAulaAE.setCellValueFactory(new PropertyValueFactory<AulaEquipo, String>("idAula"));
                cantidadAE.setCellValueFactory(new PropertyValueFactory<AulaEquipo, String>("cantidad"));

                tablaAE.setItems(getObjectoAulaEquipo());
            }catch (Exception e){
            }
        }else if(opcion == 2){
            try{
                idAulaA.setCellValueFactory(new PropertyValueFactory<Aulas, String>("idAula"));
                nombreA.setCellValueFactory(new PropertyValueFactory<Aulas, String>("nombre"));
                tipoA.setCellValueFactory(new PropertyValueFactory<Aulas, String>("tipo"));
                capacidadA.setCellValueFactory(new PropertyValueFactory<Aulas, String>("capacidad"));

                tablaA.setItems(getObjectoAulas());
            }catch (Exception e){
            }
        }else if(opcion == 3){
            try{
                idCarreraC.setCellValueFactory(new PropertyValueFactory<Carrera, String>("idCarrera"));
                nombreCarreraC.setCellValueFactory(new PropertyValueFactory<Carrera, String>("nombreCarrera"));

                tablaC.setItems(getObjectoCarrera());
            }catch (Exception e){
            }
        }else if(opcion == 4){
            try{
                idCategoriaCE.setCellValueFactory(new PropertyValueFactory<CategoriasEquipo, String>("idCategoria"));
                nombreCategoriaCE.setCellValueFactory(new PropertyValueFactory<CategoriasEquipo, String>("nombreCategoria"));
                descripcionCategoriaCE.setCellValueFactory(new PropertyValueFactory<CategoriasEquipo, String>("descripcionCategoria"));

                tablaCE.setItems(getObjectoCategoriasEquipo());
            }catch (Exception e){
            }
        }else if(opcion == 5){
            try{
                diaD.setCellValueFactory(new PropertyValueFactory<Disponibilidad, String>("dia"));
                espacioTiempoD.setCellValueFactory(new PropertyValueFactory<Disponibilidad, String>("espacioTiempo"));
                clvUsuarioD.setCellValueFactory(new PropertyValueFactory<Disponibilidad, String>("clvUsuario"));

                tablaD.setItems(getObjectoDisponibilidad());
            }catch (Exception e){
            }
        }else if(opcion == 6){
            try{
                idEquipoE.setCellValueFactory(new PropertyValueFactory<Equipo, String>("idEquipo"));
                nombreE.setCellValueFactory(new PropertyValueFactory<Equipo, String>("nombre"));
                descripcionE.setCellValueFactory(new PropertyValueFactory<Equipo, String>("descripcion"));
                idCategoriaE.setCellValueFactory(new PropertyValueFactory<Equipo, String>("idCategoria"));

                tablaE.setItems(getObjectoEquipo());
            }catch (Exception e){
            }
        }else if(opcion == 7){
            try{
                clvGrupoG.setCellValueFactory(new PropertyValueFactory<Grupos, String>("clvGrupo"));
                turnoG.setCellValueFactory(new PropertyValueFactory<Grupos, String>("turno"));

                tablaG.setItems(getObjectoGrupos());
            }catch (Exception e){
            }
        }else if(opcion == 8){
            try{
                clvGrupoGMP.setCellValueFactory(new PropertyValueFactory<GruposMateriasProfesor, String>("clvGrupo"));
                clvMateriaGMP.setCellValueFactory(new PropertyValueFactory<GruposMateriasProfesor, String>("clvMateria"));
                clvUsuarioGMP.setCellValueFactory(new PropertyValueFactory<GruposMateriasProfesor, String>("clvUsuario"));

                tablaGMP.setItems(getObjectoGruposMateriasProfesor());
            }catch (Exception e){
            }
        }else if(opcion == 9){
            try{
                clvUsuarioL.setCellValueFactory(new PropertyValueFactory<Login, String>("clvUsuario"));
                passUsuarioL.setCellValueFactory(new PropertyValueFactory<Login, String>("passUsuario"));
                tipoUsuarioL.setCellValueFactory(new PropertyValueFactory<Login, String>("tipoUsuario"));

                tablaL.setItems(getObjectoLogin());
            }catch (Exception e){
            }
        }else if(opcion == 10){
            try{
                clvMateriaMU.setCellValueFactory(new PropertyValueFactory<MateriaUsuario, String>("clvMateria"));
                clvPlanMU.setCellValueFactory(new PropertyValueFactory<MateriaUsuario, String>("clvPlan"));
                clvUsuarioMU.setCellValueFactory(new PropertyValueFactory<MateriaUsuario, String>("clvUsuario"));
                puntosConfianzaMU.setCellValueFactory(new PropertyValueFactory<MateriaUsuario, String>("puntosConfianza"));
                puntosDirectorMU.setCellValueFactory(new PropertyValueFactory<MateriaUsuario, String>("puntosDirector"));

                tablaMU.setItems(getObjectoMateriaUsuario());
            }catch (Exception e){
            }
        }else if(opcion == 11){
            try{
                nombreMateriaM.setCellValueFactory(new PropertyValueFactory<Materias, String>("nombreMateria"));
                clvMateriaM.setCellValueFactory(new PropertyValueFactory<Materias, String>("clvMateria"));
                creditosM.setCellValueFactory(new PropertyValueFactory<Materias, String>("creditos"));
                cuatrimestreM.setCellValueFactory(new PropertyValueFactory<Materias, String>("cuatrimestre"));
                posicionM.setCellValueFactory(new PropertyValueFactory<Materias, String>("posicion"));
                clvPlanM.setCellValueFactory(new PropertyValueFactory<Materias, String>("clvPlan"));
                horasXSemanaM.setCellValueFactory(new PropertyValueFactory<Materias, String>("horasXSemana"));
                tipoMateriaM.setCellValueFactory(new PropertyValueFactory<Materias, String>("tipoMateria"));

                tablaM.setItems(getObjectoMaterias());
            }catch (Exception e){
            }
        }else if(opcion == 12){
            try{
                clvPlanPE.setCellValueFactory(new PropertyValueFactory<PlanEstudios, String>("clvPlan"));
                nombrePlanPE.setCellValueFactory(new PropertyValueFactory<PlanEstudios, String>("nombrePlan"));
                nivelPE.setCellValueFactory(new PropertyValueFactory<PlanEstudios, String>("nivel"));
                idCarreraPE.setCellValueFactory(new PropertyValueFactory<PlanEstudios, String>("idCarrera"));

                tablaPE.setItems(getObjectoPlanEstudios());
            }catch (Exception e){
            }
        }else if(opcion == 13){
            try{
                diaUAG.setCellValueFactory(new PropertyValueFactory<UsoAulaGrupo, String>("dia"));
                espacioTiempoUAG.setCellValueFactory(new PropertyValueFactory<UsoAulaGrupo, String>("espacioTiempo"));
                idAulaUAG.setCellValueFactory(new PropertyValueFactory<UsoAulaGrupo, String>("idAula"));
                clvGrupoUAG.setCellValueFactory(new PropertyValueFactory<UsoAulaGrupo, String>("clvGrupo"));
                clvMateriaUAG.setCellValueFactory(new PropertyValueFactory<UsoAulaGrupo, String>("clvMateria"));

                tablaUAG.setItems(getObjectoUsoAulaGrupo());
            }catch (Exception e){
            }
        }else if(opcion == 14){
            try{
                clvUsuarioU.setCellValueFactory(new PropertyValueFactory<Usuarios, String>("clvUsuario"));
                idCarreraU.setCellValueFactory(new PropertyValueFactory<Usuarios, String>("idCarrera"));
                nombreUsuarioU.setCellValueFactory(new PropertyValueFactory<Usuarios, String>("nombreUsuario"));
                nivelAdsU.setCellValueFactory(new PropertyValueFactory<Usuarios, String>("nivelAds"));
                contratoU.setCellValueFactory(new PropertyValueFactory<Usuarios, String>("contrato"));

                tablaU.setItems(getObjectoUsuarios());
            }catch (Exception e){
            }
        }


    }

    private ObservableList<AulaEquipo> getObjectoAulaEquipo() throws SQLException {
        ObservableList<AulaEquipo> aulaEquipo = FXCollections.observableArrayList();
        ArrayList<AulaEquipo> arrayAulaEquipo = new ArrayList<AulaEquipo>();
        arrayAulaEquipo = cargarTablas.cargaAulaEquipo();

        for (int i = 0; i < arrayAulaEquipo.size(); i++) {
            idEquipoAulAEquipo = arrayAulaEquipo.get(i).getIdEquipo();
            idAulaAulaEquipo = arrayAulaEquipo.get(i).getIdAula();
            cantidadAulaEquipo = arrayAulaEquipo.get(i).getCantidad();

            System.out.println(1+idAulaAulaEquipo+2+ idEquipoAulAEquipo+3 + cantidadAulaEquipo);
            aulaEquipo.add(new AulaEquipo(idEquipoAulAEquipo, idAulaAulaEquipo, cantidadAulaEquipo));
        }

        return aulaEquipo;
    }

    private ObservableList<Aulas> getObjectoAulas() throws SQLException {
        ObservableList<Aulas> aulas = FXCollections.observableArrayList();
        ArrayList<Aulas> arrayAulas = new ArrayList<Aulas>();
        arrayAulas = cargarTablas.cargarAulas();

        for (int i = 0; i < arrayAulas.size(); i++) {
            idAulaAula = arrayAulas.get(i).getIdAula();
            nombreAula = arrayAulas.get(i).getNombre();
            tipoAula = arrayAulas.get(i).getTipo();
            capacidadAula = arrayAulas.get(i).getCapacidad();
            aulas.add(new Aulas(idAulaAula, nombreAula, tipoAula,capacidadAula));
        }

        return aulas;
    }

    private ObservableList<Carrera> getObjectoCarrera() throws SQLException {
        ObservableList<Carrera> carrera = FXCollections.observableArrayList();
        ArrayList<Carrera> arrayCarrera = new ArrayList<Carrera>();
        arrayCarrera = cargarTablas.cargarCarrera();

        for (int i = 0; i < arrayCarrera.size(); i++) {
            idCarreraCarrera = arrayCarrera.get(i).getIdCarrera();
            nombreCarreraCarrera = arrayCarrera.get(i).getNombreCarrera();

            carrera.add(new Carrera(idCarreraCarrera, nombreCarreraCarrera));
        }

        return carrera;
    }

    private ObservableList<CategoriasEquipo> getObjectoCategoriasEquipo() throws SQLException {
        ObservableList<CategoriasEquipo> categoriasEquipos = FXCollections.observableArrayList();
        ArrayList<CategoriasEquipo> arrayCategoriasEquipo = new ArrayList<CategoriasEquipo>();
        arrayCategoriasEquipo = cargarTablas.cargarCategoriasEquipo();

        for (int i = 0; i < arrayCategoriasEquipo.size(); i++) {
            idCategoriaCategoriasEquipo = arrayCategoriasEquipo.get(i).getIdCategoria();
            nombreCategoriaCategoriasEquipo = arrayCategoriasEquipo.get(i).getNombreCategoria();
            descripcionCategoriaCategoriasEquipo = arrayCategoriasEquipo.get(i).getDescripcionCategoria();
            categoriasEquipos.add(new CategoriasEquipo(idCategoriaCategoriasEquipo, nombreCategoriaCategoriasEquipo,descripcionCategoriaCategoriasEquipo));
        }

        return categoriasEquipos;
    }

    private ObservableList<Disponibilidad> getObjectoDisponibilidad() throws SQLException {
        ObservableList<Disponibilidad> disponibilidad = FXCollections.observableArrayList();
        ArrayList<Disponibilidad> arrayDisponibilidad = new ArrayList<Disponibilidad>();
        arrayDisponibilidad = cargarTablas.cargarDisponibilidad();

        for (int i = 0; i < arrayDisponibilidad.size(); i++) {
            diaDisponibilidad = arrayDisponibilidad.get(i).getDia();
            espacioTiempoDisponibilidad = arrayDisponibilidad.get(i).getEspacioTiempo();
            clvUsuarioDisponibilidad = arrayDisponibilidad.get(i).getClvUsuario();
            disponibilidad.add(new Disponibilidad(diaDisponibilidad, espacioTiempoDisponibilidad,clvUsuarioDisponibilidad));
        }

        return disponibilidad;
    }

    private ObservableList<Equipo> getObjectoEquipo() throws SQLException {
        ObservableList<Equipo> equipo = FXCollections.observableArrayList();
        ArrayList<Equipo> arrayEquipo = new ArrayList<Equipo>();
        arrayEquipo = cargarTablas.cargarEquipo();

        for (int i = 0; i < arrayEquipo.size(); i++) {
            idEquipoEquipo = arrayEquipo.get(i).getIdEquipo();
            nombreEquipo = arrayEquipo.get(i).getNombre();
            descripcionEquipo = arrayEquipo.get(i).getDescripcion();
            idCategoriaEquipo = arrayEquipo.get(i).getIdCategoria();
            equipo.add(new Equipo(idEquipoEquipo, nombreEquipo,descripcionEquipo, idCategoriaEquipo));
        }

        return equipo;
    }

    private ObservableList<Grupos> getObjectoGrupos() throws SQLException {
        ObservableList<Grupos> grupos = FXCollections.observableArrayList();
        ArrayList<Grupos> arrayGrupos = new ArrayList<Grupos>();
        arrayGrupos = cargarTablas.cargarGrupos();

        for (int i = 0; i < arrayGrupos.size(); i++) {
            clvGrupoGrupos = arrayGrupos.get(i).getClvGrupo();
            turnoGrupos = arrayGrupos.get(i).getTurno();

            grupos.add(new Grupos(clvGrupoGrupos, turnoGrupos));
        }

        return grupos;
    }

    private ObservableList<GruposMateriasProfesor> getObjectoGruposMateriasProfesor() throws SQLException {
        ObservableList<GruposMateriasProfesor> gruposmateriasprofesor = FXCollections.observableArrayList();
        ArrayList<GruposMateriasProfesor> arrayGruposMateriasProfesor = new ArrayList<GruposMateriasProfesor>();
        arrayGruposMateriasProfesor = cargarTablas.cargarGruposMateriasProfesor();

        for (int i = 0; i < arrayGruposMateriasProfesor.size(); i++) {
            clvGrupoGruposMateriasProfesor = arrayGruposMateriasProfesor.get(i).getClvGrupo();
            clvMateriaGruposMateriasProfesor = arrayGruposMateriasProfesor.get(i).getClvMateria();
            clvUsuarioGruposMateriasProfesor = arrayGruposMateriasProfesor.get(i).getClvUsuario();

            gruposmateriasprofesor.add(new GruposMateriasProfesor(clvGrupoGruposMateriasProfesor, clvMateriaGruposMateriasProfesor, clvUsuarioGruposMateriasProfesor));
        }

        return gruposmateriasprofesor;
    }

    private ObservableList<Login> getObjectoLogin() throws SQLException {
        ObservableList<Login> login = FXCollections.observableArrayList();
        ArrayList<Login> arrayLogin = new ArrayList<Login>();
        arrayLogin = cargarTablas.cargarLogin();

        for (int i = 0; i < arrayLogin.size(); i++) {
            clvUsuarioLogin = arrayLogin.get(i).getClvUsuario();
            passUsuarioLogin = arrayLogin.get(i).getPassUsuario();
            tipoUsuarioLogin = arrayLogin.get(i).getTipoUsuario();

            login.add(new Login(clvUsuarioLogin, passUsuarioLogin, tipoUsuarioLogin));
        }

        return login;
    }

    private ObservableList<MateriaUsuario> getObjectoMateriaUsuario() throws SQLException {
        ObservableList<MateriaUsuario> materiausuario = FXCollections.observableArrayList();
        ArrayList<MateriaUsuario> arrayMateriaUsuario = new ArrayList<MateriaUsuario>();
        arrayMateriaUsuario = cargarTablas.cargarMateriaUsuario();

        for (int i = 0; i < arrayMateriaUsuario.size(); i++) {
            clvMateriaMateriaUsuario = arrayMateriaUsuario.get(i).getClvMateria();
            clvPlanMateriaUsuario = arrayMateriaUsuario.get(i).getClvPlan();
            clvUsuarioMateriaUsuario = arrayMateriaUsuario.get(i).getClvUsuario();
            puntosConfianzaMateriaUsuario = arrayMateriaUsuario.get(i).getPuntosConfianza();
            puntosDirectorMateriaUsuario = arrayMateriaUsuario.get(i).getPuntosDirector();

            materiausuario.add(new MateriaUsuario(clvMateriaMateriaUsuario, clvPlanMateriaUsuario, clvUsuarioMateriaUsuario, puntosConfianzaMateriaUsuario, puntosDirectorMateriaUsuario));
        }

        return materiausuario;
    }

    private ObservableList<Materias> getObjectoMaterias() throws SQLException {
        ObservableList<Materias> materias = FXCollections.observableArrayList();
        ArrayList<Materias> arrayMaterias = new ArrayList<Materias>();
        arrayMaterias = cargarTablas.cargarMaterias();

        for (int i = 0; i < arrayMaterias.size(); i++) {
            nombreMateriaMateria = arrayMaterias.get(i).getNombreMateria();
            clvMateriaMateria = arrayMaterias.get(i).getClvMateria();
            creditosMateria = arrayMaterias.get(i).getCreditos();
            cuatrimestreMateria = arrayMaterias.get(i).getCuatrimestre();
            posicionMateria = arrayMaterias.get(i).getPosicion();
            clvPlanMateria = arrayMaterias.get(i).getClvPlan();
            horasXSemanaMateria = arrayMaterias.get(i).getHorasXSemana();
            tipoMateriaMateria = arrayMaterias.get(i).getTipoMateria();

            materias.add(new Materias(nombreMateriaMateria, clvMateriaMateria, creditosMateria, cuatrimestreMateria, posicionMateria, clvPlanMateria, horasXSemanaMateria, tipoMateriaMateria));
        }

        return materias;
    }

    private ObservableList<PlanEstudios> getObjectoPlanEstudios() throws SQLException {
        ObservableList<PlanEstudios> planestudios = FXCollections.observableArrayList();
        ArrayList<PlanEstudios> arrayPlanEstudios = new ArrayList<PlanEstudios>();
        arrayPlanEstudios = cargarTablas.cargarPlanEstudios();

        for (int i = 0; i < arrayPlanEstudios.size(); i++) {
            clvPlanPlanEstudios = arrayPlanEstudios.get(i).getClvPlan();
            nombrePlanPlanEstudios = arrayPlanEstudios.get(i).getNombrePlan();
            nivelPlanEstudios = arrayPlanEstudios.get(i).getNivel();
            idCarreraPlanEstudios = arrayPlanEstudios.get(i).getIdCarrera();

            planestudios.add(new PlanEstudios(clvPlanPlanEstudios, nombrePlanPlanEstudios, nivelPlanEstudios, idCarreraPlanEstudios));
        }

        return planestudios;
    }

    private ObservableList<UsoAulaGrupo> getObjectoUsoAulaGrupo() throws SQLException {
        ObservableList<UsoAulaGrupo> usoaulagrupo = FXCollections.observableArrayList();
        ArrayList<UsoAulaGrupo> arrayUsoAulaGrupo = new ArrayList<UsoAulaGrupo>();
        arrayUsoAulaGrupo = cargarTablas.cargarUsoAulaGrupo();

        for (int i = 0; i < arrayUsoAulaGrupo.size(); i++) {
            diaUsoAulaGrupo = arrayUsoAulaGrupo.get(i).getDia();
            espacioTiempoUsoAulaGrupo = arrayUsoAulaGrupo.get(i).getEspacioTiempo();
            idAulaUsoAulaGrupo = arrayUsoAulaGrupo.get(i).getIdAula();
            clvGrupoUsoAulaGrupo = arrayUsoAulaGrupo.get(i).getClvGrupo();
            clvMateriaUsoAulaGrupo = arrayUsoAulaGrupo.get(i).getClvMateria();

            usoaulagrupo.add(new UsoAulaGrupo(diaUsoAulaGrupo, espacioTiempoUsoAulaGrupo, idAulaUsoAulaGrupo, clvGrupoUsoAulaGrupo, clvMateriaUsoAulaGrupo));
        }

        return usoaulagrupo;
    }

    private ObservableList<Usuarios> getObjectoUsuarios() throws SQLException {
        ObservableList<Usuarios> usuarios = FXCollections.observableArrayList();
        ArrayList<Usuarios> arrayUsuarios = new ArrayList<Usuarios>();
        arrayUsuarios = cargarTablas.cargarUsuarios();

        for (int i = 0; i < arrayUsuarios.size(); i++) {
            clvUsuarioUsuario = arrayUsuarios.get(i).getClvUsuario();
            idCarreraUsuario = arrayUsuarios.get(i).getIdCarrera();
            nombreUsuarioUsuario = arrayUsuarios.get(i).getNombreUsuario();
            nivelAdsUsuario = arrayUsuarios.get(i).getNivelAds();
            contratoUsuario = arrayUsuarios.get(i).getContrato();

            usuarios.add(new Usuarios(clvUsuarioUsuario, idCarreraUsuario, nombreUsuarioUsuario, nivelAdsUsuario, contratoUsuario));
        }

        return usuarios;
    }

    public void Open_aulas() throws SQLException {
        opcion = 2;
        arrayAulas = cargarTablas.cargarAulas();
        app.aulas();
        Stage stage = (Stage) this.btn_aulas.getScene().getWindow();
        stage.close();
    }

    public void Open_carreras() throws SQLException {
        opcion = 3;
        arrayCarrera = cargarTablas.cargarCarrera();
        app.carreras();
        Stage stage = (Stage) this.btn_carreras.getScene().getWindow();
        stage.close();
    }

    public void Open_categorias_equipo() throws SQLException {
        opcion = 4;
        arrayCategoriasEquipo = cargarTablas.cargarCategoriasEquipo();
        app.categorias_equipo();
        Stage stage = (Stage) this.btn_categorias_equipo.getScene().getWindow();
        stage.close();
    }

    public void Open_disponibilidad() throws SQLException {
        opcion = 5;
        arrayDisponibilidad = cargarTablas.cargarDisponibilidad();
        app.disponibilidad();
        Stage stage = (Stage) this.btn_disponibilidad.getScene().getWindow();
        stage.close();
    }

    public void Open_equipo() throws SQLException {
        opcion = 6;
        arrayEquipo = cargarTablas.cargarEquipo();
        app.equipo();
        Stage stage = (Stage) this.btn_equipo.getScene().getWindow();
        stage.close();
    }

    public void Open_grupos() throws SQLException {
        opcion = 7;
        arrayGrupos = cargarTablas.cargarGrupos();
        app.grupos();
        Stage stage = (Stage) this.btn_grupos.getScene().getWindow();
        stage.close();
    }

    public void Open_login() throws SQLException {
        opcion = 9;
        arrayLogin = cargarTablas.cargarLogin();

        app.login();
        Stage stage = (Stage) this.btn_login.getScene().getWindow();
        stage.close();
    }

    public void Open_materia_usuario() throws SQLException {
        opcion = 10;
        arrayMateriaUsuario = cargarTablas.cargarMateriaUsuario();
        app.materia_usuario();
        Stage stage = (Stage) this.btn_materia_usuario.getScene().getWindow();
        stage.close();
    }

    public void Open_materias() throws SQLException {
        opcion = 11;
        arrayMaterias = cargarTablas.cargarMaterias();
        app.materias();
        Stage stage = (Stage) this.btn_materias.getScene().getWindow();
        stage.close();
    }

    public void Open_plan_estudios() throws SQLException {
        opcion = 12;
        arrayPlanEstudios = cargarTablas.cargarPlanEstudios();
        app.plan_estudios();
        Stage stage = (Stage) this.btn_plan_estudios.getScene().getWindow();
        stage.close();
    }

    public void Open_uso_aula_grupo() throws SQLException {
        opcion = 13;
        arrayUsoAulaGrupo = cargarTablas.cargarUsoAulaGrupo();
        app.uso_aula_grupo();
        Stage stage = (Stage) this.btn_uso_aula_grupo.getScene().getWindow();
        stage.close();
    }

    public void Open_usuarios() throws SQLException {
        opcion = 14;
        arrayUsuarios = cargarTablas.cargarUsuarios();
        app.usuarios();
        Stage stage = (Stage) this.btn_usuarios.getScene().getWindow();
        stage.close();
    }

    public void mandarAlCRUD(){
        app.menu();
        Stage stage = (Stage) this.btn_TablasSQL.getScene().getWindow();
        stage.close();
    }

    public void Open_aula_equipos() throws SQLException {

        opcion = 1;
        arrayAulaEquipo = cargarTablas.cargaAulaEquipo();
        app.aula_equipo();
        Stage stage = (Stage) this.btn_aula_equipos.getScene().getWindow();
        stage.close();
    }

    public void Open_grupos_materia_profesor() throws SQLException {
        opcion = 8;
        arrayGruposMateriasProfesor = cargarTablas.cargarGruposMateriasProfesor();
        app.grupos_materias_profesor();
        Stage stage = (Stage) this.btn_grupos_materia_profesor.getScene().getWindow();
        stage.close();
    }

    public void Open_txt(){
        app.txt();
        Stage stage = (Stage) this.btn_txt.getScene().getWindow();
        stage.close();
    }

    public void Open_xlsx(){
        app.xlsx();
        Stage stage = (Stage) this.btn_xlsx.getScene().getWindow();
        stage.close();
    }

    //Botones para regresar al menu principal
    public void volver_aula_equipo() throws SQLException {
        app.menu();
        Stage stage = (Stage) this.btn_volver_aula_equipo.getScene().getWindow();
        stage.close();
    }

    public void volver_aulas(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_aulas.getScene().getWindow();
        stage.close();
    }

    public void volver_carreras(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_carreras.getScene().getWindow();
        stage.close();
    }

    public void volver_categorias_equipo(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_categorias_equipo.getScene().getWindow();
        stage.close();
    }

    public void volver_disponibilidad(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_disponibilidad.getScene().getWindow();
        stage.close();
    }

    public void volver_equipo(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_equipo.getScene().getWindow();
        stage.close();

    }

    public void volver_grupos(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_grupos.getScene().getWindow();
        stage.close();

    }

    public void volver_grupos_materias_profesor(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_grupos_materias_profesor.getScene().getWindow();
        stage.close();
    }

    public void volver_login(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_login.getScene().getWindow();
        stage.close();
    }

    public void volver_materia_usuario(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_materia_usuario.getScene().getWindow();
        stage.close();
    }

    public void volver_materias(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_materias.getScene().getWindow();
        stage.close();
    }

    public void volver_plan_estudios(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_plan_estudios.getScene().getWindow();
        stage.close();
    }

    public void volver_uso_aula_grupo(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_uso_aula_grupo.getScene().getWindow();
        stage.close();
    }

    public void volver_usuarios(){
        app.menu();
        Stage stage = (Stage) this.btn_volver_usuarios.getScene().getWindow();
        stage.close();
    }

    //Botones para agregar a las tablas
    public void agregarNuevoAulaEquipo(){
        ConexionGestor cone = new ConexionGestor();

            boolean existe = false;
            try {

                    existe = compararSiExisteEseDato(cone.conexion(), "aula_equipo", labelidEquipoAE.getText(), 1);

                    if (existe == true) {
                        JOptionPane.showMessageDialog(null, "ERROR ID EQUIPO", "ERROR",JOptionPane.ERROR_MESSAGE);
                    }
                    if (existe == false) {
                        existe = false;
                        existe = compararSiExisteEseDato(cone.conexion(), "equipo", labelidEquipoAE.getText(), 1);
                        if (existe == false) {
                            JOptionPane.showMessageDialog(null, "ERROR ID EQUIPO", "ERROR",JOptionPane.ERROR_MESSAGE);
                            existe = true;
                        } else {
                            existe = false;
                        }
                    }
                    existe = compararSiExisteEseDato(cone.conexion(), "aula_equipo", labelidAulaAE.getText(), 2);
                    if (existe == true) {
                        JOptionPane.showMessageDialog(null, "ERROR ID AULA", "ERROR",JOptionPane.ERROR_MESSAGE);

                    }
                    if (existe == false) {
                        existe = false;
                        existe = compararSiExisteEseDato(cone.conexion(), "aulas", labelidAulaAE.getText(), 1);
                        if (existe == false) {
                            JOptionPane.showMessageDialog(null, "ERROR ID AULA", "ERROR",JOptionPane.ERROR_MESSAGE);
                            existe = true;
                        } else {
                            existe = false;
                        }

                 }

                    System.out.println("INGRESE CANTIDAD DE 1 a 60");
                    if (!labelcantidadAE.getText().matches("^[0-9]*$") || labelcantidadAE.getText().equals("")) {
                        System.out.println("\n");
                        labelcantidadAE.setText("");
                        JOptionPane.showMessageDialog(null, "ERROR CANTIDAD", "ERROR",JOptionPane.ERROR_MESSAGE);

                    } else {
                        if (!(Integer.parseInt(labelcantidadAE.getText()) > 0) || !(Integer.parseInt(labelcantidadAE.getText()) < 61)) {
                            System.out.println("\n");
                            labelcantidadAE.setText("");
                            JOptionPane.showMessageDialog(null, "ERROR CANTIDAD", "ERROR",JOptionPane.ERROR_MESSAGE);

                        }
                    }


                //Aqui manda el conect y los datos que iran en cada una de las columnas
                this.insertarEnAulaEquipoConDatos(cone.conexion(), labelidEquipoAE.getText(), labelidAulaAE.getText(), labelcantidadAE.getText());
                tablaAE.setItems(getObjectoAulaEquipo());
            } catch (Exception e) {
                System.out.println("ERROR AL INSERTAR");

             }


    }

    public void insertarEnAulaEquipoConDatos(Connection conect, String id_equipo, String id_aula, String cantidad) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;
        try {
            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "equipo", id_equipo, 1) == true) {
                if (this.compararSiExisteEseDato(conect, "aulas", id_aula, 1) == true) {
                    s = conect.createStatement();
                    //;
                    ResultSet rs = s.executeQuery("select id_equipo, id_aula from aula_equipo");
                    while (!String.valueOf(rs.next()).equals("false")) {
							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores no sean los mismos que otra fila.
							*/
                        if (rs.getString(1).equals(id_equipo)||rs.getString(2).equals(id_aula)) {
                            registroExistente = true;
                        }
                    }
                    if (registroExistente == false) {
                        insersion = "INSERT INTO `aula_equipo` (`id_equipo`, `id_aula`, `cantidad`) VALUES ('" + id_equipo + "', '" + id_aula + "', '" + cantidad + "');";
                        s.execute(insersion);

                    }

                } else {

                }
            } else {

            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void agregarNuevoAulas(){
        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        try {

            if(!labelIdAulaA.getText().equals("") && !labelNombreA.getText().equals("") && !labelTipoA.getText().equals("") && !labelCapacidadA.getText().equals("")){
                existe = true;

                if (!labelIdAulaA.getText().matches("^[0-9]*$") || labelIdAulaA.getText().equals("")) {
                    labelIdAulaA.setText("");
                    JOptionPane.showMessageDialog(null, "ERROR ID AULA", "ERROR",JOptionPane.ERROR_MESSAGE);

                } else {
                    if (!(Integer.parseInt(labelIdAulaA.getText()) > 0)) {
                        labelIdAulaA.setText("");
                        JOptionPane.showMessageDialog(null, "ERROR ID AULA", "ERROR",JOptionPane.ERROR_MESSAGE);

                    }
                }
                existe = compararSiExisteEseDato(cone.conexion(), "aulas", labelIdAulaA.getText(), 1);
                if (existe == true) {
                    JOptionPane.showMessageDialog(null, "ERROR ID AULA", "ERROR",JOptionPane.ERROR_MESSAGE);
                    labelIdAulaA.setText("");
                }

                if(!labelTipoA.getText().equals("Laboratorio") && !labelTipoA.getText().equals("Salon")){
                    JOptionPane.showMessageDialog(null, "ERROR TIPO AULA", "ERROR",JOptionPane.ERROR_MESSAGE);
                }




                if (!labelCapacidadA.getText().matches("^[0-9]*$") || labelCapacidadA.getText().equals("")) {
                    System.out.println("\n");
                    labelCapacidadA.setText("");
                    JOptionPane.showMessageDialog(null, "ERROR CAPACIDAD", "ERROR",JOptionPane.ERROR_MESSAGE);

                } else {
                    if (!(Integer.parseInt(labelCapacidadA.getText()) > 0) || !(Integer.parseInt(labelCapacidadA.getText()) < 61)) {
                        System.out.println("\n");
                        labelcantidadAE.setText("");
                        JOptionPane.showMessageDialog(null, "ERROR CAPACIDAD", "ERROR",JOptionPane.ERROR_MESSAGE);

                    }
                }

                //Aqui manda el conect y los datos que iran en cada una de las columnas
                this.insertarEnAulasConDatos(cone.conexion(), labelIdAulaA.getText(), labelNombreA.getText(), labelTipoA.getText(), labelCapacidadA.getText());
                tablaA.setItems(getObjectoAulas());

            }

        } catch (Exception e) {

        }
    }

    public void insertarEnAulasConDatos(Connection conect, String id_aula, String nombre, String tipo, String capacidad) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {
            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)

            s = conect.createStatement();
            ResultSet rs = s.executeQuery("select id_aula, nombre, tipo from aulas");
            while (!String.valueOf(rs.next()).equals("false")) {
                /*
					Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
					los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
				*/
                if (rs.getString(1).equals(id_aula)) {
                    registroExistente = true;
                }
            }
            if (registroExistente == false) {
                insersion = "INSERT INTO `aulas` (`id_aula`, `nombre`, `tipo`, `capacidad`) VALUES ('" + id_aula + "', '" + nombre + "', '" + tipo + "', '" + capacidad + "');";
                s.execute(insersion);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void agregarNuevoCarreras(){
        String idCarrera, nombreCarrera;
        idCarrera = lidCarrera.getText();
        nombreCarrera = lnombreCarrera.getText();
        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        int errores=0;
        try {

            existe = compararSiExisteEseDato(cone.conexion(), "carrera", idCarrera, 1);

            if (existe == true) {
                JOptionPane.showMessageDialog(null, "ERROR YA EXISTE ESE ID DE CARRERA", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }

            existe = compararSiExisteEseDato(cone.conexion(), "carrera", nombreCarrera, 2);
            if (existe == true) {
                JOptionPane.showMessageDialog(null, "YA HAY UNA CARRERA CON ESE NOMBRE", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }
            //Aqui manda el conect y los datos que iran en cada una de las columnas
            if(errores==0){
                cru.insertarEnCarreraConDatos(cone.conexion(), idCarrera, nombreCarrera);
                tablaC.setItems(this.getObjectoCarrera());
            }
        } catch (Exception e) {
            System.out.println("ERROR AL INSERTAR");
        }
    }

    public void agregarNuevoCategoriasEquipo(){
        String idCategoria, nombreCategoria, descripcionCategoria;
        idCategoria = tf_idCategoriaCE.getText();
        nombreCategoria = tf_nombreCategoriaCE.getText();
        descripcionCategoria = tf_descripcionCategoriaCE.getText();

        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        int errores=0;
        try {

            existe = compararSiExisteEseDato(cone.conexion(), "categorias_equipo", idCategoria, 1);

            if (existe == true) {
                JOptionPane.showMessageDialog(null, "ERROR YA EXISTE ESE ID DE CATEGORIA EQUIPO", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }

            existe = compararSiExisteEseDato(cone.conexion(), "categorias_equipo", nombreCategoria, 2);
            if (existe == true) {
                JOptionPane.showMessageDialog(null, "YA HAY UNA CATEGORIA EQUIPO CON ESE NOMBRE", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }
            //Aqui manda el conect y los datos que iran en cada una de las columnas
            if(errores==0){
                cru.insertarEnCategoriasEquipoConDatos(cone.conexion(), idCategoria, nombreCategoria, descripcionCategoria);
                tablaCE.setItems(this.getObjectoCategoriasEquipo());
            }
        } catch (Exception e) {
            System.out.println("ERROR AL INSERTAR");
        }
    }

    public void agregarNuevoDisponibilidad(){
        String diaS, espacioTiempoS, clvUsuarioS;
        diaS = tf_diaD.getText();
        espacioTiempoS = tf_espacioTiempoD.getText();
        clvUsuarioS= tf_clvUsuarioD.getText();

        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        int errores=0;
        try {
            //Compara si en la tabla hay ya está el ID que se intenta agregar
            existe = compararSiExisteEseDato(cone.conexion(), "disponibilidad", clvUsuarioS, 3);
            if (existe == true) {
                JOptionPane.showMessageDialog(null, "ERROR YA UN REGISTRO CON ESA CLV DE USUARIO", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            } else {
                /*
                Al ser un valor dependiente de otra tabla (Foranea) el registro debe existir
                en la otra tabla. Por lo que va a comparar si en verdad existe el valor.
                */
                existe = compararSiExisteEseDato(cone.conexion(), "usuarios", clvUsuarioS, 1);
                if (existe == false) {

                    JOptionPane.showMessageDialog(null, "ERROR NO HAY NINGUN USUARIO CON LA CLAVE INGRESADA", "ERROR",JOptionPane.ERROR_MESSAGE);
                    errores++;
                }
            }

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            if(errores==0){
                cru.insertarEnDisponibilidadConDatos(cone.conexion(), diaS, espacioTiempoS, clvUsuarioS);
                tablaD.setItems(this.getObjectoDisponibilidad());
            }
        } catch (Exception e) {
            System.out.println("ERROR AL INSERTAR");
        }
    }

    public void agregarNuevoEquipo(){
        String idEquipo, nombre, descripcion, idCategoria;
        idEquipo = tf_idEquipoE.getText();
        nombre = tf_nombreE.getText();
        descripcion = tf_descripcionE.getText();
        idCategoria = tf_idCategoriaE.getText();

        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        int errores = 0;
        try {
            //Compara si en la tabla hay ya está el ID que se intenta agregar
            existe = compararSiExisteEseDato(cone.conexion(), "equipo", idEquipo, 1);
            if (existe == true) {
                JOptionPane.showMessageDialog(null, "ERROR YA EXISTE UN REGISTRO CON ESA CLV DE EQUIPO", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            } else {
                /*
                Al ser un valor dependiente de otra tabla (Foranea) el registro debe existir
                en la otra tabla. Por lo que va a comparar si en verdad existe el valor.
                */
                existe = compararSiExisteEseDato(cone.conexion(), "categorias_equipo", idCategoria, 1);
                if (existe == false) {

                    JOptionPane.showMessageDialog(null, "ERROR NO HAY NINGUNA CATEGORIA CON LA CLAVE INGRESADA", "ERROR",JOptionPane.ERROR_MESSAGE);
                    errores++;
                } else{
                    existe = false;
                }
            }

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            if(errores==0){
                cru.insertarEnEquipoConDatos(cone.conexion(), idEquipo, nombre, descripcion, idCategoria);
                tablaE.setItems(this.getObjectoEquipo());
            }
        } catch (Exception e) {
            System.out.println("ERROR AL INSERTAR");
        }
    }

    public void agregarNuevoGrupos(){
        String clv_grupo, turno;
        int turnoNum;
        clv_grupo=tf_clvGrupoG.getText();
        turno=tf_turnoG.getText();
        turnoNum=Integer.parseInt(turno);

        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        int errores=0;
        try {

            existe = compararSiExisteEseDato(cone.conexion(), "grupos", clv_grupo, 1);

            if (existe == true) {
                JOptionPane.showMessageDialog(null, "ERROR YA EXISTE UN REGISTRO CON ESA CLAVE", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }
            if (turnoNum<1||turnoNum>2){
                JOptionPane.showMessageDialog(null, "EN TURNO, EL VALOR DEBE SER 1 O 2", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }
            //Aqui manda el conect y los datos que iran en cada una de las columnas
            if(errores==0){
                cru.insertarEnGruposConDatos(cone.conexion(), clv_grupo, turno);
                tablaG.setItems(this.getObjectoGrupos());
            }
        } catch (Exception e) {
            System.out.println("ERROR AL INSERTAR");
        }
    }

    public void agregarNuevoGruposMateriasProfesor(){
        String clv_grupo, clv_materia, clv_usuario;
        clv_grupo=tf_clvGrupoGMP.getText();
        clv_materia=tf_clvMateriaGMP.getText();
        clv_usuario=tf_clvUsuarioGMP.getText();

        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        int errores=0;
        try {

            existe = compararSiExisteEseDato(cone.conexion(), "grupos", clv_grupo, 1);
            if (existe == false){
                JOptionPane.showMessageDialog(null, "ERROR NO EXISTE UN GRUPO CON ESA CLAVE", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }
            existe = compararSiExisteEseDato(cone.conexion(), "materias", clv_materia, 2);
            if (existe == false){
                JOptionPane.showMessageDialog(null, "ERROR NO EXISTE UNA MATERIA CON ESA CLAVE", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }
            existe = compararSiExisteEseDato(cone.conexion(), "usuarios", clv_usuario, 1);
            if (existe == false){
                JOptionPane.showMessageDialog(null, "ERROR NO EXISTE UN USUARIO CON ESA CLAVE", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            if(errores==0){
                cru.insertarEnGrupoMateriaProfesorConDatos(cone.conexion(), clv_grupo, clv_materia, clv_usuario);
                tablaGMP.setItems(this.getObjectoGruposMateriasProfesor());
            }
        } catch (Exception e) {
            System.out.println("ERROR AL INSERTAR");
        }
    }

    public void agregarNuevoLogin(){
        String clv_usuario, pass_usuario, tipo_usuario;
        clv_usuario=tf_clvUsuarioL.getText();
        pass_usuario=tf_passUsuarioL.getText();
        tipo_usuario=tf_tipoUsuarioL.getText();

        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        int errores = 0;
        try {
            //Compara si en la tabla hay ya está el ID que se intenta agregar
            existe = compararSiExisteEseDato(cone.conexion(), "login", clv_usuario, 1);
            if (existe == true) {
                JOptionPane.showMessageDialog(null, "ERROR YA EXISTE UN REGISTRO CON ESA CLV DE USUARIO", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            } else {
                /*
                Al ser un valor dependiente de otra tabla (Foranea) el registro debe existir
                en la otra tabla. Por lo que va a comparar si en verdad existe el valor.
                */
                existe = compararSiExisteEseDato(cone.conexion(), "usuarios", clv_usuario, 1);
                if (existe == false) {

                    JOptionPane.showMessageDialog(null, "ERROR NO HAY NINGUN USUARIO CON LA CLAVE INGRESADA", "ERROR",JOptionPane.ERROR_MESSAGE);
                    errores++;
                }
            }

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            if(errores==0){
                cru.insertarEnLoginConDatos(cone.conexion(), clv_usuario, pass_usuario, tipo_usuario);
                tablaL.setItems(this.getObjectoLogin());
            }
        } catch (Exception e) {
            System.out.println("ERROR AL INSERTAR");
        }
    }

    public void agregarNuevoMateriaUsuario(){
        String clvMateria, clvPlan, clvUsuario, puntosConfianza, puntosDirector;
        clvMateria = tf_clvMateriaMU.getText();
        clvPlan = tf_clvPlanMU.getText();
        clvUsuario = tf_clvUsuarioMU.getText();
        puntosConfianza = tf_puntosConfianzaMU.getText();
        puntosDirector = tf_puntosDirector2MU.getText();

        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        int errores=0;
        try {

            existe = compararSiExisteEseDato(cone.conexion(), "materias", clvMateria, 2);
            if (existe == false) {

                JOptionPane.showMessageDialog(null, "ERROR NO HAY NINGUNA MATERIA CON LA CLAVE INGRESADA", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }
            existe = compararSiExisteEseDato(cone.conexion(), "plan_estudios", clvPlan, 1);
            if (existe == false){
                JOptionPane.showMessageDialog(null, "ERROR NO EXISTE UN PLAN ESTUDIOS CON ESA CLAVE", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }
            existe = compararSiExisteEseDato(cone.conexion(), "usuarios", clvUsuario, 1);
            if (existe == false){
                JOptionPane.showMessageDialog(null, "ERROR NO EXISTE UN USUARIO CON ESA CLAVE", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            }


            //Aqui manda el conect y los datos que iran en cada una de las columnas
            if(errores==0){
                cru.insertarEnMateriaUsuarioConDatos(cone.conexion(), clvMateria, clvPlan, clvUsuario, puntosConfianza, puntosDirector);
                tablaMU.setItems(this.getObjectoMateriaUsuario());
            }
        } catch (Exception e) {
            System.out.println("ERROR AL INSERTAR");
        }
    }

    public void agregarNuevoMaterias(){
        String nombre_materia, clv_materia, creditos, cuatrimestre, posicion, clv_plan, horasXSemana, tipoMateria;
        nombre_materia=tf_nombreMateriaM.getText();
        clv_materia=tf_clvMateriaM.getText();
        creditos=tf_creditosM.getText();
        cuatrimestre=tf_cuatrimestreM.getText();
        posicion=tf_posicionM.getText();
        clv_plan=tf_clvPlanM.getText();
        horasXSemana=tf_horasXSemanaM.getText();
        tipoMateria=tf_tipoMateriaM.getText();

        ConexionGestor cone = new ConexionGestor();

        boolean existe = false;
        int errores = 0;
        try {
            //Compara si en la tabla hay ya está el ID que se intenta agregar
            existe = compararSiExisteEseDato(cone.conexion(), "materias", clv_materia, 2);
            if (existe == true) {
                JOptionPane.showMessageDialog(null, "ERROR YA EXISTE UN REGISTRO CON ESA CLV DE MATERIA", "ERROR",JOptionPane.ERROR_MESSAGE);
                errores++;
            } else {
                /*
                Al ser un valor dependiente de otra tabla (Foranea) el registro debe existir
                en la otra tabla. Por lo que va a comparar si en verdad existe el valor.
                */
                existe = compararSiExisteEseDato(cone.conexion(), "plan_estudios", clv_plan, 1);
                if (existe == false) {

                    JOptionPane.showMessageDialog(null, "ERROR NO HAY NINGUN PLAN CON LA CLAVE INGRESADA", "ERROR",JOptionPane.ERROR_MESSAGE);
                    errores++;
                }
            }

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            if(errores==0){
                cru.insertarEnMateriasConDatos(cone.conexion(), nombre_materia, clv_materia, creditos, cuatrimestre, posicion, clv_plan, horasXSemana, tipoMateria);
                tablaM.setItems(this.getObjectoMaterias());
            }
        } catch (Exception e) {
            System.out.println("ERROR AL INSERTAR");
        }
    }



    //Botones para eliminar registros de las tablas
    public void eliminarRegistroAulaEquipo() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from aula_equipo");

        try{
            AulaEquipo aulaEquipo = tablaAE.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayAulaEquipo = cargarTablas.cargaAulaEquipo();

                for(int i = 0; i < arrayAulaEquipo.size(); i++){
                    if(aulaEquipo.getIdEquipo().equals(arrayAulaEquipo.get(i).getIdEquipo()) && aulaEquipo.getIdAula().equals(arrayAulaEquipo.get(i).getIdAula())){
                        eliminar = "delete from aula_equipo where id_equipo ='"+aulaEquipo.getIdEquipo()+"';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);

                    }
                }


                tablaAE.setItems(getObjectoAulaEquipo());


            }



        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroAulas() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from aulas");

        try{
            Aulas aulas = tablaA.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayAulas = cargarTablas.cargarAulas();

                for (int i = 0; i < arrayAulas.size(); i++) {
                    if (aulas.getIdAula().equals(arrayAulas.get(i).getIdAula()) && aulas.getNombre().equals(arrayAulas.get(i).getNombre())) {
                        eliminar = "delete from aulas where id_aula ='" + aulas.getIdAula() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaA.setItems(getObjectoAulas());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroCarreras() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from carrera");

        try{
            Carrera carrera = tablaC.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayCarrera = cargarTablas.cargarCarrera();

                for (int i = 0; i < arrayCarrera.size(); i++) {
                    if (carrera.getIdCarrera().equals(arrayCarrera.get(i).getIdCarrera()) && carrera.getNombreCarrera().equals(arrayCarrera.get(i).getNombreCarrera())) {
                        eliminar = "delete from carrera where idcarrera ='" + carrera.getIdCarrera() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaC.setItems(getObjectoCarrera());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroCategoriasEquipo() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from categorias_equipo");

        try{
            CategoriasEquipo categoriasEquipo = tablaCE.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayCategoriasEquipo = cargarTablas.cargarCategoriasEquipo();

                for (int i = 0; i < arrayCategoriasEquipo.size(); i++) {
                    if (categoriasEquipo.getIdCategoria().equals(arrayCategoriasEquipo.get(i).getIdCategoria()) && categoriasEquipo.getNombreCategoria().equals(arrayCategoriasEquipo.get(i).getNombreCategoria())) {
                        eliminar = "delete from categorias_equipo where id_categoria ='" + categoriasEquipo.getIdCategoria() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaCE.setItems(getObjectoCategoriasEquipo());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroDisponibilidad() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from disponibilidad");

        try{
            Disponibilidad disponibilidad = tablaD.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayDisponibilidad = cargarTablas.cargarDisponibilidad();

                for (int i = 0; i < arrayDisponibilidad.size(); i++) {
                    if (disponibilidad.getClvUsuario().equals(arrayDisponibilidad.get(i).getClvUsuario())) {
                        eliminar = "delete from disponibilidad where clv_usuario ='" + disponibilidad.getClvUsuario() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaD.setItems(getObjectoDisponibilidad());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroEquipo() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from equipo");

        try{
            Equipo equipo = tablaE.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayEquipo = cargarTablas.cargarEquipo();

                for (int i = 0; i < arrayEquipo.size(); i++) {
                    if (equipo.getIdEquipo().equals(arrayEquipo.get(i).getIdEquipo())) {
                        eliminar = "delete from equipo where id_equipo ='" + equipo.getIdEquipo() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaE.setItems(getObjectoEquipo());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroGrupos() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from grupos");

        try{
            Grupos grupos = tablaG.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayGrupos = cargarTablas.cargarGrupos();

                for (int i = 0; i < arrayGrupos.size(); i++) {
                    if (grupos.getClvGrupo().equals(arrayGrupos.get(i).getClvGrupo())) {
                        eliminar = "delete from grupos where clv_grupo ='" + grupos.getClvGrupo() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaG.setItems(getObjectoGrupos());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroGruposMateriasProfesor() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from grupo_materia_profesor");

        try{
            GruposMateriasProfesor gruposMateriasProfesor = tablaGMP.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayGruposMateriasProfesor = cargarTablas.cargarGruposMateriasProfesor();

                for (int i = 0; i < arrayGruposMateriasProfesor.size(); i++) {
                    if (gruposMateriasProfesor.getClvGrupo().equals(arrayGruposMateriasProfesor.get(i).getClvGrupo()) && gruposMateriasProfesor.getClvMateria().equals(arrayGruposMateriasProfesor.get(i).getClvMateria()) && gruposMateriasProfesor.getClvUsuario().equals(arrayGruposMateriasProfesor.get(i).getClvUsuario())) {
                        eliminar = "delete from grupo_materia_profesor where clv_grupo ='" + gruposMateriasProfesor.getClvGrupo() + "'and clv_materia ='"+ gruposMateriasProfesor.getClvMateria() +"'and clv_usuario ='"+ gruposMateriasProfesor.getClvUsuario() +"';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaGMP.setItems(getObjectoGruposMateriasProfesor());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroLogin() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from login");

        try{
            Login login = tablaL.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayLogin = cargarTablas.cargarLogin();

                for (int i = 0; i < arrayLogin.size(); i++) {
                    if (login.getClvUsuario().equals(arrayLogin.get(i).getClvUsuario())) {
                        eliminar = "delete from login where clv_usuario ='" + login.getClvUsuario() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaL.setItems(getObjectoLogin());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroMateriaUsuario() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from materia_usuario");

        try{
            MateriaUsuario materiaUsuario = tablaMU.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayMateriaUsuario = cargarTablas.cargarMateriaUsuario();

                for (int i = 0; i < arrayMateriaUsuario.size(); i++) {
                    if (materiaUsuario.getClvMateria().equals(arrayMateriaUsuario.get(i).getClvMateria()) && materiaUsuario.getClvPlan().equals(arrayMateriaUsuario.get(i).getClvPlan()) && materiaUsuario.getClvUsuario().equals(arrayMateriaUsuario.get(i).getClvUsuario())) {
                        eliminar = "delete from materia_usuario where clv_materia ='" + materiaUsuario.getClvMateria() + "'and clv_plan ='"+ materiaUsuario.getClvPlan() +"'and clv_usuario ='"+ materiaUsuario.getClvUsuario() +"';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaMU.setItems(getObjectoMateriaUsuario());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroMaterias() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from materias");

        try{
            Materias materias = tablaM.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayMaterias = cargarTablas.cargarMaterias();

                for (int i = 0; i < arrayMaterias.size(); i++) {
                    if (materias.getClvMateria().equals(arrayMaterias.get(i).getClvMateria())) {
                        eliminar = "delete from materias where clv_materia ='" + materias.getClvMateria() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaM.setItems(getObjectoMaterias());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroPlanEstudios() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from plan_estudios");

        try{
            PlanEstudios planEstudios = tablaPE.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayPlanEstudios = cargarTablas.cargarPlanEstudios();

                for (int i = 0; i < arrayPlanEstudios.size(); i++) {
                    if (planEstudios.getClvPlan().equals(arrayPlanEstudios.get(i).getClvPlan())) {
                        eliminar = "delete from plan_estudios where clv_plan ='" + planEstudios.getClvPlan() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaPE.setItems(getObjectoPlanEstudios());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroUsoAulaGrupo() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from uso_aula_grupo");

        try{
            UsoAulaGrupo usoAulaGrupo = tablaUAG.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayUsoAulaGrupo = cargarTablas.cargarUsoAulaGrupo();

                for (int i = 0; i < arrayUsoAulaGrupo.size(); i++) {
                    if (usoAulaGrupo.getIdAula().equals(arrayUsoAulaGrupo.get(i).getIdAula()) && usoAulaGrupo.getClvGrupo().equals(arrayUsoAulaGrupo.get(i).getClvGrupo()) && usoAulaGrupo.getClvMateria().equals(arrayUsoAulaGrupo.get(i).getClvMateria())) {
                        eliminar = "delete from uso_aula_grupo where id_aula ='" + usoAulaGrupo.getIdAula() + "'and clv_grupo ='"+ usoAulaGrupo.getClvGrupo() +"'and clv_materia ='"+ usoAulaGrupo.getClvMateria() +"';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaUAG.setItems(getObjectoUsoAulaGrupo());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }

    public void eliminarRegistroUsuarios() throws SQLException {
        String eliminar = "";

        int Opcion = JOptionPane.YES_NO_OPTION;
        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from usuarios");

        try{
            Usuarios usuarios = tablaU.getSelectionModel().getSelectedItem();
            if(JOptionPane.showConfirmDialog(null,"¿Desea eliminar?","Eliminar",Opcion)==0) {
                arrayUsuarios = cargarTablas.cargarUsuarios();

                for (int i = 0; i < arrayUsuarios.size(); i++) {
                    if (usuarios.getClvUsuario().equals(arrayUsuarios.get(i).getClvUsuario())) {
                        eliminar = "delete from usuarios where clv_usuario ='" + usuarios.getClvUsuario() + "';";
                        s.executeUpdate(eliminar);
                        JOptionPane.showMessageDialog(null, "ELIMINAR", "SE ELIMINO CORRECTAMENTE", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                tablaU.setItems(getObjectoUsuarios());
            }
        }catch(Exception e){
            System.out.println("No has seleccionado nada");
        }
    }


    //Botones para modificar registros de las tablas

    public void seleccionarRegistroAulaEquipo() throws SQLException {
        AulaEquipo aulaEquipo = tablaAE.getSelectionModel().getSelectedItem();
        arrayAulaEquipo = cargarTablas.cargaAulaEquipo();

        try{
            for(int i = 0; i < arrayAulaEquipo.size(); i++) {
                if (aulaEquipo.getIdEquipo().equals(arrayAulaEquipo.get(i).getIdEquipo())) {
                    modificarIdEquipoAE.setText(aulaEquipo.getIdEquipo());
                    modificarIdAulaAE.setText(aulaEquipo.getIdAula());
                    modificarCantidadAE.setText(aulaEquipo.getCantidad());
                }
            }
        }catch (Exception e){

        }

    }

    public void modificarRegistroAulaEquipo() throws SQLException {
        AulaEquipo aulaEquipo = tablaAE.getSelectionModel().getSelectedItem();
        arrayAulaEquipo = cargarTablas.cargaAulaEquipo();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from aula_equipo");
        String modificar;
        try{
            for(int i = 0; i < arrayAulaEquipo.size(); i++){
                if(aulaEquipo.getIdEquipo().equals(arrayAulaEquipo.get(i).getIdEquipo()) && !modificarIdEquipoAE.getText().equals("") && !modificarIdAulaAE.getText().equals("") && !modificarCantidadAE.getText().equals("")){
                    try{
                        modificar = "UPDATE aula_equipo"+" set id_equipo"+"='"+modificarIdEquipoAE.getText()+"', id_aula"+"='"+modificarIdAulaAE.getText()+"', cantidad"+"='"+modificarCantidadAE.getText()+"' WHERE id_equipo" +"='"+aulaEquipo.getIdEquipo()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }

            tablaAE.setItems(getObjectoAulaEquipo());
        }catch (Exception e){

        }



    }

    public void seleccionarRegistroAulas() throws SQLException {
        Aulas aulas = tablaA.getSelectionModel().getSelectedItem();
        arrayAulas = cargarTablas.cargarAulas();

        try{
            for(int i = 0; i < arrayAulas.size(); i++) {
                if (aulas.getIdAula().equals(arrayAulas.get(i).getIdAula())) {
                    modificarIdAulaA.setText(aulas.getIdAula());
                    modificarNombreA.setText(aulas.getNombre());
                    modificarTipoA.setText(aulas.getTipo());
                    modificarCapacidadA.setText(aulas.getCapacidad());


                }
            }
        }catch (Exception e){

        }

    }

    public void modificarRegistroAulas() throws SQLException {
        Aulas aulas = tablaA.getSelectionModel().getSelectedItem();
        arrayAulas = cargarTablas.cargarAulas();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from aulas");
        String modificar;


        try{
            for(int i = 0; i < arrayAulas.size(); i++){
                if(aulas.getIdAula().equals(arrayAulas.get(i).getIdAula()) && !modificarIdAulaA.getText().equals("") && !modificarNombreA.getText().equals("") && !modificarTipoA.getText().equals("")&&!modificarCapacidadA.getText().equals("")){
                    try{
                        modificar = "UPDATE aulas"+" set id_aula"+"='"+modificarIdAulaA.getText()+"', nombre"+"='"+modificarNombreA.getText()+"', tipo"+"='"+modificarTipoA.getText()+"', capacidad"+"='"+modificarCapacidadA.getText()+"' WHERE id_aula" +"='"+aulas.getIdAula()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }

            tablaA.setItems(getObjectoAulas());
        }catch (Exception e){

        }


    }

    public void seleccionarRegistroCarreras() throws SQLException {
        Carrera carrera = tablaC.getSelectionModel().getSelectedItem();
        arrayCarrera = cargarTablas.cargarCarrera();

        try{
            for(int i = 0; i < arrayCarrera.size(); i++) {
                if (carrera.getIdCarrera().equals(arrayCarrera.get(i).getIdCarrera())) {
                    modificarIdCarreraC.setText(carrera.getIdCarrera());
                    modificarNombreCarreraC.setText(carrera.getNombreCarrera());
                }
            }
        }catch (Exception e){

        }

    }

    public void modificarRegistroCarrera() throws SQLException {
        Carrera carrera = tablaC.getSelectionModel().getSelectedItem();
        arrayCarrera = cargarTablas.cargarCarrera();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from carrera");
        String modificar;

        try{
            for(int i = 0; i < arrayCarrera.size(); i++){
                if(carrera.getIdCarrera().equals(arrayCarrera.get(i).getIdCarrera()) && !modificarNombreCarreraC.getText().equals("")){
                    try{
                        modificar = "UPDATE carrera"+" set idcarrera"+"='"+modificarIdCarreraC.getText()+"', nombre_carrera"+"='"+modificarNombreCarreraC.getText()+"' WHERE idcarrera" +"='"+carrera.getIdCarrera()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }

            tablaC.setItems(getObjectoCarrera());
        }catch (Exception e){

        }


    }

    public void seleccionarCategoriaEquipo() throws SQLException {
        CategoriasEquipo categoriasEquipo = tablaCE.getSelectionModel().getSelectedItem();
        arrayCategoriasEquipo = cargarTablas.cargarCategoriasEquipo();
        try{
            for(int i = 0; i < arrayCategoriasEquipo.size(); i++) {
                if (categoriasEquipo.getIdCategoria().equals(arrayCategoriasEquipo.get(i).getIdCategoria())) {
                    modificarIdCategoriaCE.setText(categoriasEquipo.getIdCategoria());
                    modificarNombreCategoriaCE.setText(categoriasEquipo.getNombreCategoria());
                    modificarDescripcionCategoriaCE.setText(categoriasEquipo.getDescripcionCategoria());


                }
            }
        }catch (Exception e){

        }

    }

    public void modificarRegistroCategoriaEquipo() throws SQLException {
        CategoriasEquipo categoriasEquipo = tablaCE.getSelectionModel().getSelectedItem();
        arrayCategoriasEquipo = cargarTablas.cargarCategoriasEquipo();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from categorias_equipo");
        String modificar;

        try{
            for(int i = 0; i < arrayCategoriasEquipo.size(); i++){
                if(categoriasEquipo.getIdCategoria().equals(arrayCategoriasEquipo.get(i).getIdCategoria()) && !modificarIdCategoriaCE.getText().equals("") && !modificarNombreCategoriaCE.equals("") && !modificarDescripcionCategoriaCE.equals("")){
                    try{
                        modificar = "UPDATE categorias_equipo"+" set id_categoria"+"='"+modificarIdCategoriaCE.getText()+"', nombre_categoria"+"='"+modificarNombreCategoriaCE.getText()+"', descripcion_categoria"+"='"+modificarDescripcionCategoriaCE.getText()+"' WHERE id_categoria" +"='"+categoriasEquipo.getIdCategoria()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }

            tablaCE.setItems(getObjectoCategoriasEquipo());
        }catch (Exception e){

        }


    }

    public void seleccionarDisponibilidad() throws SQLException {
        Disponibilidad disponibilidad = tablaD.getSelectionModel().getSelectedItem();
        arrayDisponibilidad = cargarTablas.cargarDisponibilidad();
        try{
            for(int i = 0; i < arrayDisponibilidad.size(); i++) {
                if (disponibilidad.getDia().equals(arrayDisponibilidad.get(i).getDia()) && disponibilidad.getEspacioTiempo().equals(arrayDisponibilidad.get(i).getEspacioTiempo()) && disponibilidad.getClvUsuario().equals(arrayDisponibilidad.get(i).getClvUsuario())) {
                    modificarDiaD.setText(disponibilidad.getDia());
                    modificarEspacioTiempoD.setText(disponibilidad.getEspacioTiempo());
                    modificarClvUsuarioD.setText(disponibilidad.getClvUsuario());
                }
            }
        }catch (Exception e){

        }

    }

    public void modificarRegistroDisponibilidad() throws SQLException {
        Disponibilidad disponibilidad = tablaD.getSelectionModel().getSelectedItem();
        arrayDisponibilidad = cargarTablas.cargarDisponibilidad();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from disponibilidad");
        String modificar;

        try{
            for(int i = 0; i < arrayDisponibilidad.size(); i++){
                if(disponibilidad.getDia().equals(arrayDisponibilidad.get(i).getDia()) && disponibilidad.getClvUsuario().equals(arrayDisponibilidad.get(i).getClvUsuario()) && !modificarDiaD.getText().equals("") && !modificarEspacioTiempoD.equals("") && !modificarClvUsuarioD.equals("")){
                    try{
                        modificar = "UPDATE disponibilidad"+" set dia"+"='"+modificarDiaD.getText()+"', espacio_tiempo"+"='"+modificarEspacioTiempoD.getText()+"', clv_usuario"+"='"+modificarClvUsuarioD.getText()+"' WHERE clv_usuario" +"='"+disponibilidad.getClvUsuario()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }

            tablaD.setItems(getObjectoDisponibilidad());
        }catch (Exception e){

        }


    }

    public void seleccionarEquipo() throws SQLException {
        Equipo equipo = tablaE.getSelectionModel().getSelectedItem();
        arrayEquipo = cargarTablas.cargarEquipo();
        try{
            for(int i = 0; i < arrayEquipo.size(); i++) {
                if (equipo.getIdEquipo().equals(arrayEquipo.get(i).getIdEquipo())) {
                    modificarIdEquipoE.setText(equipo.getIdEquipo());
                    modificarNombreE.setText(equipo.getNombre());
                    modificarDescripcionE.setText(equipo.getDescripcion());
                    modificarIdCategoriaE.setText(equipo.getIdEquipo());
                }
            }
        }catch (Exception e){

        }

    }

    public void modificarRegistroEquipo() throws SQLException {
        Equipo equipo = tablaE.getSelectionModel().getSelectedItem();
        arrayEquipo = cargarTablas.cargarEquipo();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from equipo");
        String modificar;

        try{
            for(int i = 0; i < arrayEquipo.size(); i++){
                if(equipo.getIdEquipo().equals(arrayEquipo.get(i).getIdEquipo()) && !modificarIdEquipoE.getText().equals("") && !modificarNombreE.equals("") && !modificarDescripcionE.equals("") && !modificarIdCategoriaE.equals("")){
                    try{
                        modificar = "UPDATE equipo"+" set id_equipo"+"='"+modificarIdEquipoE.getText()+"', nombre"+"='"+modificarNombreE.getText()+"', descripcion"+"='"+modificarDescripcionE.getText()+"', id_categoria"+"='"+modificarIdCategoriaE.getText()+"' WHERE id_equipo" +"='"+equipo.getIdEquipo()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
            tablaE.setItems(getObjectoEquipo());
        }catch (Exception e){
        }
    }

    public void seleccionarGrupos() throws SQLException {
        Grupos grupos = tablaG.getSelectionModel().getSelectedItem();
        arrayGrupos = cargarTablas.cargarGrupos();



        try{
            for(int i = 0; i < arrayGrupos.size(); i++) {
                if (grupos.getClvGrupo().equals(arrayGrupos.get(i).getClvGrupo())&& grupos.getTurno().equals(arrayGrupos.get(i).getTurno())) {
                    modificarClvGrupoG.setText(grupos.getClvGrupo());
                    modificarTurnoG.setText(grupos.getTurno());

                }
            }
        }catch (Exception e){

        }

    }

    public void modificarRegistroGrupos() throws SQLException {
        Grupos grupos = tablaG.getSelectionModel().getSelectedItem();
        arrayGrupos = cargarTablas.cargarGrupos();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from grupos");
        String modificar;




        try{
            for(int i = 0; i < arrayGrupos.size(); i++){

                if(grupos.getClvGrupo().equals(arrayGrupos.get(i).getClvGrupo())&&!modificarClvGrupoG.getText().equals("") && !modificarTurnoG.equals("")){

                    try{

                        modificar = "UPDATE grupos"+" set clv_grupo"+"='"+modificarClvGrupoG.getText()+"', turno"+"='"+modificarTurnoG.getText()+"' WHERE clv_grupo" +"='"+grupos.getClvGrupo()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
            tablaG.setItems(getObjectoGrupos());
        }catch (Exception e){
        }
    }

    public void seleccionarGruposMateriasProfesor() throws SQLException {
        GruposMateriasProfesor gruposMateriasProfesor = tablaGMP.getSelectionModel().getSelectedItem();
        arrayGruposMateriasProfesor = cargarTablas.cargarGruposMateriasProfesor();



        try{
            for(int i = 0; i < arrayGruposMateriasProfesor.size(); i++) {
                if (gruposMateriasProfesor.getClvGrupo().equals(arrayGruposMateriasProfesor.get(i).getClvGrupo())&& gruposMateriasProfesor.getClvMateria().equals(arrayGruposMateriasProfesor.get(i).getClvMateria())) {
                    modificarClvGrupoGMP.setText(gruposMateriasProfesor.getClvGrupo());
                    modificarClvMateriaGMP.setText(gruposMateriasProfesor.getClvMateria());
                    modificarClvUsuarioGMP.setText(gruposMateriasProfesor.getClvUsuario());

                }
            }
        }catch (Exception e){

        }

    }

    public void modificarRegistroGruposMateriasProfesor() throws SQLException {
        GruposMateriasProfesor gruposMateriasProfesor = tablaGMP.getSelectionModel().getSelectedItem();
        arrayGruposMateriasProfesor = cargarTablas.cargarGruposMateriasProfesor();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from grupo_materia_profesor");
        String modificar;




        try{
            for(int i = 0; i < arrayGruposMateriasProfesor.size(); i++){

                if(gruposMateriasProfesor.getClvGrupo().equals(arrayGruposMateriasProfesor.get(i).getClvGrupo())&&!modificarClvMateriaGMP.getText().equals("") && !modificarClvUsuarioGMP.equals("")){

                    try{

                        modificar = "UPDATE grupo_materia_profesor"+" set clv_grupo"+"='"+modificarClvGrupoGMP.getText()+"', clv_materia"+"='"+modificarClvMateriaGMP.getText()+"', clv_usuario"+"='"+modificarClvUsuarioGMP.getText()+"' WHERE clv_grupo" +"='"+gruposMateriasProfesor.getClvGrupo()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
            tablaGMP.setItems(getObjectoGruposMateriasProfesor());
        }catch (Exception e){
        }
    }

    public void seleccionarLogin() throws SQLException {
        Login login = tablaL.getSelectionModel().getSelectedItem();
        arrayLogin = cargarTablas.cargarLogin();



        try{
            for(int i = 0; i < arrayLogin.size(); i++) {
                if (login.getClvUsuario().equals(arrayLogin.get(i).getClvUsuario())) {
                    modificarClvUsuarioL.setText(login.getClvUsuario());
                    modificarPassUsuarioL.setText(login.getPassUsuario());
                    modificarTipoUsuarioL.setText(login.getTipoUsuario());
                }
            }
        }catch (Exception e){

        }

    }

    public void modificarRegistroLogin() throws SQLException {
        Login login = tablaL.getSelectionModel().getSelectedItem();
        arrayLogin = cargarTablas.cargarLogin();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from login");
        String modificar;




        try{
            for(int i = 0; i < arrayLogin.size(); i++){

                if(login.getClvUsuario().equals(arrayLogin.get(i).getClvUsuario())&&!modificarClvUsuarioL.getText().equals("") && !modificarPassUsuarioL.equals("")&& !modificarTipoUsuarioL.equals("") && (modificarTipoUsuarioL.getText().equals("DIRE") || modificarTipoUsuarioL.getText().equals("PROF"))){

                    try{

                        modificar = "UPDATE login"+" set clv_usuario"+"='"+modificarClvUsuarioL.getText()+"', pass_usuario"+"='"+modificarPassUsuarioL.getText()+"', tipo_usuario"+"='"+modificarTipoUsuarioL.getText()+"' WHERE clv_usuario" +"='"+login.getClvUsuario()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
            tablaL.setItems(getObjectoLogin());
        }catch (Exception e){
        }
    }

    public void seleccionarMateriaUsuario() throws SQLException {
        MateriaUsuario materiaUsuario = tablaMU.getSelectionModel().getSelectedItem();
        arrayMateriaUsuario = cargarTablas.cargarMateriaUsuario();



        try{
            for(int i = 0; i < arrayMateriaUsuario.size(); i++) {
                if (materiaUsuario.getClvMateria().equals(arrayMateriaUsuario.get(i).getClvMateria())&&materiaUsuario.getClvUsuario().equals(arrayMateriaUsuario.get(i).getClvUsuario())) {
                    modificarClvMateriaMU.setText(materiaUsuario.getClvMateria());
                    modificarClvPlanMU.setText(materiaUsuario.getClvPlan());
                    modificarClvUsuarioMU.setText(materiaUsuario.getClvUsuario());
                    modificarPuntosConfianzaMU.setText(materiaUsuario.getPuntosConfianza());
                    modificarPuntosDirectorMU.setText(materiaUsuario.getPuntosDirector());

                }
            }
        }catch (Exception e){

        }
    }

    public void modificarRegistroMateriaUsuario() throws SQLException {
        MateriaUsuario materiaUsuario = tablaMU.getSelectionModel().getSelectedItem();
        arrayMateriaUsuario = cargarTablas.cargarMateriaUsuario();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from materia_usuario");
        String modificar;




        try{
            for(int i = 0; i < arrayMateriaUsuario.size(); i++){

                if(materiaUsuario.getClvMateria().equals(arrayMateriaUsuario.get(i).getClvMateria())&& materiaUsuario.getClvPlan().equals(arrayMateriaUsuario.get(i).getClvPlan())&&materiaUsuario.getClvPlan().equals(arrayMateriaUsuario.get(i).getClvPlan()) && !modificarClvUsuarioMU.getText().equals("")&& !modificarPuntosConfianzaMU.getText().equals("") && !modificarPuntosDirectorMU.getText().equals("")){

                    try{

                        modificar = "UPDATE materia_usuario"+" set clv_materia"+"='"+modificarClvMateriaMU.getText()+"', clv_plan"+"='"+modificarClvPlanMU.getText()+"', clv_usuario"+"='"+modificarClvUsuarioMU.getText()+"', puntos_confianza"+"='"+modificarPuntosConfianzaMU.getText()+"', puntos_director"+"='"+modificarPuntosDirectorMU.getText()+"' WHERE clv_materia" +"='"+materiaUsuario.getClvMateria()+"' AND clv_usuario"+"='"+materiaUsuario.getClvUsuario()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
            tablaMU.setItems(getObjectoMateriaUsuario());
        }catch (Exception e){
        }
    }

    public void seleccionarMaterias() throws SQLException {
        Materias materias = tablaM.getSelectionModel().getSelectedItem();
        arrayMaterias = cargarTablas.cargarMaterias();

        try{
            for(int i = 0; i < arrayMaterias.size(); i++) {
                if (materias.getClvMateria().equals(arrayMaterias.get(i).getClvMateria())) {
                    modificarNombreMateriaM.setText(materias.getNombreMateria());
                    modificarClvMateriaM.setText(materias.getClvMateria());
                    modificarCreditosM.setText(materias.getCreditos());
                    modificarCuatrimestreM.setText(materias.getCuatrimestre());
                    modificarPosicionM.setText(materias.getPosicion());
                    modificarClvPlanM.setText(materias.getClvPlan());
                    modificarHoraXSemanaM.setText(materias.getHorasXSemana());
                    modificarTipoMateriaM.setText(materias.getTipoMateria());

                }
            }
        }catch (Exception e){

        }
    }

    public void modificarRegistroMaterias() throws SQLException {
        Materias materias = tablaM.getSelectionModel().getSelectedItem();
        arrayMaterias = cargarTablas.cargarMaterias();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from materias");
        String modificar;

        try{
            for(int i = 0; i < arrayMaterias.size(); i++){

                if(materias.getClvMateria().equals(arrayMaterias.get(i).getClvMateria()) && !modificarNombreMateriaM.getText().equals("") && !modificarCreditosM.getText().equals("") && !modificarCuatrimestreM.getText().equals("") && !modificarPosicionM.getText().equals("") && !modificarClvPlanM.getText().equals("") && !modificarHoraXSemanaM.getText().equals("") && !modificarTipoMateriaM.getText().equals("")){
                    System.out.println("ola");
                    try{

                        modificar = "UPDATE materias"+" set nombre_materia"+"='"+modificarNombreMateriaM.getText()+"', clv_materia"+"='"+modificarClvMateriaM.getText()+"', creditos"+"='"+modificarCreditosM.getText()+"', cuatrimestre"+"='"+modificarCuatrimestreM.getText()+"', posicion"+"='"+modificarPosicionM.getText()+"', clv_plan"+"='"+modificarClvPlanM.getText()+"', horas_x_semana"+"='"+modificarHoraXSemanaM.getText()+"', tipo_materia"+"='"+modificarTipoMateriaM.getText()+"' WHERE clv_materia" +"='"+materias.getClvMateria()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
            tablaM.setItems(getObjectoMaterias());
        }catch (Exception e){
        }
    }

    public void seleccionarPlanEstudios() throws SQLException {
        PlanEstudios planEstudios = tablaPE.getSelectionModel().getSelectedItem();
        arrayPlanEstudios = cargarTablas.cargarPlanEstudios();

        try{
            for(int i = 0; i < arrayPlanEstudios.size(); i++) {
                if (planEstudios.getClvPlan().equals(arrayPlanEstudios.get(i).getClvPlan())) {
                    modificarClvPlanPE.setText(planEstudios.getClvPlan());
                    modificarNombrePlanPE.setText(planEstudios.getNombrePlan());
                    modificarNivelPE.setText(planEstudios.getNivel());
                    modificarIdCarreraPE.setText(planEstudios.getIdCarrera());


                }
            }
        }catch (Exception e){

        }
    }

    public void modificarRegistroPlanEstudios() throws SQLException {
        PlanEstudios planEstudios = tablaPE.getSelectionModel().getSelectedItem();
        arrayPlanEstudios = cargarTablas.cargarPlanEstudios();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from plan_estudios");
        String modificar;




        try{
            for(int i = 0; i < arrayPlanEstudios.size(); i++){

                if(planEstudios.getClvPlan().equals(arrayPlanEstudios.get(i).getClvPlan())&& !modificarNombrePlanPE.getText().equals("")&& !modificarNivelPE.getText().equals("") && !modificarIdCarreraPE.getText().equals("")){

                    try{
                        modificar = "UPDATE plan_estudios"+" set clv_plan"+"='"+modificarClvPlanPE.getText()+"', nombre_plan"+"='"+modificarNombrePlanPE.getText()+"', nivel"+"='"+modificarNivelPE.getText()+"', idcarrera"+"='"+modificarIdCarreraPE.getText()+"' WHERE clv_plan" +"='"+planEstudios.getClvPlan()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
            tablaPE.setItems(getObjectoPlanEstudios());
        }catch (Exception e){
        }
    }

    public void seleccionarUsoAulaGrupo() throws SQLException {
        UsoAulaGrupo usoAulaGrupo = tablaUAG.getSelectionModel().getSelectedItem();
        arrayUsoAulaGrupo = cargarTablas.cargarUsoAulaGrupo();

        try{
            for(int i = 0; i < arrayUsoAulaGrupo.size(); i++) {
                if (usoAulaGrupo.getIdAula().equals(arrayUsoAulaGrupo.get(i).getIdAula()) && usoAulaGrupo.getClvGrupo().equals(arrayUsoAulaGrupo.get(i).getClvGrupo())) {
                    modificarDiaUAG.setText(usoAulaGrupo.getDia());
                    modificarEspacioTiempoUAG.setText(usoAulaGrupo.getEspacioTiempo());
                    modificarIdAulaUAG.setText(usoAulaGrupo.getIdAula());
                    modificarClvGrupoUAG.setText(usoAulaGrupo.getClvGrupo());
                    modificarClvMateriaUAG.setText(usoAulaGrupo.getClvMateria());
                }
            }
        }catch (Exception e){
        }
    }

    public void modificarRegistroUsoAulaGrupo() throws SQLException {
        UsoAulaGrupo usoAulaGrupo = tablaUAG.getSelectionModel().getSelectedItem();
        arrayUsoAulaGrupo = cargarTablas.cargarUsoAulaGrupo();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from uso_aula_grupo");
        String modificar;

        try{
            for(int i = 0; i < arrayUsoAulaGrupo.size(); i++){
                if (usoAulaGrupo.getIdAula().equals(arrayUsoAulaGrupo.get(i).getIdAula()) && usoAulaGrupo.getClvGrupo().equals(arrayUsoAulaGrupo.get(i).getClvGrupo()) && !modificarDiaUAG.getText().equals("") && !modificarEspacioTiempoUAG.getText().equals("") && !modificarClvMateriaUAG.getText().equals("")) {
                    try{
                        modificar = "UPDATE uso_aula_grupo"+" set dia"+"='"+modificarDiaUAG.getText()+"', espacio_tiempo"+"='"+modificarEspacioTiempoUAG.getText()+"', id_aula"+"='"+modificarIdAulaUAG.getText()+"', clv_grupo"+"='"+modificarClvGrupoUAG.getText()+"', clv_materia"+"='"+modificarClvMateriaUAG.getText()+"' WHERE id_aula" +"='"+usoAulaGrupo.getIdAula()+"' AND clv_grupo"+"='"+usoAulaGrupo.getClvGrupo()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
            tablaUAG.setItems(getObjectoUsoAulaGrupo());
        }catch (Exception e){
        }
    }

    public void seleccionarUsuarios() throws SQLException {
        Usuarios usuarios = tablaU.getSelectionModel().getSelectedItem();
        arrayUsuarios = cargarTablas.cargarUsuarios();

        try{
            for(int i = 0; i < arrayUsuarios.size(); i++) {
                if (usuarios.getClvUsuario().equals(arrayUsuarios.get(i).getClvUsuario())) {
                    modificarClvUsuarioU.setText(usuarios.getClvUsuario());
                    modificarIdCarreraU.setText(usuarios.getIdCarrera());
                    modificarNombreUsuarioU.setText(usuarios.getNombreUsuario());
                    modificarNivelAdsU.setText(usuarios.getNivelAds());
                    modificarContratoU.setText(usuarios.getContrato());
                }
            }
        }catch (Exception e){
        }
    }

    public void modificarRegistroUsuarios() throws SQLException {
        Usuarios usuarios = tablaU.getSelectionModel().getSelectedItem();
        arrayUsuarios = cargarTablas.cargarUsuarios();

        ConexionGestor cone = new ConexionGestor();
        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from usuarios");
        String modificar;

        try{
            for(int i = 0; i < arrayUsuarios.size(); i++){
                if (usuarios.getClvUsuario().equals(arrayUsuarios.get(i).getClvUsuario()) && !modificarIdCarreraU.getText().equals("") && !modificarNombreUsuarioU.getText().equals("") && !modificarNivelAdsU.getText().equals("") && !modificarContratoU.getText().equals("")) {
                    try{
                        modificar = "UPDATE usuarios"+" set clv_usuario"+"='"+modificarClvUsuarioU.getText()+"', idcarrera"+"='"+modificarIdCarreraU.getText()+"', nombre_usuario"+"='"+modificarNombreUsuarioU.getText()+"', nivel_ads"+"='"+modificarNivelAdsU.getText()+"', contrato"+"='"+modificarContratoU.getText()+"' WHERE clv_usuario" +"='"+usuarios.getClvUsuario()+"';";
                        s.executeUpdate(modificar);
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "SE MODIFICAR CORRECTAMENTE",JOptionPane.INFORMATION_MESSAGE);
                    }catch (Exception e){
                        JOptionPane.showMessageDialog(null, "MODIFICAR", "ERROR AL MODIFICAR",JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
            tablaU.setItems(getObjectoUsuarios());

        }catch (Exception e){

        }

    }

    public boolean compararSiExisteEseDato(Connection conect, String tablaEnLaQueSeVaAComparar, String id_valorIngresado, int posicionColumnaEnLaQueSeInsertara) {
        boolean existeValorEnBD = false;
        try {

            Statement s = conect.createStatement();
            //;
            ResultSet rs = s.executeQuery("select * from " + tablaEnLaQueSeVaAComparar);

            while (!String.valueOf(rs.next()).equals("false")) {
                if (rs.getString(posicionColumnaEnLaQueSeInsertara).equals(id_valorIngresado)) {
                    existeValorEnBD = true;
                }
            }

        } catch(NumberFormatException e){

        } catch (Exception e) {
            System.out.println("MANDAR VENTANA A ERROR EN PROCESO");
        }
        return existeValorEnBD; //Retorna el boolean de si encontró coincidencia o no.
    }



}
