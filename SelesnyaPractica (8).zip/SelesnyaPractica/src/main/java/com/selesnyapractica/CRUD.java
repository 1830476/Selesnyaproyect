package com.selesnyapractica;

import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.Scanner;

public class CRUD {

    static private Connection conect = null;
    Scanner entrada = new Scanner(System.in);
    Menu menu = new Menu();

    //Para colores en consola
    private String red = "\033[31m";
    private String green = "\033[32m";
    private String yellow = "\033[33m";
    private String reset = "\u001B[0m";
    private String cyan = "\033[36m";
    private String purple = "\033[35m";

    public void menuCRUD(Connection conection) throws SQLException {
        this.conect = conection;
        String eleccionMenu;

        do {
            System.out.println(yellow + "Menu");
            System.out.println("1.-Agregar registros");
            System.out.println("2.-Eliminar registros");
            System.out.println("3.-Actualizar registros");
            System.out.println("4.-Visualizar registros");
            System.out.println("0.-Salir" + reset);
            eleccionMenu = entrada.nextLine();//Ingresa el valor del menu

            switch (eleccionMenu) {
                case "1":
                    agregarRegistros();
                    eleccionMenu = "0";
                    break;
                case "2":
                    eliminarRegistros();
                    eleccionMenu = "0";
                    break;
                case "3":
                    actualizarRegistros();
                    eleccionMenu = "0";
                    break;
                case "4":
                    visualizarRegistros();
                    eleccionMenu = "0";
                    break;
                case "5":

                    eleccionMenu = "0";
                    break;
                case "0":
                    eleccionMenu = "0";
                    break;
                default:
                    menu.limpiarConsola();
                    System.out.println("No esta en el menu");
            }
        } while (eleccionMenu != "0");
    }

    public void actualizarRegistros() throws SQLException {
        String eleccionAgregar;
        System.out.println("\n");
        do {
            System.out.println(yellow + "De que tabla desea modificar");
            System.out.println("1.-Usuarios");
            System.out.println("2.-Grupos");
            System.out.println("3.-Materia usuario");
            System.out.println("4.-Aulas");
            System.out.println("5.-Login");
            System.out.println("6.-Disponibilidad");
            System.out.println("7.-Grupo materia profesor");
            System.out.println("8.-Uso aula grupo");
            System.out.println("9.-Carrera");
            System.out.println("10.-Categorias Equipos");
            System.out.println("11.-Equipos");
            System.out.println("12.-Plan estudios");
            System.out.println("13.-Materias");
            System.out.println("14.-Aula equipo");

            System.out.println("0.-Salir" + reset);
            eleccionAgregar = entrada.nextLine();

            switch (eleccionAgregar) {
                case "1":
                    actualizar(conect,"usuarios");
                    eleccionAgregar = "0";
                    break;
                case "2":
                    actualizar(conect,"grupos");
                    eleccionAgregar = "0";
                    break;
                case "3":
                    actualizar(conect,"materia_usuario");
                    eleccionAgregar = "0";
                    break;
                case "4":
                    actualizar(conect,"aulas");
                    eleccionAgregar = "0";
                    break;
                case "5":
                    actualizar(conect,"login");
                    eleccionAgregar = "0";
                    break;
                case "6":
                    actualizar(conect,"disponibilidad");
                    eleccionAgregar = "0";
                    break;
                case "7":
                    actualizar(conect,"grupo_materia_profesor");
                    eleccionAgregar = "0";
                    break;
                case "8":
                    actualizar(conect,"uso_aula_grupo");
                    eleccionAgregar = "0";
                    break;
                case "9":
                    actualizar(conect,"carrera");
                    eleccionAgregar = "0";
                    break;
                case "10":
                    actualizar(conect,"categorias_equipo");
                    eleccionAgregar = "0";
                    break;
                case "11":
                    actualizar(conect,"equipo");
                    eleccionAgregar = "0";
                    break;
                case "12":
                    actualizar(conect,"plan_estudios");
                    eleccionAgregar = "0";
                    break;
                case "13":
                    actualizar(conect,"materias");
                    eleccionAgregar = "0";
                    break;
                case "14":
                    actualizar(conect,"aula_equipo");
                    eleccionAgregar = "0";
                    break;
                case "0":
                    menuCRUD(conect);
                    eleccionAgregar = "0";
                    break;

                default:
                    menu.limpiarConsola();
                    System.out.println("No es una eleccion correcta");

            }

        } while (eleccionAgregar != "0");


    }

    public void actualizar(Connection conect,String tabla) throws SQLException {
        Statement s = conect.createStatement();
        String columna="";
        String columnaAntes="";
        String columnaNueva="";
        String modificar="";
        mostrar(conect,tabla);
        do {
            System.out.println("");
            System.out.println(purple+"Ingrese la columna que quiere modificar"+reset);
            columna = entrada.nextLine();
        } while (columna.equals(""));

        do {
            System.out.println("");
            System.out.println(purple+"Ingrese el valor que desea cambiar"+reset);
            columnaAntes = entrada.nextLine();
        } while (columnaAntes.equals(""));

        do {
            System.out.println("");
            System.out.println(purple+"Ingrese el nuevo valor"+reset);
            columnaNueva = entrada.nextLine();
        } while (columnaNueva.equals(""));

        try{
            modificar = "UPDATE "+tabla+" set "+columna+"='"+columnaNueva+"' WHERE "+columna +"='"+columnaAntes+"';";
            s.executeUpdate(modificar);
            System.out.println("Registro se modifico correctamente");
        }catch (Exception e){
            System.out.println("Error al modificar");
        }




    }

    public void eliminarRegistros() throws SQLException {
        String eleccionAgregar;
        System.out.println("\n");
        do {
            System.out.println(yellow + "De que tabla desea eliminar");
            System.out.println("1.-Usuarios");
            System.out.println("2.-Grupos");
            System.out.println("3.-Materia usuario");
            System.out.println("4.-Aulas");
            System.out.println("5.-Login");
            System.out.println("6.-Disponibilidad");
            System.out.println("7.-Grupo materia profesor");
            System.out.println("8.-Uso aula grupo");
            System.out.println("9.-Carrera");
            System.out.println("10.-Categorias Equipos");
            System.out.println("11.-Equipos");
            System.out.println("12.-Plan estudios");
            System.out.println("13.-Materias");
            System.out.println("14.-Aula equipo");

            System.out.println("0.-Salir" + reset);
            eleccionAgregar = entrada.nextLine();

            switch (eleccionAgregar) {
                case "1":
                    eliminar(conect,"usuarios");
                    eleccionAgregar = "0";
                    break;
                case "2":
                    eliminar(conect,"grupos");
                    eleccionAgregar = "0";
                    break;
                case "3":
                    eliminar(conect,"materia_usuario");
                    eleccionAgregar = "0";
                    break;
                case "4":
                    eliminar(conect,"aulas");
                    eleccionAgregar = "0";
                    break;
                case "5":
                    eliminar(conect,"login");
                    eleccionAgregar = "0";
                    break;
                case "6":
                    eliminar(conect,"disponibilidad");
                    eleccionAgregar = "0";
                    break;
                case "7":
                    eliminar(conect,"grupo_materia_profesor");
                    eleccionAgregar = "0";
                    break;
                case "8":
                    eliminar(conect,"uso_aula_grupo");
                    eleccionAgregar = "0";
                    break;
                case "9":
                    eliminar(conect,"carrera");
                    eleccionAgregar = "0";
                    break;
                case "10":
                    eliminar(conect,"categorias_equipo");
                    eleccionAgregar = "0";
                    break;
                case "11":
                    eliminar(conect,"equipo");
                    eleccionAgregar = "0";
                    break;
                case "12":
                    eliminar(conect,"plan_estudios");
                    eleccionAgregar = "0";
                    break;
                case "13":
                    eliminar(conect,"materias");
                    eleccionAgregar = "0";
                    break;
                case "14":
                    eliminar(conect,"aula_equipo");
                    eleccionAgregar = "0";
                    break;
                case "0":
                    menuCRUD(conect);
                    eleccionAgregar = "0";
                    break;

                default:
                    menu.limpiarConsola();
                    System.out.println("No es una eleccion correcta");

            }

        } while (eleccionAgregar != "0");

    }

    public void eliminar(Connection conect, String tabla) throws SQLException {
        Statement s = conect.createStatement();
        ResultSet rs = s.executeQuery("select * from " + tabla);

        String eliminar = "";
        boolean mostrarTitulos=false,existe=false;
        String variableEliminar1="";


        if (tabla.equals("usuarios")) {
            mostrar(conect, "usuarios");
            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_usuario del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                } while (variableEliminar1.equals(""));
                existe = compararSiExisteEseDato(conect, "usuarios", variableEliminar1, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }else{
                    eliminar = "delete from usuarios where clv_usuario ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }
            }
        }else if (tabla.equals("grupos")) {
            mostrar(conect, "grupos");
            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_grupo del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                } while (variableEliminar1.equals(""));
                existe = compararSiExisteEseDato(conect, "grupos", variableEliminar1, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            eliminar = "delete from grupos where clv_grupo ='"+variableEliminar1+"';";
            s.executeUpdate(eliminar);
            System.out.println("Registro eliminado correctamente");

        }else if(tabla.equals("materia_usuario")){
            mostrar(conect, "materia_usuario");
            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_materia del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                } while (variableEliminar1.equals(""));
                existe = compararSiExisteEseDato(conect, "materia_usuario", variableEliminar1, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            eliminar = "delete from materia_usuario where clv_materia ='"+variableEliminar1+"';";
            s.executeUpdate(eliminar);
            System.out.println("Registro eliminado correctamente");

        }else if(tabla.equals("aulas")){
            mostrar(conect, "aulas");

            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo

                while (variableEliminar1.equals("")) {
                    System.out.println(purple + "Ingrese id_aula del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                    if (!variableEliminar1.matches("^[0-9]*$") || variableEliminar1.equals("")) {
                        variableEliminar1 = "";
                    } else {
                        if (!(Integer.parseInt(variableEliminar1) > 0)) {
                            variableEliminar1 = "";
                        }
                    }
                }
                existe = compararSiExisteEseDato(conect, "aulas", variableEliminar1, 1);
                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                    variableEliminar1 = "";
                }else{
                    eliminar = "delete from aulas where id_aula ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }
            }

        }else if (tabla.equals("login")) {
            mostrar(conect, "login");
            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_usuario del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                } while (variableEliminar1.equals(""));
                existe = compararSiExisteEseDato(conect, "login", variableEliminar1, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }else{
                    eliminar = "delete from login where clv_usuario ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }
            }
        }else if (tabla.equals("disponibilidad")) {
            mostrar(conect, "disponibilidad");
            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_usuario del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                } while (variableEliminar1.equals(""));
                existe = compararSiExisteEseDato(conect, "disponibilidad", variableEliminar1, 3);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }else{
                    eliminar = "delete from disponibilidad where clv_usuario ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }
            }
        }else if (tabla.equals("grupo_materia_profesor")) {
            mostrar(conect, "grupo_materia_profesor");
            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_grupo del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                } while (variableEliminar1.equals(""));
                existe = compararSiExisteEseDato(conect, "grupo_materia_profesor", variableEliminar1, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }else{
                    eliminar = "delete from grupo_materia_profesor where clv_grupo ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }
            }
        }else if (tabla.equals("uso_aula_grupo")) {
            mostrar(conect, "uso_aula_grupo");
            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_grupo del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                } while (variableEliminar1.equals(""));
                existe = compararSiExisteEseDato(conect, "uso_aula_grupo", variableEliminar1, 4);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }else{
                    eliminar = "delete from uso_aula_grupo where clv_grupo ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }
            }
        }else if (tabla.equals("carrera")) {
            mostrar(conect, "carrera");

            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                while (variableEliminar1.equals("")) {
                    System.out.println(purple + "Ingrese idcarrera del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                    if (!variableEliminar1.matches("^[0-9]*$") || variableEliminar1.equals("")) {
                        System.out.println("\n");
                        variableEliminar1 = "";
                    } else {
                        if (!(Integer.parseInt(variableEliminar1) > 0)) {
                            System.out.println("\n");
                            variableEliminar1 = "";
                        }
                    }
                }
                existe = compararSiExisteEseDato(conect, "carrera", variableEliminar1, 1);
                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                    variableEliminar1 = "";
                }else{
                    eliminar = "delete from carrera where idcarrera ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }

            }
        }else if (tabla.equals("categorias_equipo")) {
            mostrar(conect, "categorias_equipo");

            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                while (variableEliminar1.equals("")) {
                    System.out.println(purple + "Ingrese id_categoria del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                    if (!variableEliminar1.matches("^[0-9]*$") || variableEliminar1.equals("")) {
                        System.out.println("\n");
                        variableEliminar1 = "";
                    } else {
                        if (!(Integer.parseInt(variableEliminar1) > 0)) {
                            System.out.println("\n");
                            variableEliminar1 = "";
                        }
                    }
                }
                existe = compararSiExisteEseDato(conect, "categorias_equipo", variableEliminar1, 1);
                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                    variableEliminar1 = "";
                }else{
                    eliminar = "delete from categorias_equipo where id_categoria ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }

            }
        }else if (tabla.equals("equipo")) {
            mostrar(conect, "equipo");

            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                while (variableEliminar1.equals("")) {
                    System.out.println(purple + "Ingrese id_equipo del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                    if (!variableEliminar1.matches("^[0-9]*$") || variableEliminar1.equals("")) {
                        System.out.println("\n");
                        variableEliminar1 = "";
                    } else {
                        if (!(Integer.parseInt(variableEliminar1) > 0)) {
                            System.out.println("\n");
                            variableEliminar1 = "";
                        }
                    }
                }
                existe = compararSiExisteEseDato(conect, "equipo", variableEliminar1, 1);
                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                    variableEliminar1 = "";
                }else{
                    eliminar = "delete from equipo where id_equipo ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }

            }
        }else if (tabla.equals("plan_estudios")) {
            mostrar(conect, "plan_estudios");

            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_plan del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                } while (variableEliminar1.equals(""));
                existe = compararSiExisteEseDato(conect, "plan_estudios", variableEliminar1, 1);
                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                    variableEliminar1 = "";
                }else{
                    eliminar = "delete from plan_estudios where clv_plan ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }

            }
        }else if (tabla.equals("materias")) {
            mostrar(conect, "materias");
            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_materia del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                } while (variableEliminar1.equals(""));
                existe = compararSiExisteEseDato(conect, "materias", variableEliminar1, 2);
                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                    variableEliminar1 = "";
                }else{
                    eliminar = "delete from materias where clv_materia ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }
            }
        }else if (tabla.equals("aula_equipo")) {
            mostrar(conect, "aula_equipo");

            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                while (variableEliminar1.equals("")) {
                    System.out.println(purple + "Ingrese id_equipo del registro a eliminar" + reset);
                    variableEliminar1 = entrada.nextLine();
                    if (!variableEliminar1.matches("^[0-9]*$") || variableEliminar1.equals("")) {
                        System.out.println("\n");
                        variableEliminar1 = "";
                    } else {
                        if (!(Integer.parseInt(variableEliminar1) > 0)) {
                            System.out.println("\n");
                            variableEliminar1 = "";
                        }
                    }
                }
                existe = compararSiExisteEseDato(conect, "aula_equipo", variableEliminar1, 1);
                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + variableEliminar1 + reset + " NO existe en la BD. Compruebe sus registro.\n");
                    variableEliminar1 = "";
                }else{
                    eliminar = "delete from aula_equipo where id_equipo ='"+variableEliminar1+"';";
                    s.executeUpdate(eliminar);
                    System.out.println("Registro eliminado correctamente");
                }

            }
        }
    }

    public void visualizarRegistros() throws SQLException {
        String eleccionAgregar;
        System.out.println("\n");
        do {
            System.out.println(yellow + "Que tabla desea vizualizar");
            System.out.println("1.-Usuarios");
            System.out.println("2.-Grupos");
            System.out.println("3.-Materia usuario");
            System.out.println("4.-Aulas");
            System.out.println("5.-Login");
            System.out.println("6.-Disponibilidad");
            System.out.println("7.-Grupo materia profesor");
            System.out.println("8.-Uso aula grupo");
            System.out.println("9.-Carrera");
            System.out.println("10.-Categorias Equipos");
            System.out.println("11.-Equipos");
            System.out.println("12.-Plan estudios");
            System.out.println("13.-Materias");
            System.out.println("14.-Aula equipo");

            System.out.println("0.-Salir" + reset);
            eleccionAgregar = entrada.nextLine();

            switch (eleccionAgregar) {
                case "1":
                    mostrar(conect,"usuarios");
                    eleccionAgregar = "0";
                    break;
                case "2":
                    mostrar(conect,"grupos");
                    eleccionAgregar = "0";
                    break;
                case "3":
                    mostrar(conect,"materia_usuario");
                    eleccionAgregar = "0";
                    break;
                case "4":
                    mostrar(conect,"aulas");
                    eleccionAgregar = "0";
                    break;
                case "5":
                    mostrar(conect,"login");
                    eleccionAgregar = "0";
                    break;
                case "6":
                    mostrar(conect,"disponibilidad");
                    eleccionAgregar = "0";
                    break;
                case "7":
                    mostrar(conect,"grupo_materia_profesor");
                    eleccionAgregar = "0";
                    break;
                case "8":
                    mostrar(conect,"uso_aula_grupo");
                    eleccionAgregar = "0";
                    break;
                case "9":
                    mostrar(conect,"carrera");
                    eleccionAgregar = "0";
                    break;
                case "10":
                    mostrar(conect,"categorias_equipo");
                    eleccionAgregar = "0";
                    break;
                case "11":
                    mostrar(conect,"equipo");
                    eleccionAgregar = "0";
                    break;
                case "12":
                    mostrar(conect,"plan_estudios");
                    eleccionAgregar = "0";
                    break;
                case "13":
                    mostrar(conect,"materias");
                    eleccionAgregar = "0";
                    break;
                case "14":
                    mostrar(conect,"aula_equipo");
                    eleccionAgregar = "0";
                    break;
                case "0":
                    menuCRUD(conect);
                    eleccionAgregar = "0";
                    break;

                default:
                    menu.limpiarConsola();
                    System.out.println("No es una eleccion correcta");

            }

        } while (eleccionAgregar != "0");

    }

    public void mostrar(Connection conect,String tabla) throws SQLException {
        Statement s = conect.createStatement();
        boolean mostrarTitulos=false;

        ObservableList<Constr_aula_equipos> Mostrar_aula_equipos = FXCollections.observableArrayList();


        //;
        ResultSet rs = s.executeQuery("select * from " + tabla);

        while(!String.valueOf(rs.next()).equals("false")) {
            if (tabla.equals("usuarios")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t" + rs.getMetaData().getColumnName(3)+ "\t" + rs.getMetaData().getColumnName(4) + "\t" + rs.getMetaData().getColumnName(5));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2) + "\t\t" + rs.getString(3) + "\t\t" + rs.getString(4) + "\t\t" + rs.getString(5));

            } else if (tabla.equals("grupos")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2));
                


            }else if(tabla.equals("materia_usuario")){
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2)+ "\t" + rs.getMetaData().getColumnName(3)+ "\t" + rs.getMetaData().getColumnName(4)+ "\t" + rs.getMetaData().getColumnName(5));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2)+ "\t\t" + rs.getString(3)+ "\t\t" + rs.getString(4)+ "\t\t" + rs.getString(5));
            }else if(tabla.equals("aulas")){
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2)+ "\t\t" + rs.getMetaData().getColumnName(3)+ "\t" + rs.getMetaData().getColumnName(4));
                }
                System.out.println(rs.getString(1) + "\t" + rs.getString(2)+ "\t" + rs.getString(3)+ "\t" + rs.getString(4));
            }else if (tabla.equals("login")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t" + rs.getMetaData().getColumnName(3));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2) + "\t\t" + rs.getString(3));
            }else if (tabla.equals("disponibilidad")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t" + rs.getMetaData().getColumnName(3));
                }
                System.out.println(rs.getString(1) + "\t" + rs.getString(2) + "\t\t" + rs.getString(3));
            }else if (tabla.equals("grupo_materia_profesor")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t" + rs.getMetaData().getColumnName(3));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2) + "\t\t" + rs.getString(3));

            }if (tabla.equals("uso_aula_grupo")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t" + rs.getMetaData().getColumnName(3)+ "\t\t" + rs.getMetaData().getColumnName(4) + "\t" + rs.getMetaData().getColumnName(5));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t\t" + rs.getString(4) + "\t\t" + rs.getString(5));

            }else if (tabla.equals("carrera")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) );
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2));

            }else if (tabla.equals("categorias_equipo")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t" + rs.getMetaData().getColumnName(3));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2) + "\t\t\t" + rs.getString(3) );



            }else if (tabla.equals("equipo")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t\t" + rs.getMetaData().getColumnName(3)+ "\t\t\t" + rs.getMetaData().getColumnName(4));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2) + "\t\t" + rs.getString(3) + "\t" + rs.getString(4));

            }else if (tabla.equals("plan_estudios")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t\t\t" + rs.getMetaData().getColumnName(3)+ "\t" + rs.getMetaData().getColumnName(4));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2) + "\t\t" + rs.getString(3) + "\t\t" + rs.getString(4));

            }else if (tabla.equals("materias")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t" + rs.getMetaData().getColumnName(3)+ "\t" + rs.getMetaData().getColumnName(4) + "\t" + rs.getMetaData().getColumnName(5)+ "\t" + rs.getMetaData().getColumnName(6)+ "\t" + rs.getMetaData().getColumnName(7)+ "\t" + rs.getMetaData().getColumnName(8));
                }
                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2) + "\t\t" + rs.getString(3) + "\t" + rs.getString(4) + "\t" + rs.getString(5)+ "\t" + rs.getString(6)+ "\t" + rs.getString(7)+ "\t" + rs.getString(8));

            }else if (tabla.equals("aula_equipo")) {
                if(mostrarTitulos == false){
                    System.out.println("\n");
                    System.out.println(rs.getMetaData().getTableName(1));
                    System.out.println(rs.getMetaData().getColumnName(1) + "\t" + rs.getMetaData().getColumnName(2) + "\t\t" + rs.getMetaData().getColumnName(3));
                }

                System.out.println(rs.getString(1) + "\t\t" + rs.getString(2) + "\t\t" + rs.getString(3));


            }


            mostrarTitulos=true;
        }
    }

    public void agregarRegistros() throws SQLException {
        String eleccionAgregar;
        System.out.println("\n");

        do {
            System.out.println(yellow + "A que tabla desea agregar un registro");
            System.out.println("1.-Usuarios");
            System.out.println("2.-Grupos");
            System.out.println("3.-Materia usuario");
            System.out.println("4.-Aulas");
            System.out.println("5.-Login");
            System.out.println("6.-Disponibilidad");
            System.out.println("7.-Grupo materia profesor");
            System.out.println("8.-Uso aula grupo");
            System.out.println("9.-Carrera");
            System.out.println("10.-Categorias Equipos");
            System.out.println("11.-Equipos");
            System.out.println("12.-Plan estudios");
            System.out.println("13.-Materias");
            System.out.println("14.-Aulta equipo");

            System.out.println("0.-Salir" + reset);
            eleccionAgregar = entrada.nextLine();

            switch (eleccionAgregar) {
                case "1":
                    agregarUsuario();
                    eleccionAgregar = "0";

                    break;

                case "2":
                    agregarGrupos();
                    eleccionAgregar = "0";
                    break;
                case "3":
                    agregarMateriaUsuario();
                    eleccionAgregar = "0";
                    break;
                case "4":
                    agregarAulas();
                    eleccionAgregar = "0";
                    break;
                case "5":
                    agregarLogin();
                    eleccionAgregar = "0";
                    break;
                case "6":
                    agregarDisponibilidad();
                    eleccionAgregar = "0";
                    break;
                case "7":
                    agregarGrupoMateriaProfesor();
                    eleccionAgregar = "0";
                    break;
                case "8":
                    agregarUsoAulaGrupo();
                    eleccionAgregar = "0";
                    break;
                case "9":
                    agregarCarrera();
                    eleccionAgregar = "0";
                    break;
                case "10":
                    agregarCategoriasEquipo();
                    eleccionAgregar = "0";
                    break;
                case "11":
                    agregarEquipo();
                    eleccionAgregar = "0";
                    break;
                case "12":
                    agregarPlanEstudios();
                    eleccionAgregar = "0";
                    break;
                case "13":
                    agregarMaterias();
                    eleccionAgregar = "0";
                    break;
                case "14":
                    agregarAulaEquipo();
                    eleccionAgregar = "0";
                    break;
                case "0":
                    menuCRUD(conect);
                    eleccionAgregar = "0";
                    break;

                default:
                    menu.limpiarConsola();
                    System.out.println("No es una eleccion correcta");

            }

        } while (eleccionAgregar != "0");


    }

    public void agregarUsuario() throws SQLException {
        String clv_usuario = "";
        String idcarrera = "";
        String nombre_usuario = "";
        String nivel_ads = "";
        String contrato = "";
        String eleccion = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA USUARIO ---------------------");
        boolean existe = false;

        try {

            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_usuario" + reset);
                    clv_usuario = entrada.nextLine();
                } while (clv_usuario.equals(""));
                existe = compararSiExisteEseDato(conect, "usuarios", clv_usuario, 1);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
            }

            existe = false;
            System.out.println("");
            while (existe == false) { //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido
                do {
                    System.out.println(purple + "Ingrese idcarrera" + reset);
                    idcarrera = entrada.nextLine();
                } while (idcarrera.equals(""));
                existe = compararSiExisteEseDato(conect, "carrera", idcarrera, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + idcarrera + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            do {
                System.out.println("");
                System.out.println(purple + "Ingrese el nombre del usuario" + reset);
                nombre_usuario = entrada.nextLine();
            } while (nombre_usuario.equals(""));

            existe = false;
            System.out.println("");
            do {
                System.out.println(yellow + "Ingrese el nivel ads");
                System.out.println("1.-Dr.");
                System.out.println("2.-M.C");
                System.out.println("3.-Ing.");
                System.out.println("4.-Lic." + reset);
                eleccion = entrada.nextLine();

                switch (eleccion) {
                    case "1":
                        nivel_ads = "Dr.";
                        existe = false;
                        break;
                    case "2":
                        nivel_ads = "M.C";
                        existe = false;
                        break;
                    case "3":
                        nivel_ads = "Ing.";
                        existe = false;
                        break;
                    case "4":
                        nivel_ads = "Lic.";
                        existe = false;
                        break;
                    default:
                        existe = true;
                }
            } while (existe != false);

            existe = false;

            do {
                System.out.println(yellow + "Ingrese el contrato");
                System.out.println("1.-PTC");
                System.out.println("2.-PA" + reset);
                eleccion = entrada.nextLine();

                switch (eleccion) {
                    case "1":
                        contrato = "PTC";
                        existe = false;
                        break;
                    case "2":
                        contrato = "PA";
                        existe = false;
                        break;
                    default:
                        existe = true;
                }
            } while (existe != false);

            this.insertarEnUsuariosConDatos(conect, clv_usuario, idcarrera, nombre_usuario, nivel_ads, contrato);

        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }

    }

    public void agregarGrupos() throws SQLException {
        String clv_grupo = "";
        String cuatrimestre = "";
        int cuatrimestreNumero = 0;
        String grupo = "";
        int grupoNumero = 0;
        String turno = "";
        int turnoNumero = 0;
        String eleccion = "";
        String insersion = "";


        System.out.println("--------------------- INGRESANDO EN LA TABLA GRUPOS ---------------------");
        boolean existe = false;
        try {
            do {
                System.out.println(yellow + "Ingrese la carrera");
                System.out.println("1.-ITI");
                System.out.println("2.-IM");
                System.out.println("3.-ISA");
                System.out.println("4.-ITM");
                System.out.println("5.-LAYGE" + reset);
                eleccion = entrada.nextLine();

                switch (eleccion) {
                    case "1":
                        clv_grupo = "ITI";
                        existe = false;
                        break;
                    case "2":
                        clv_grupo = "IM";
                        existe = false;
                        break;
                    case "3":
                        clv_grupo = "ISA";
                        existe = false;
                        break;
                    case "4":
                        clv_grupo = "ITM";
                        existe = false;
                        break;
                    case "5":
                        clv_grupo = "LAYGE";
                        existe = false;
                        break;
                    default:
                        existe = true;
                }
            } while (existe != false);

            existe = false;
            do {
                System.out.println(yellow + "Ingrese el cuatrimestre");

                cuatrimestre = entrada.nextLine();
                if (cuatrimestre.equals("1")) {
                    cuatrimestreNumero = 1;
                } else if (cuatrimestre.equals("2")) {
                    cuatrimestreNumero = 2;
                } else if (cuatrimestre.equals("3")) {
                    cuatrimestreNumero = 3;
                } else if (cuatrimestre.equals("4")) {
                    cuatrimestreNumero = 4;
                } else if (cuatrimestre.equals("5")) {
                    cuatrimestreNumero = 5;
                } else if (cuatrimestre.equals("6")) {
                    cuatrimestreNumero = 6;
                } else if (cuatrimestre.equals("7")) {
                    cuatrimestreNumero = 7;
                } else if (cuatrimestre.equals("8")) {
                    cuatrimestreNumero = 8;
                } else if (cuatrimestre.equals("9")) {
                    cuatrimestreNumero = 9;
                } else {
                    cuatrimestreNumero = 0;
                }
            } while (cuatrimestreNumero < 1 || cuatrimestreNumero > 9);

            existe = false;
            do {
                System.out.println(yellow + "Ingrese el grupo de 1 a 5");

                grupo = entrada.nextLine();
                if (grupo.equals("1")) {
                    grupoNumero = 1;
                } else if (grupo.equals("2")) {
                    grupoNumero = 2;
                } else if (grupo.equals("3")) {
                    grupoNumero = 3;
                } else if (grupo.equals("4")) {
                    grupoNumero = 4;
                } else if (grupo.equals("5")) {
                    grupoNumero = 5;
                } else {
                    grupoNumero = 0;
                }

            } while (grupoNumero < 1 || grupoNumero > 5);

            //concadeno todo lo anterior para formar el clv_grupo
            clv_grupo = clv_grupo + cuatrimestre + "-" + grupo;

            do {
                System.out.println(yellow + "Ingrese el turno");
                System.out.println("1.-Matutino");
                System.out.println("2.-Vespertino" + reset);

                turno = entrada.nextLine();

                if (turno.equals("1")) {
                    turnoNumero = 1;
                } else if (turno.equals("2")) {
                    turnoNumero = 2;
                }


            } while (turnoNumero < 1 || turnoNumero > 2);


            this.insertarEnGruposConDatos(conect, clv_grupo, turno);

        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }

    }

    public void agregarMateriaUsuario() throws SQLException {
        String claveMateriaAIngresar = "";
        String clavePlanAIngresar = "";
        String claveUsuarioAIngresar = "";
        String puntosConfianza = "";
        String puntosDirector = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA MATERIA USUARIO ---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_materia" + reset);
                    claveMateriaAIngresar = entrada.nextLine();
                } while (claveMateriaAIngresar.equals(""));
                existe = compararSiExisteEseDato(conect, "materias", claveMateriaAIngresar, 2);
                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + claveMateriaAIngresar + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            existe = false;
            System.out.println("");
            while (existe == false) { //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido

                do {
                    System.out.println(purple + "Ingrese clv_plan" + reset);
                    clavePlanAIngresar = entrada.nextLine();
                } while (clavePlanAIngresar.equals(""));
                existe = compararSiExisteEseDato(conect, "plan_estudios", clavePlanAIngresar, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clavePlanAIngresar + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            existe = false;
            System.out.println("");
            while (existe == false) { //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido
                do {
                    System.out.println(purple + "Ingrese clv_usuario" + reset);
                    claveUsuarioAIngresar = entrada.nextLine();
                } while (claveUsuarioAIngresar.equals(""));
                existe = compararSiExisteEseDato(conect, "usuarios", claveUsuarioAIngresar, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + claveUsuarioAIngresar + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            existe = false;
            while (puntosConfianza.equals("")) {
                System.out.println(purple + "Ingrese puntos de confianza (1-5)" + reset);
                puntosConfianza = entrada.nextLine();
                if (!puntosConfianza.matches("^[0-9]*$") || puntosConfianza.equals("")) {
                    System.out.println("\n");
                    puntosConfianza = "";
                } else {
                    if (!(Integer.parseInt(puntosConfianza) > 0) || !(Integer.parseInt(puntosConfianza) < 6)) {
                        System.out.println("\n");
                        puntosConfianza = "";
                    }
                }
            }

            existe = false;
            while (puntosDirector.equals("")) {
                System.out.println(purple + "Ingrese puntos de director (1-5)" + reset);
                puntosDirector = entrada.nextLine();
                if (!puntosDirector.matches("^[0-9]*$") || puntosDirector.equals("")) {
                    System.out.println("\n");
                    puntosDirector = "";
                } else {
                    if (!(Integer.parseInt(puntosDirector) > 0) || !(Integer.parseInt(puntosDirector) < 6)) {
                        System.out.println("\n");
                        puntosDirector = "";
                    }
                }
            }

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnMateriaUsuarioConDatos(conect, claveMateriaAIngresar, clavePlanAIngresar, claveUsuarioAIngresar, puntosConfianza, puntosDirector);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }
    }

    public void agregarAulas() throws SQLException {
        String id_aula = "";
        String nombre = "";
        String tipo = "";
        String capacidad = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA AULAS ---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo

                while (id_aula.equals("")) {
                    System.out.println(purple + "Ingrese id_aula" + reset);
                    id_aula = entrada.nextLine();
                    if (!id_aula.matches("^[0-9]*$") || id_aula.equals("")) {
                        id_aula = "";
                    } else {
                        if (!(Integer.parseInt(id_aula) > 0)) {
                            id_aula = "";
                        }
                    }
                }
                existe = compararSiExisteEseDato(conect, "aulas", id_aula, 1);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_aula + reset + " YA existe en la BD. Compruebe sus registro.\n");
                    id_aula = "";

                }
            }

            existe = false;
            do {
                System.out.println("");
                System.out.println(purple + "Ingrese el nombre" + reset);
                nombre = entrada.nextLine();
            } while (nombre.equals(""));

            do {
                System.out.println(yellow + "Ingrese el tipo de aula");
                System.out.println("1.-Laboratorio");
                System.out.println("2.-Salon" + reset);
                tipo = entrada.nextLine();

                switch (tipo) {
                    case "1":
                        tipo = "Laboratorio";
                        existe = false;
                        break;
                    case "2":
                        tipo = "Salon";
                        existe = false;
                        break;
                    default:
                        existe = true;
                }
            } while (existe != false);

            existe = false;
            do {
                System.out.println("");
                System.out.println(yellow + "Ingrese la capacidad");
                System.out.println("20/30/40" + reset);
                capacidad = entrada.nextLine();
            } while (!capacidad.equals("20") && !capacidad.equals("30") && !capacidad.equals("40"));

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnAulasConDatos(conect, id_aula, nombre, tipo, capacidad);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }


    }

    public void agregarLogin() throws SQLException {
        String clv_usuario = "";
        String pass_usuario = "";
        String tipo_usuario = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA LOGIN ---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_usuario" + reset);
                    clv_usuario = entrada.nextLine();
                } while (clv_usuario.equals(""));
                existe = compararSiExisteEseDato(conect, "login", clv_usuario, 1);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
                if (existe == false) {
                    existe = false;
                    existe = compararSiExisteEseDato(conect, "usuarios", clv_usuario, 1);
                    if (existe == false) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        existe = true;
                    } else {
                        existe = false;
                    }
                }
            }

            existe = false;

            do {
                System.out.println("");
                System.out.println(purple + "Ingrese el password" + reset);
                pass_usuario = entrada.nextLine();
            } while (pass_usuario.equals(""));

            do {
                System.out.println(yellow + "Ingrese el tipo de usuario");
                System.out.println("1.-PROF");
                System.out.println("2.-DIRE" + reset);
                tipo_usuario = entrada.nextLine();

                switch (tipo_usuario) {
                    case "1":
                        tipo_usuario = "PROF";
                        existe = false;
                        break;
                    case "2":
                        tipo_usuario = "DIRE";
                        existe = false;
                        break;
                    default:
                        existe = true;
                }
            } while (existe != false);


            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnLoginConDatos(conect, clv_usuario, pass_usuario, tipo_usuario);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }


    }

    public void agregarDisponibilidad() throws SQLException {
        String dia = "";
        String espacio_tiempo = "";
        String clv_usuario = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA DISPONIBILIDAD ---------------------");
        boolean existe = false;

        try {

            existe = true;
            while (dia.equals("")) {
                System.out.println(purple + "Ingrese el dia del 1 al 10" + reset);
                dia = entrada.nextLine();
                if (!dia.matches("^[0-9]*$") || dia.equals("")) {
                    System.out.println("\n");
                    dia = "";
                } else {
                    if (!(Integer.parseInt(dia) > 0) || !(Integer.parseInt(dia) < 11)) {
                        System.out.println("\n");
                        dia = "";
                    }
                }
            }

            existe = true;
            while (espacio_tiempo.equals("")) {
                System.out.println(purple + "Ingrese el espacio_tiempo del 1 al 10" + reset);
                espacio_tiempo = entrada.nextLine();
                if (!espacio_tiempo.matches("^[0-9]*$") || espacio_tiempo.equals("")) {
                    System.out.println("\n");
                    espacio_tiempo = "";
                } else {
                    if (!(Integer.parseInt(espacio_tiempo) > 0) || !(Integer.parseInt(espacio_tiempo) < 11)) {
                        System.out.println("\n");
                        espacio_tiempo = "";
                    }
                }
            }

            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_usuario" + reset);
                    clv_usuario = entrada.nextLine();
                } while (clv_usuario.equals(""));
                existe = compararSiExisteEseDato(conect, "disponibilidad", clv_usuario, 3);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
                if (existe == false) {
                    existe = false;
                    existe = compararSiExisteEseDato(conect, "usuarios", clv_usuario, 1);
                    if (existe == false) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        existe = true;
                    } else {
                        existe = false;
                    }
                }
            }
            this.insertarEnDisponibilidadConDatos(conect, dia, espacio_tiempo, clv_usuario);

        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }

    }

    public void agregarGrupoMateriaProfesor() throws SQLException {
        String clv_grupo = "";
        String clv_materia = "";
        String clv_usuario = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA GRUPOS MATERIAS PROFESOR ---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {

            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_grupo" + reset);
                    clv_grupo = entrada.nextLine();
                } while (clv_grupo.equals(""));
                existe = compararSiExisteEseDato(conect, "grupo_materia_profesor", clv_grupo, 1);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_grupo + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
                if (existe == false) {
                    existe = false;
                    existe = compararSiExisteEseDato(conect, "grupos", clv_grupo, 1);
                    if (existe == false) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_grupo + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        existe = true;
                    } else {
                        existe = false;
                    }
                }
            }

            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_materia" + reset);
                    clv_materia = entrada.nextLine();
                } while (clv_materia.equals(""));
                existe = compararSiExisteEseDato(conect, "grupo_materia_profesor", clv_materia, 2);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_materia + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
                if (existe == false) {
                    existe = false;
                    existe = compararSiExisteEseDato(conect, "materias", clv_materia, 2);
                    if (existe == false) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_materia + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        existe = true;
                    } else {
                        existe = false;
                    }
                }
            }

            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo

                do {
                    System.out.println(purple + "Ingrese clv_usuario" + reset);
                    clv_usuario = entrada.nextLine();
                } while (clv_usuario.equals(""));
                existe = compararSiExisteEseDato(conect, "grupo_materia_profesor", clv_usuario, 3);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
                if (existe == false) {
                    existe = false;
                    existe = compararSiExisteEseDato(conect, "usuarios", clv_usuario, 1);
                    if (existe == false) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        existe = true;
                    } else {
                        existe = false;
                    }
                }
            }


            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnGrupoMateriaProfesorConDatos(conect, clv_grupo, clv_materia, clv_usuario);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }


    }

    public void agregarUsoAulaGrupo() throws SQLException {
        String dia = "";
        String espacio_tiempo = "";
        String id_aula = "";
        String clv_grupo = "";
        String clv_materia = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA USO AULA GRUPO ---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = true;
            while (dia.equals("")) {
                System.out.println(purple + "Ingrese el dia del 1 al 10" + reset);
                dia = entrada.nextLine();
                if (!dia.matches("^[0-9]*$") || dia.equals("")) {
                    System.out.println("\n");
                    dia = "";
                } else {
                    if (!(Integer.parseInt(dia) > 0) || !(Integer.parseInt(dia) < 11)) {
                        System.out.println("\n");
                        dia = "";
                    }
                }
            }

            existe = true;
            while (espacio_tiempo.equals("")) {
                System.out.println(purple + "Ingrese el espacio_tiempo del 1 al 10" + reset);
                espacio_tiempo = entrada.nextLine();
                if (!espacio_tiempo.matches("^[0-9]*$") || espacio_tiempo.equals("")) {
                    System.out.println("\n");
                    espacio_tiempo = "";
                } else {
                    if (!(Integer.parseInt(espacio_tiempo) > 0) || !(Integer.parseInt(espacio_tiempo) < 11)) {
                        System.out.println("\n");
                        espacio_tiempo = "";
                    }
                }
            }

            existe = false;
            System.out.println("");
            while (existe == false) { //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido

                do {
                    System.out.println(purple + "Ingrese id_aula" + reset);
                    id_aula = entrada.nextLine();
                } while (id_aula.equals(""));

                existe = compararSiExisteEseDato(conect, "aulas", id_aula, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_aula + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            existe = false;
            System.out.println("");
            while (existe == false) { //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido
                do {
                    System.out.println(purple + "Ingrese clv_grupo" + reset);
                    clv_grupo = entrada.nextLine();
                } while (clv_grupo.equals(""));
                existe = compararSiExisteEseDato(conect, "grupos", clv_grupo, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_grupo + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            existe = false;
            System.out.println("");
            while (existe == false) { //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido
                do {
                    System.out.println(purple + "Ingrese clv_materia" + reset);
                    clv_materia = entrada.nextLine();
                } while (clv_materia.equals(""));
                existe = compararSiExisteEseDato(conect, "materias", clv_materia, 2);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_materia + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }


            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnUsoAulaGrupoConDatos(conect, dia, espacio_tiempo, id_aula, clv_grupo, clv_materia);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }


    }

    public void agregarCarrera() throws SQLException {
        String idcarrera = "";
        String nombre_carrera = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA CARRERA---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                while (idcarrera.equals("")) {
                    System.out.println(purple + "Ingrese idcarrera" + reset);
                    idcarrera = entrada.nextLine();
                    if (!idcarrera.matches("^[0-9]*$") || idcarrera.equals("")) {
                        System.out.println("\n");
                        idcarrera = "";
                    } else {
                        if (!(Integer.parseInt(idcarrera) > 0)) {
                            System.out.println("\n");
                            idcarrera = "";
                        }
                    }
                }

                existe = compararSiExisteEseDato(conect, "carrera", idcarrera, 1);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + idcarrera + reset + " YA existe en la BD. Compruebe sus registro.\n");
                    idcarrera = "";
                }

            }

            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese nombre_carrera" + reset);
                    nombre_carrera = entrada.nextLine();
                } while (nombre_carrera.equals(""));
                existe = compararSiExisteEseDato(conect, "carrera", nombre_carrera, 2);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + nombre_carrera + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
            }


            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnCarreraConDatos(conect, idcarrera, nombre_carrera);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }


    }

    public void agregarCategoriasEquipo() throws SQLException {
        String id_categoria = "";
        String nombre_categoria = "";
        String descripcion_categoria = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA CATEGORIAS EQUIPO---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo


                while (id_categoria.equals("")) {
                    System.out.println(purple + "Ingrese id_categoria" + reset);
                    id_categoria = entrada.nextLine();
                    if (!id_categoria.matches("^[0-9]*$") || id_categoria.equals("")) {
                        System.out.println("\n");
                        id_categoria = "";
                    } else {
                        if (!(Integer.parseInt(id_categoria) > 0)) {
                            System.out.println("\n");
                            id_categoria = "";
                        }
                    }
                }
                existe = compararSiExisteEseDato(conect, "categorias_equipo", id_categoria, 1);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_categoria + reset + " YA existe en la BD. Compruebe sus registro.\n");
                    id_categoria = "";
                }
            }

            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese nombre_categoria" + reset);
                    nombre_categoria = entrada.nextLine();
                } while (nombre_categoria.equals(""));
                existe = compararSiExisteEseDato(conect, "categorias_equipo", nombre_categoria, 2);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + nombre_categoria + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
            }
            existe = false;
            do {
                System.out.println(purple + "Ingrese descripcion_categoria" + reset);
                descripcion_categoria = entrada.nextLine();
            } while (descripcion_categoria.equals(""));


            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnCategoriasEquipoConDatos(conect, id_categoria, nombre_categoria, descripcion_categoria);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }
    }

    public void agregarEquipo() throws SQLException {
        String id_equipo = "";
        String nombre = "";
        String descripcion = "";
        String id_categoria = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA EQUIPO ---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo

                while (id_equipo.equals("")) {
                    System.out.println(purple + "Ingrese id_equipo" + reset);
                    id_equipo = entrada.nextLine();
                    if (!id_equipo.matches("^[0-9]*$") || id_equipo.equals("")) {
                        System.out.println("\n");
                        id_equipo = "";
                    } else {
                        if (!(Integer.parseInt(id_equipo) > 0)) {
                            System.out.println("\n");
                            id_equipo = "";
                        }
                    }
                }
                existe = compararSiExisteEseDato(conect, "equipo", id_equipo, 1);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_equipo + reset + " YA existe en la BD. Compruebe sus registro.\n");
                    id_equipo = "";
                }
            }

            existe = false;
            do {
                System.out.println(purple + "Ingrese descripcion" + reset);
                descripcion = entrada.nextLine();
            } while (descripcion.equals(""));

            existe = false;
            do {
                System.out.println(purple + "Ingrese nombre" + reset);
                nombre = entrada.nextLine();
            } while (nombre.equals(""));

            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese id_categoria" + reset);
                    id_categoria = entrada.nextLine();
                } while (id_categoria.equals(""));
                existe = compararSiExisteEseDato(conect, "categorias_equipo", id_categoria, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_categoria + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnEquipoConDatos(conect, id_equipo, nombre, descripcion, id_categoria);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }
    }

    public void agregarPlanEstudios() throws SQLException {
        String clv_plan = "";
        String nombre_plan = "";
        String nivel = "";
        String idcarrera = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA PLAN ESTUDIOS ---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese clv_plan" + reset);
                    clv_plan = entrada.nextLine();
                } while (clv_plan.equals(""));

                existe = compararSiExisteEseDato(conect, "plan_estudios", clv_plan, 1);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_plan + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
            }

            existe = false;
            do {
                System.out.println(purple + "Ingrese nombre_plan" + reset);
                nombre_plan = entrada.nextLine();
            } while (nombre_plan.equals(""));


            existe = false;
            while (nivel.equals("")) {
                System.out.println(purple + "Ingrese el nivel del 1 al 3" + reset);
                nivel = entrada.nextLine();
                if (!nivel.matches("^[0-9]*$") || nivel.equals("")) {
                    System.out.println("\n");
                    nivel = "";
                } else {
                    if (!(Integer.parseInt(nivel) > 0) || !(Integer.parseInt(nivel) < 4)) {
                        System.out.println("\n");
                        nivel = "";
                    }
                }
            }

            existe = false;
            while (existe == false) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese idcarrera" + reset);
                    idcarrera = entrada.nextLine();
                } while (idcarrera.equals(""));

                existe = compararSiExisteEseDato(conect, "carrera", idcarrera, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + idcarrera + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnPlanEstudiosConDatos(conect, clv_plan, nombre_plan, nivel, idcarrera);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }
    }

    public void agregarMaterias() throws SQLException {
        String nombre_materia = "";
        String clv_materia = "";
        String creditos = "";
        String cuatrimestre = "";
        String posicion = "";
        String clv_plan = "";
        String horas_x_semana = "";
        String tipo_materia = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA MATERIAS ---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = false;
            do {
                System.out.println(purple + "Ingrese nombre_materia" + reset);
                nombre_materia = entrada.nextLine();
            } while (nombre_materia.equals(""));

            existe = true;
            System.out.println("");
            while (existe == true) { //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido
                do {
                    System.out.println(purple + "Ingrese clv_materia" + reset);
                    clv_materia = entrada.nextLine();
                } while (clv_materia.equals(""));

                existe = compararSiExisteEseDato(conect, "materias", clv_materia, 2);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_materia + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
            }

            existe = false;
            while (creditos.equals("")) {
                System.out.println(purple + "Ingrese los creditos del 1 al 5" + reset);
                creditos = entrada.nextLine();
                if (!creditos.matches("^[0-9]*$") || creditos.equals("")) {
                    System.out.println("\n");
                    creditos = "";
                } else {
                    if (!(Integer.parseInt(creditos) > 0) || !(Integer.parseInt(creditos) < 6)) {
                        System.out.println("\n");
                        creditos = "";
                    }
                }
            }

            existe = false;
            while (cuatrimestre.equals("")) {
                System.out.println(purple + "Ingrese el cuatrimestre (1-9)" + reset);
                cuatrimestre = entrada.nextLine();
                if (!cuatrimestre.matches("^[0-9]*$") || cuatrimestre.equals("")) {
                    System.out.println("\n");
                    cuatrimestre = "";
                } else {
                    if (!(Integer.parseInt(cuatrimestre) > 0) || !(Integer.parseInt(cuatrimestre) < 10)) {
                        System.out.println("\n");
                        cuatrimestre = "";
                    }
                }
            }

            existe = false;
            while (posicion.equals("")) {
                System.out.println(purple + "Ingrese la posicion (1-2)" + reset);
                posicion = entrada.nextLine();
                if (!posicion.matches("^[0-9]*$") || posicion.equals("")) {
                    System.out.println("\n");
                    posicion = "";
                } else {
                    if (!(Integer.parseInt(posicion) > 0) || !(Integer.parseInt(posicion) < 3)) {
                        System.out.println("\n");
                        posicion = "";
                    }
                }
            }

            existe = false;
            System.out.println("");
            while (existe == false) { //Si no existe, se seguirá repitiendo hasta que ingrese un valor válido
                do {
                    System.out.println(purple + "Ingrese clv_plan" + reset);
                    clv_plan = entrada.nextLine();
                } while (clv_plan.equals(""));

                existe = compararSiExisteEseDato(conect, "plan_estudios", clv_plan, 1);

                if (existe == false) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_plan + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

            existe = false;
            while (horas_x_semana.equals("")) {
                System.out.println(purple + "Ingrese las horas por semana de 15 a 25" + reset);
                horas_x_semana = entrada.nextLine();
                if (!horas_x_semana.matches("^[0-9]*$") || horas_x_semana.equals("")) {
                    System.out.println("\n");
                    horas_x_semana = "";
                } else {
                    if (!(Integer.parseInt(horas_x_semana) > 14) || !(Integer.parseInt(horas_x_semana) < 26)) {
                        System.out.println("\n");
                        horas_x_semana = "";
                    }
                }
            }
            existe = false;
            System.out.println("");
            do {
                System.out.println(purple + "Ingrese tipo_materia (3 digitos)" + reset);
                tipo_materia = entrada.nextLine();
            } while (tipo_materia.equals("") || tipo_materia.length() > 3);

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnMateriasConDatos(conect, nombre_materia, clv_materia, creditos, cuatrimestre, posicion, clv_plan, horas_x_semana, tipo_materia);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }
    }

    public void agregarAulaEquipo() throws SQLException {
        String id_equipo = "";
        String id_aula = "";
        String cantidad = "";
        String insersion = "";

        System.out.println("--------------------- INGRESANDO EN LA TABLA AULA EQUIPO ---------------------");
        //Intresar a la tabla materia_usuario
        boolean existe = false;
        try {
            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese id_equipo" + reset);
                    id_equipo = entrada.nextLine();
                } while (id_equipo.equals(""));
                existe = compararSiExisteEseDato(conect, "aula_equipo", id_equipo, 1);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_equipo + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
                if (existe == false) {
                    existe = false;
                    existe = compararSiExisteEseDato(conect, "equipo", id_equipo, 1);
                    if (existe == false) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_equipo + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        existe = true;
                    } else {
                        existe = false;
                    }
                }
            }

            existe = true;
            while (existe == true) { //Si existe, se seguirá repitiendo hasta que ingrese un valor de id nuevo
                do {
                    System.out.println(purple + "Ingrese id_aula" + reset);
                    id_aula = entrada.nextLine();
                } while (id_aula.equals(""));
                existe = compararSiExisteEseDato(conect, "aula_equipo", id_aula, 2);

                if (existe == true) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_aula + reset + " YA existe en la BD. Compruebe sus registro.\n");
                }
                if (existe == false) {
                    existe = false;
                    existe = compararSiExisteEseDato(conect, "aulas", id_aula, 1);
                    if (existe == false) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_aula + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        existe = true;
                    } else {
                        existe = false;
                    }
                }
            }

            existe = false;
            while (cantidad.equals("")) {
                System.out.println(purple + "Ingrese la cantidad de 1 a 60" + reset);
                cantidad = entrada.nextLine();
                if (!cantidad.matches("^[0-9]*$") || cantidad.equals("")) {
                    System.out.println("\n");
                    cantidad = "";
                } else {
                    if (!(Integer.parseInt(cantidad) > 0) || !(Integer.parseInt(cantidad) < 61)) {
                        System.out.println("\n");
                        cantidad = "";
                    }
                }
            }

            //Aqui manda el conect y los datos que iran en cada una de las columnas
            this.insertarEnAulaEquipoConDatos(conect, id_equipo, id_aula, cantidad);
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion en el metodo insertarEnMateriaUsuario: " + e);
        }
    }

    	/*
	Este metodo recibe como parametros el conect y cada uno de los datos que se insertaran en las columnas, de esta forma
	podemos utilizar este mismo método para insertar datos desde el crud, desde un excel y desde un txt.
	*/
    public void insertarEnMateriaUsuarioConDatos(Connection conect, String claveMateriaAIngresar, String clavePlanAIngresar, String claveUsuarioAIngresar, String puntosConfianza, String puntosDirector) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "materias", claveMateriaAIngresar, 2) == true) {
                if (this.compararSiExisteEseDato(conect, "plan_estudios", clavePlanAIngresar, 1) == true) {
                    if (this.compararSiExisteEseDato(conect, "usuarios", claveUsuarioAIngresar, 1) == true) {
                        s = conect.createStatement();
                        //;
                        ResultSet rs = s.executeQuery("select clv_materia, clv_plan, clv_usuario from materia_usuario");
                        while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                            if (rs.getString(1).equals(claveMateriaAIngresar) && rs.getString(2).equals(clavePlanAIngresar) && rs.getString(3).equals(claveUsuarioAIngresar)) {
                                System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                                registroExistente = true;
                            }
                        }
                        if (registroExistente == false) {
                            insersion = "INSERT INTO `materia_usuario` (`clv_materia`, `clv_plan`, `clv_usuario`, `puntos_confianza`, `puntos_director`) VALUES ('" + claveMateriaAIngresar + "', '" + clavePlanAIngresar + "', '" + claveUsuarioAIngresar + "', '" + puntosConfianza + "', '" + puntosDirector + "');";
                            s.execute(insersion);
                            System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                        }
                    } else {
                        if (!claveUsuarioAIngresar.equals("")) {
                            System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + claveUsuarioAIngresar + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        }
                    }
                } else {
                    if (!clavePlanAIngresar.equals("")) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clavePlanAIngresar + reset + " NO existe en la BD. Compruebe sus registro.\n");

                    }
                }
            } else {
                if (!claveMateriaAIngresar.equals("")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + claveMateriaAIngresar + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void insertarEnGruposConDatos(Connection conect, String clv_grupo, String turno) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            //NOTA IMPORTANTE, HABLAR EN EQUIPO SI SE HARA OTRA TABLA PARA EL VALOR NUMERICO DE TURNO (turno 1,2)
            //EN CASO DE SER ASI PONER LA PARTE DE LA COMPROBACION DE LA FOREGINKEY

            s = conect.createStatement();
            //;
            ResultSet rs = s.executeQuery("select clv_grupo, turno from grupos");
            while (!String.valueOf(rs.next()).equals("false")) {
                /*
					Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
					los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
				*/
                if (rs.getString(1).equals(clv_grupo)) {
                    System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                    registroExistente = true;
                }
            }
            if (registroExistente == false) {
                insersion = "INSERT INTO `grupos` (`clv_grupo`, `turno`) VALUES ('" + clv_grupo + "', '" + turno + "');";
                s.execute(insersion);
                System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");
            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    ///(conect, clv_usuario, idcarrera, nombre_usuario, nivel_ads, contrato)

    public void insertarEnUsuariosConDatos(Connection conect, String clv_usuario, String idcarrera, String nombre_usuario, String nivel_ads, String contrato) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "carrera", idcarrera, 1) == true) {
                s = conect.createStatement();
                //;
                ResultSet rs = s.executeQuery("select clv_usuario, idcarrera, nombre_usuario from usuarios");
                while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                    if (rs.getString(1).equals(clv_usuario)||rs.getString(2).equals(idcarrera)&&rs.getString(3).equals(nombre_usuario)) {
                        System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                        registroExistente = true;
                    }
                }
                if (registroExistente == false) {
                    insersion = "INSERT INTO `usuarios` (`clv_usuario`, `idcarrera`, `nombre_usuario`, `nivel_ads`, `contrato`) VALUES ('" + clv_usuario + "', '" + idcarrera + "', '" + nombre_usuario + "', '" + nivel_ads + "', '" + contrato + "');";
                    s.execute(insersion);
                    System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                }


            } else {
                if (!idcarrera.equals("")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + idcarrera + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void insertarEnAulasConDatos(Connection conect, String id_aula, String nombre, String tipo, String capacidad) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {
            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)

            s = conect.createStatement();
            ResultSet rs = s.executeQuery("select id_aula, nombre, tipo from aulas");
            while (!String.valueOf(rs.next()).equals("false")) {
                /*
					Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
					los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
				*/
                if (rs.getString(1).equals(id_aula)) {
                    System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                    registroExistente = true;
                }
            }
            if (registroExistente == false) {
                insersion = "INSERT INTO `aulas` (`id_aula`, `nombre`, `tipo`, `capacidad`) VALUES ('" + id_aula + "', '" + nombre + "', '" + tipo + "', '" + capacidad + "');";
                s.execute(insersion);
                System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void insertarEnLoginConDatos(Connection conect, String clv_usuario, String pass_usuario, String tipo_usuario) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "usuarios", clv_usuario, 1) == true) {
                s = conect.createStatement();
                ;
                ResultSet rs = s.executeQuery("select clv_usuario, pass_usuario from login");
                while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                    if (rs.getString(1).equals(clv_usuario)) {
                        System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                        registroExistente = true;
                    }
                }
                if (registroExistente == false) {
                    insersion = "INSERT INTO `login` (`clv_usuario`, `pass_usuario`, `tipo_usuario`) VALUES ('" + clv_usuario + "', '" + pass_usuario + "', '" + tipo_usuario + "');";
                    s.execute(insersion);
                    System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                }


            } else {
                if (!clv_usuario.equals("")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void insertarEnDisponibilidadConDatos(Connection conect, String dia, String espacio_tiempo, String clv_usuario) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "usuarios", clv_usuario, 1) == true) {
                s = conect.createStatement();
                ResultSet rs = s.executeQuery("select dia,espacio_tiempo,clv_usuario from disponibilidad");
                while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                    if (rs.getString(3).equals(clv_usuario)) {
                        System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                        registroExistente = true;
                    }
                }
                if (registroExistente == false) {
                    insersion = "INSERT INTO `disponibilidad` (`dia`, `espacio_tiempo`, `clv_usuario`) VALUES ('" + dia + "', '" + espacio_tiempo + "', '" + clv_usuario + "');";
                    s.execute(insersion);
                    System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                }


            } else {
                if (!clv_usuario.equals("")&&clv_usuario!=null&&!clv_usuario.equals("null")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void insertarEnGrupoMateriaProfesorConDatos(Connection conect, String clv_grupo, String clv_materia, String clv_usuario) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "grupos", clv_grupo, 1) == true) {
                if (this.compararSiExisteEseDato(conect, "materias", clv_materia, 2) == true) {
                    if (this.compararSiExisteEseDato(conect, "usuarios", clv_usuario, 1) == true) {
                        s = conect.createStatement();
                        ResultSet rs = s.executeQuery("select clv_grupo, clv_materia, clv_usuario from grupo_materia_profesor");
                        while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                            if (rs.getString(1).equals(clv_grupo) && rs.getString(2).equals(clv_materia) && rs.getString(3).equals(clv_usuario)) {
                                System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                                registroExistente = true;
                            }
                        }
                        if (registroExistente == false) {
                            insersion = "INSERT INTO `grupo_materia_profesor` (`clv_grupo`, `clv_materia`, `clv_usuario`) VALUES ('" + clv_grupo + "', '" + clv_materia + "', '" + clv_usuario + "');";
                            s.execute(insersion);
                            System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                        }
                    } else {
                        if (!clv_usuario.equals("")) {
                            System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_usuario + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        }
                    }
                } else {
                    if (!clv_materia.equals("")) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_materia + reset + " NO existe en la BD. Compruebe sus registro.\n");

                    }
                }
            } else {
                if (!clv_grupo.equals("")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_grupo + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void insertarEnUsoAulaGrupoConDatos(Connection conect, String dia, String espacio_tiempo, String id_aula, String clv_grupo, String clv_materia) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "aulas", id_aula, 1) == true) {
                if (this.compararSiExisteEseDato(conect, "grupos", clv_grupo, 1) == true) {
                    if (this.compararSiExisteEseDato(conect, "materias", clv_materia, 2) == true) {
                        s = conect.createStatement();
                        ResultSet rs = s.executeQuery("select dia, espacio_tiempo, id_aula,clv_grupo from uso_aula_grupo");
                        while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                            if (rs.getString(1).equals(dia) && rs.getString(2).equals(espacio_tiempo) && rs.getString(3).equals(id_aula) && rs.getString(4).equals(clv_grupo)) {
                                System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                                registroExistente = true;
                            }
                        }
                        if (registroExistente == false) {
                            insersion = "INSERT INTO `uso_aula_grupo` (`dia`, `espacio_tiempo`, `id_aula`, `clv_grupo`, `clv_materia`) VALUES ('" + dia + "', '" + espacio_tiempo + "', '" + id_aula + "', '" + clv_grupo + "', '" + clv_materia + "');";
                            s.execute(insersion);
                            System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                        }
                    } else {
                        if (!clv_materia.equals("")) {
                            System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_materia + reset + " NO existe en la BD. Compruebe sus registro.\n");
                        }
                    }
                } else {
                    if (!clv_grupo.equals("")) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_grupo + reset + " NO existe en la BD. Compruebe sus registro.\n");

                    }
                }
            } else {
                if (!id_aula.equals("")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_aula + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void insertarEnCarreraConDatos(Connection conect, String idcarrera, String nombre_carrera) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            s = conect.createStatement();
            //;
            ResultSet rs = s.executeQuery("select idcarrera, nombre_carrera from carrera");
            while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                if (rs.getString(1).equals(idcarrera) || rs.getString(2).equals(nombre_carrera)) {
                    System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                    registroExistente = true;
                }
            }
            if (registroExistente == false) {
                insersion = "INSERT INTO `carrera` (`idcarrera`, `nombre_carrera`) VALUES ('" + idcarrera + "', '" + nombre_carrera + "');";
                s.execute(insersion);
                System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void insertarEnCategoriasEquipoConDatos(Connection conect, String id_categoria, String nombre_categoria, String descripcion_categoria) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;
        try {

            s = conect.createStatement();
            //;
            ResultSet rs = s.executeQuery("select id_categoria, nombre_categoria from categorias_equipo");
            while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                if (rs.getString(1).equals(id_categoria) || rs.getString(2).equals(nombre_categoria)) {
                    System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                    registroExistente = true;
                }
            }
            if (registroExistente == false) {
				if(!id_categoria.equals("")&&!nombre_categoria.equals("")&&!descripcion_categoria.equals("")){
					insersion = "INSERT INTO `categorias_equipo` (`id_categoria`, `nombre_categoria`, `descripcion_categoria`) VALUES ('" + id_categoria + "', '" + nombre_categoria + "', '" + descripcion_categoria + "');";
					s.execute(insersion);
					System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");
				}
                

            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void insertarEnEquipoConDatos(Connection conect, String id_equipo, String nombre, String descripcion, String id_categoria) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "categorias_equipo", id_categoria, 1) == true) {
                s = conect.createStatement();
                //;
                ResultSet rs = s.executeQuery("select id_equipo, nombre from equipo");
                while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                    if (rs.getString(1).equals(id_equipo) || rs.getString(2).equals(nombre)) {
                        System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                        registroExistente = true;
                    }
                }
                if (registroExistente == false) {
                    insersion = "INSERT INTO `equipo` (`id_equipo`, `nombre`, `descripcion`, `id_categoria`) VALUES ('" + id_equipo + "', '" + nombre + "', '" + descripcion + "', '" + id_categoria + "');";
                    s.execute(insersion);
                    System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                }

            } else {
                if (!id_categoria.equals("")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_categoria + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void insertarEnPlanEstudiosConDatos(Connection conect, String clv_plan, String nombre_plan, String nivel, String idcarrera) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {
            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "carrera", idcarrera, 1) == true) {

                s = conect.createStatement();
                //;
                ResultSet rs = s.executeQuery("select clv_plan, nombre_plan from plan_estudios");
                while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                    if (rs.getString(1).equals(clv_plan) || rs.getString(2).equals(nombre_plan)) {
                        System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                        registroExistente = true;
                    }
                }
                if (registroExistente == false) {
                    insersion = "INSERT INTO `plan_estudios` (`clv_plan`, `nombre_plan`, `nivel`, `idcarrera`) VALUES ('" + clv_plan + "', '" + nombre_plan + "', '" + nivel + "', '" + idcarrera + "');";
                    s.execute(insersion);
                    System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                }

            } else {
                if (!idcarrera.equals("")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + idcarrera + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void insertarEnMateriasConDatos(Connection conect, String nombre_materia, String clv_materia, String creditos, String cuatrimestre, String posicion, String clv_plan, String horas_x_semana, String tipo_materia) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;

        try {

            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "plan_estudios", clv_plan, 1) == true) {
                s = conect.createStatement();
                //;
                ResultSet rs = s.executeQuery("select nombre_materia, clv_materia from materias");
                while (!String.valueOf(rs.next()).equals("false")) {

							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores clv_materia, clv_plan y clv_usuario no sean los mismos que otra fila.
							*/
                    if (rs.getString(1).equals(nombre_materia) || rs.getString(2).equals(clv_materia)) {
                        System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                        registroExistente = true;
                    }
                }
                if (registroExistente == false) {
                    insersion = "INSERT INTO `materias` (`nombre_materia`, `clv_materia`, `creditos`, `cuatrimestre`, `posicion`, `clv_plan`, `horas_x_semana`, `tipo_materia`) VALUES ('" + nombre_materia + "', '" + clv_materia + "', '" + creditos + "', '" + cuatrimestre + "', '" + posicion + "','" + clv_plan + "','" + horas_x_semana + "','" + tipo_materia + "');";
                    s.execute(insersion);
                    System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                }
            } else {
                if (!clv_plan.equals("")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + clv_plan + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public void insertarEnAulaEquipoConDatos(Connection conect, String id_equipo, String id_aula, String cantidad) {
        String insersion = "";
        boolean registroExistente = false;
        Statement s = null;
        try {
            //Aquí valida las Foreign Key (Que éstas existan en las tablas dependientes)
            if (this.compararSiExisteEseDato(conect, "equipo", id_equipo, 1) == true) {
                if (this.compararSiExisteEseDato(conect, "aulas", id_aula, 1) == true) {
                    s = conect.createStatement();
                    //;
                    ResultSet rs = s.executeQuery("select id_equipo, id_aula from aula_equipo");
                    while (!String.valueOf(rs.next()).equals("false")) {
							/*
							Aquí valida si el registro que se intenta ingresar ya existe en la tabla o no. Comparando que
							los valores no sean los mismos que otra fila.
							*/
                        if (rs.getString(1).equals(id_equipo)||rs.getString(2).equals(id_aula)) {
                            System.out.println(yellow + "[Advertencia] " + reset + "Un registro ingresado ya existe en la tabla");
                            registroExistente = true;
                        }
                    }
                    if (registroExistente == false) {
                        insersion = "INSERT INTO `aula_equipo` (`id_equipo`, `id_aula`, `cantidad`) VALUES ('" + id_equipo + "', '" + id_aula + "', '" + cantidad + "');";
                        s.execute(insersion);
                        System.out.println(green + "[Exito] " + reset + "Datos ingresados correctamente");

                    }

                } else {
                    if (!id_aula.equals("")) {
                        System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_aula + reset + " NO existe en la BD. Compruebe sus registro.\n");

                    }
                }
            } else {
                if (!id_equipo.equals("")) {
                    System.out.println(yellow + "\n[Advertencia] " + reset + "El valor " + cyan + id_equipo + reset + " NO existe en la BD. Compruebe sus registro.\n");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public boolean compararSiExisteEseDato(Connection conect, String tablaEnLaQueSeVaAComparar, String id_valorIngresado, int posicionColumnaEnLaQueSeInsertara) {
        boolean existeValorEnBD = false;
        try {

            Statement s = conect.createStatement();
            //;
            ResultSet rs = s.executeQuery("select * from " + tablaEnLaQueSeVaAComparar);

            while (!String.valueOf(rs.next()).equals("false")) {
                if (rs.getString(posicionColumnaEnLaQueSeInsertara).equals(id_valorIngresado)) {
                    existeValorEnBD = true;
                }
            }

        } catch(NumberFormatException e){
			
		} catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion: " + e);
        }
        return existeValorEnBD; //Retorna el boolean de si encontró coincidencia o no.
    }

}