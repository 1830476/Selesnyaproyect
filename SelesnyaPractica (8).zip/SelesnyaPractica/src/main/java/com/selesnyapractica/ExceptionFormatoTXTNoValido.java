package com.selesnyapractica;

public class ExceptionFormatoTXTNoValido extends Exception {

    public ExceptionFormatoTXTNoValido(String msg) {
        super(msg);
    }
    
}
