package com.selesnyapractica;

import java.util.Scanner;
import java.sql.SQLException;
/**
 * Hello world!
 *
 */
public class Menu
{
    
	public void iniciar() throws SQLException {
		
		//Para colores en consola
		String red="\033[31m";
		String green="\033[32m";
		String yellow="\033[33m";
		String reset="\u001B[0m";
		String cyan="\033[36m";
		String purple="\033[35m";
		String seleccion="";

		TestInsersion t = new TestInsersion();
		MenuTXTyXLSX men = new MenuTXTyXLSX();
		ConexionGestor cone = new ConexionGestor();
		SoloEjemploConsulta sec = new SoloEjemploConsulta();
        Scanner entrada = new Scanner(System.in);
		CRUD crud = new CRUD();
		
		this.limpiarConsola();
		System.out.println(yellow+"[Recordatorio] "+reset+"¿Ya hiciste pull antes de realizar modificaciones locales?\n\n");
		System.out.println(cyan+"-----------------------------------------------------------"+reset);
		System.out.println(purple+"Bienvenido a la practica elaborada por la familia "+cyan+"Selesnya"+purple+"."+reset);
		System.out.println(cyan+"-----------------------------------------------------------\n\n"+reset);
		do{
			
			System.out.println("Por favor, seleccione el numero del modulo que desea ejecutar: \n"+yellow);
			System.out.print(yellow+"1) CRUD\n2) Lectura de archivos XLSX\n3) Lectura de archivosTXT\n4) Conexion a la base de datos\n0) Salir\n\n"+reset+">");
			seleccion=entrada.nextLine();
			switch(seleccion){
				case "1":
					this.limpiarConsola();
					seleccion="0";
					crud.menuCRUD(cone.conexion());
					break;
				case "2":
					this.limpiarConsola();
					seleccion="0";
					men.menuLectura(cone.conexion(),"2");
					break;
				case "3":
					this.limpiarConsola();
					seleccion="0";
					men.menuLectura(cone.conexion(),"3");
					break;
				case "4":
					seleccion="0";
					cone.conexion();
					break;
				case "0":
					System.out.println("\n\nFinalizando programa.");
					break;
				default:
					this.limpiarConsola();
					System.out.println(red+"[Error] "+reset+"Ha capturado un valor incorrecto. Intente de nuevo\n");
					break;
			}
		}while(!seleccion.equals("0"));
		this.saltoLinea();
	}
	
	//Extras
    public void limpiarConsola() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception e) {
        }

    }

	public void esperar() {
		try {
			Thread.sleep(3 * 1000);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void saltoLinea(){
		System.out.println("\n\n\n\n\n");
	}
}
