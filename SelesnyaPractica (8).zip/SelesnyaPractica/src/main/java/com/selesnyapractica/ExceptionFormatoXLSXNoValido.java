package com.selesnyapractica;

public class ExceptionFormatoXLSXNoValido extends Exception {

    public ExceptionFormatoXLSXNoValido(String msg) {
        super(msg);
    }
    //throw new ExceptionNoDataBaseFound(yellow+"ADVERTENCIA: "+reset+"No se encontró una base de datos. Creando una nueva...\n\n");
}
