package com.selesnyapractica;

public class MateriaUsuario {

    private String clvMateria;
    private String clvPlan;
    private String clvUsuario;
    private String puntosConfianza;
    private String puntosDirector;

    public MateriaUsuario(String clvMateria, String clvPlan, String clvUsuario, String puntosConfianza, String puntosDirector) {
        this.clvMateria = clvMateria;
        this.clvPlan = clvPlan;
        this.clvUsuario = clvUsuario;
        this.puntosConfianza = puntosConfianza;
        this.puntosDirector = puntosDirector;
    }

    public String getClvMateria() {
        return clvMateria;
    }

    public void setClvMateria(String clvMateria) {
        this.clvMateria = clvMateria;
    }

    public String getClvPlan() {
        return clvPlan;
    }

    public void setClvPlan(String clvPlan) {
        this.clvPlan = clvPlan;
    }

    public String getClvUsuario() {
        return clvUsuario;
    }

    public void setClvUsuario(String clvUsuario) {
        this.clvUsuario = clvUsuario;
    }

    public String getPuntosConfianza() {
        return puntosConfianza;
    }

    public void setPuntosConfianza(String puntosConfianza) {
        this.puntosConfianza = puntosConfianza;
    }

    public String getPuntosDirector() {
        return puntosDirector;
    }

    public void setPuntosDirector(String puntosDirector) {
        this.puntosDirector = puntosDirector;
    }
}
