package com.selesnyapractica;

public class Materias {

    private String nombreMateria;
    private String clvMateria;
    private String creditos;
    private String cuatrimestre;
    private String posicion;
    private String clvPlan;
    private String horasXSemana;
    private String tipoMateria;

    public Materias(String nombreMateria, String clvMateria, String creditos, String cuatrimestre, String posicion, String clvPlan, String horasXSemana, String tipoMateria) {
        this.nombreMateria = nombreMateria;
        this.clvMateria = clvMateria;
        this.creditos = creditos;
        this.cuatrimestre = cuatrimestre;
        this.posicion = posicion;
        this.clvPlan = clvPlan;
        this.horasXSemana = horasXSemana;
        this.tipoMateria = tipoMateria;
    }

    public String getNombreMateria() {
        return nombreMateria;
    }

    public void setNombreMateria(String nombreMateria) {
        this.nombreMateria = nombreMateria;
    }

    public String getClvMateria() {
        return clvMateria;
    }

    public void setClvMateria(String clvMateria) {
        this.clvMateria = clvMateria;
    }

    public String getCreditos() {
        return creditos;
    }

    public void setCreditos(String creditos) {
        this.creditos = creditos;
    }

    public String getCuatrimestre() {
        return cuatrimestre;
    }

    public void setCuatrimestre(String cuatrimestre) {
        this.cuatrimestre = cuatrimestre;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public String getClvPlan() {
        return clvPlan;
    }

    public void setClvPlan(String clvPlan) {
        this.clvPlan = clvPlan;
    }

    public String getHorasXSemana() {
        return horasXSemana;
    }

    public void setHorasXSemana(String horasXSemana) {
        this.horasXSemana = horasXSemana;
    }

    public String getTipoMateria() {
        return tipoMateria;
    }

    public void setTipoMateria(String tipoMateria) {
        this.tipoMateria = tipoMateria;
    }
}
