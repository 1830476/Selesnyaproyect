package com.selesnyapractica;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

public class CargarTablas{

    static ConexionGestor cone = new ConexionGestor();

    public ArrayList<AulaEquipo> cargaAulaEquipo() throws SQLException {

        ArrayList<AulaEquipo> arrayAulaEquipo = new ArrayList<AulaEquipo>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from aula_equipo");

        String idEquipoAulaEquipo="";
        String idAulaAulaEquipo="";
        String cantidadAulaEquipo="";

        while(!String.valueOf(rs.next()).equals("false")) {

            idEquipoAulaEquipo = rs.getString(1);
            idAulaAulaEquipo = rs.getString(2);
            cantidadAulaEquipo = rs.getString(3);


            arrayAulaEquipo.add(new AulaEquipo(idEquipoAulaEquipo,idAulaAulaEquipo,cantidadAulaEquipo));
        }

        return arrayAulaEquipo;
    }

    public ArrayList<Aulas> cargarAulas() throws SQLException {

        ArrayList<Aulas> arrayAulas = new ArrayList<Aulas>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from aulas");

        String idAulaAula="";
        String nombre="";
        String tipo="";
        String capacidad="";

        while(!String.valueOf(rs.next()).equals("false")) {

            idAulaAula = rs.getString(1);
            nombre = rs.getString(2);
            tipo = rs.getString(3);
            capacidad = rs.getString(4);


            arrayAulas.add(new Aulas(idAulaAula,nombre,tipo,capacidad));
        }

        return arrayAulas;
    }

    public ArrayList<Carrera> cargarCarrera() throws SQLException {

        ArrayList<Carrera> arrayCarrera = new ArrayList<Carrera>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from carrera");

        String idCarrera="";
        String nombreCarrera="";

        while(!String.valueOf(rs.next()).equals("false")) {
            idCarrera = rs.getString(1);
            nombreCarrera = rs.getString(2);

            arrayCarrera.add(new Carrera(idCarrera,nombreCarrera));
        }
        return arrayCarrera;
    }

    public ArrayList<CategoriasEquipo> cargarCategoriasEquipo() throws SQLException {

        ArrayList<CategoriasEquipo> arrayCategoriasEquipo = new ArrayList<CategoriasEquipo>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from categorias_equipo");

        String idCategoria="";
        String nombreCategoria="";
        String descripcionCategoria="";

        while(!String.valueOf(rs.next()).equals("false")) {
            idCategoria = rs.getString(1);
            nombreCategoria = rs.getString(2);
            descripcionCategoria = rs.getString(3);

            arrayCategoriasEquipo.add(new CategoriasEquipo(idCategoria,nombreCategoria,descripcionCategoria));
        }
        return arrayCategoriasEquipo;
    }

    public ArrayList<Disponibilidad> cargarDisponibilidad() throws SQLException {

        ArrayList<Disponibilidad> arrayDisponibilidad = new ArrayList<Disponibilidad>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from disponibilidad");

        String dia="";
        String espacioTiempo="";
        String clvUsuario="";

        while(!String.valueOf(rs.next()).equals("false")) {
            dia = rs.getString(1);
            espacioTiempo = rs.getString(2);
            clvUsuario = rs.getString(3);

            arrayDisponibilidad.add(new Disponibilidad(dia,espacioTiempo,clvUsuario));
        }
        return arrayDisponibilidad;
    }

    public ArrayList<Equipo> cargarEquipo() throws SQLException {

        ArrayList<Equipo> arrayEquipo = new ArrayList<Equipo>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from equipo");

        String idEquipo="";
        String nombre="";
        String descripcion="";
        String idCategoria="";

        while(!String.valueOf(rs.next()).equals("false")) {
            idEquipo = rs.getString(1);
            nombre = rs.getString(2);
            descripcion = rs.getString(3);
            idCategoria = rs.getString(4);

            arrayEquipo.add(new Equipo(idEquipo,nombre,descripcion, idCategoria));
        }
        return arrayEquipo;
    }

    public ArrayList<Grupos> cargarGrupos() throws SQLException {

        ArrayList<Grupos> arrayGrupos = new ArrayList<Grupos>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from grupos");

        String clvGrupo="";
        String turno="";


        while(!String.valueOf(rs.next()).equals("false")) {
            clvGrupo = rs.getString(1);
            turno = rs.getString(2);

            arrayGrupos.add(new Grupos(clvGrupo,turno));
        }
        return arrayGrupos;
    }

    public ArrayList<GruposMateriasProfesor> cargarGruposMateriasProfesor() throws SQLException {

        ArrayList<GruposMateriasProfesor> arrayGruposMateriasProfesor = new ArrayList<GruposMateriasProfesor>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from grupo_materia_profesor");

        String clvGrupo="";
        String clvMateria="";
        String clvUsuario="";


        while(!String.valueOf(rs.next()).equals("false")) {
            clvGrupo = rs.getString(1);
            clvMateria = rs.getString(2);
            clvUsuario = rs.getString(3);

            arrayGruposMateriasProfesor.add(new GruposMateriasProfesor(clvGrupo,clvMateria,clvUsuario));
        }
        return arrayGruposMateriasProfesor;
    }

    public ArrayList<Login> cargarLogin() throws SQLException {

        ArrayList<Login> arrayLogin = new ArrayList<Login>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from login");

        String clvUsuario="";
        String passUsuario="";
        String tipoUsuario="";


        while(!String.valueOf(rs.next()).equals("false")) {
            clvUsuario = rs.getString(1);
            passUsuario = rs.getString(2);
            tipoUsuario = rs.getString(3);

            arrayLogin.add(new Login(clvUsuario,passUsuario,tipoUsuario));
        }
        return arrayLogin;
    }
    public ArrayList<MateriaUsuario> cargarMateriaUsuario() throws SQLException {

        ArrayList<MateriaUsuario> arrayMateriaUsuario = new ArrayList<MateriaUsuario>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from materia_usuario");

        String clvMateria="";
        String clvPlan="";
        String clvUsuario="";
        String puntosConfianza="";
        String puntosDirector="";


        while(!String.valueOf(rs.next()).equals("false")) {
            clvMateria = rs.getString(1);
            clvPlan = rs.getString(2);
            clvUsuario = rs.getString(3);
            puntosConfianza = rs.getString(4);
            puntosDirector = rs.getString(5);

            arrayMateriaUsuario.add(new MateriaUsuario(clvMateria,clvPlan,clvUsuario, puntosConfianza, puntosDirector));
        }
        return arrayMateriaUsuario;
    }

    public ArrayList<Materias> cargarMaterias() throws SQLException {

        ArrayList<Materias> arrayMaterias = new ArrayList<Materias>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from materias");

        String nombreMateria="";
        String clvMateria="";
        String creditos="";
        String cuatrimestre="";
        String posicion="";
        String clvPlan="";
        String horasXSemana="";
        String tipoMaterias="";

        while(!String.valueOf(rs.next()).equals("false")) {
            nombreMateria = rs.getString(1);
            clvMateria = rs.getString(2);
            creditos = rs.getString(3);
            cuatrimestre = rs.getString(4);
            posicion = rs.getString(5);
            clvPlan = rs.getString(6);
            horasXSemana = rs.getString(7);
            tipoMaterias = rs.getString(8);

            arrayMaterias.add(new Materias(nombreMateria,clvMateria,creditos, cuatrimestre, posicion, clvPlan, horasXSemana, tipoMaterias));
        }
        return arrayMaterias;
    }

    public ArrayList<PlanEstudios> cargarPlanEstudios() throws SQLException {

        ArrayList<PlanEstudios> arrayPlanEstudios = new ArrayList<PlanEstudios>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from plan_estudios");

        String clvPlan="";
        String nombrePlan="";
        String nivel="";
        String idCarrera="";

        while(!String.valueOf(rs.next()).equals("false")) {
            clvPlan = rs.getString(1);
            nombrePlan = rs.getString(2);
            nivel = rs.getString(3);
            idCarrera = rs.getString(4);

            arrayPlanEstudios.add(new PlanEstudios(clvPlan,nombrePlan,nivel, idCarrera));
        }
        return arrayPlanEstudios;
    }

    public ArrayList<UsoAulaGrupo> cargarUsoAulaGrupo() throws SQLException {

        ArrayList<UsoAulaGrupo> arrayUsoAulaGrupo = new ArrayList<UsoAulaGrupo>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from uso_aula_grupo");

        String dia="";
        String espacioTiempo="";
        String idAula="";
        String clvGrupo="";
        String clvMateria="";

        while(!String.valueOf(rs.next()).equals("false")) {
            dia = rs.getString(1);
            espacioTiempo = rs.getString(2);
            idAula = rs.getString(3);
            clvGrupo = rs.getString(4);
            clvMateria = rs.getString(5);

            arrayUsoAulaGrupo.add(new UsoAulaGrupo(dia,espacioTiempo,idAula, clvGrupo, clvMateria));
        }
        return arrayUsoAulaGrupo;
    }

    public ArrayList<Usuarios> cargarUsuarios() throws SQLException {

        ArrayList<Usuarios> arrayUsuarios = new ArrayList<Usuarios>();

        Statement s = cone.conexion().createStatement();
        ResultSet rs = s.executeQuery("select * from usuarios");

        String clvUsuario="";
        String idCarrera="";
        String nombreUsuario="";
        String nivelAds="";
        String contrato="";

        while(!String.valueOf(rs.next()).equals("false")) {
            clvUsuario = rs.getString(1);
            idCarrera = rs.getString(2);
            nombreUsuario = rs.getString(3);
            nivelAds = rs.getString(4);
            contrato = rs.getString(5);

            arrayUsuarios.add(new Usuarios(clvUsuario,idCarrera,nombreUsuario, nivelAds, contrato));
        }
        return arrayUsuarios;
    }

}
