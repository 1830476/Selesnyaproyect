package com.selesnyapractica;

public class Disponibilidad {

    private String dia;
    private String espacioTiempo;
    private String clvUsuario;

    public Disponibilidad(String dia, String espacioTiempo, String clvUsuario) {
        this.dia = dia;
        this.espacioTiempo = espacioTiempo;
        this.clvUsuario = clvUsuario;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getEspacioTiempo() {
        return espacioTiempo;
    }

    public void setEspacioTiempo(String espacioTiempo) {
        this.espacioTiempo = espacioTiempo;
    }

    public String getClvUsuario() {
        return clvUsuario;
    }

    public void setClvUsuario(String clvUsuario) {
        this.clvUsuario = clvUsuario;
    }
}
