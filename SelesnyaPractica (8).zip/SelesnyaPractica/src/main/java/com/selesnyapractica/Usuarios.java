package com.selesnyapractica;

public class Usuarios {

    private String clvUsuario;
    private String idCarrera;
    private String nombreUsuario;
    private String nivelAds;
    private String contrato;

    public Usuarios(String clvUsuario, String idCarrera, String nombreUsuario, String nivelAds, String contrato) {
        this.clvUsuario = clvUsuario;
        this.idCarrera = idCarrera;
        this.nombreUsuario = nombreUsuario;
        this.nivelAds = nivelAds;
        this.contrato = contrato;
    }

    public String getClvUsuario() {
        return clvUsuario;
    }

    public void setClvUsuario(String clvUsuario) {
        this.clvUsuario = clvUsuario;
    }

    public String getIdCarrera() {
        return idCarrera;
    }

    public void setIdCarrera(String idCarrera) {
        this.idCarrera = idCarrera;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getNivelAds() {
        return nivelAds;
    }

    public void setNivelAds(String nivelAds) {
        this.nivelAds = nivelAds;
    }

    public String getContrato() {
        return contrato;
    }

    public void setContrato(String contrato) {
        this.contrato = contrato;
    }
}
