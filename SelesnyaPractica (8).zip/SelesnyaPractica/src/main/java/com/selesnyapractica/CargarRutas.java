package com.selesnyapractica;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CargarRutas {

    //Para colores en consola
    private String red="\033[31m";
    private String green="\033[32m";
    private String yellow="\033[33m";
    private String reset="\u001B[0m";
    private String cyan="\033[36m";
	
    String rutaConfig;
	String rutaAbsoluta="";
	
    private String excelData;
	private String gestor;
	private String rutaScriptLocal;
	private String rutaBDTemporal;
    private String puertoMySQL;
    private String nombreBD;
    private String user;
    private String password;

    //Variables txt
    private String materia_usuarioTXT;
    private String aulasTXT;
    private String aulas_equipoTXT;
    private String carreraTXT;
    private String categorias_equipoTXT;
    private String disponibilidadTXT;
    private String equipoTXT;
    private String grupo_materia_profesorTXT;
    private String gruposTXT;
    private String loginTXT;
    private String materiasTXT;
    private String plan_estudiosTXT;
    private String uso_aula_grupoTXT;
    private String usuariosTXT;

    //Variables xlsx
    private String materia_usuarioXLSX;
    private String aulasXLSX;
    private String aulas_equipoXLSX;
    private String carreraXLSX;
    private String categorias_equipoXLSX;
    private String disponibilidadXLSX;
    private String equipoXLSX;
    private String grupo_materia_profesorXLSX;
    private String gruposXLSX;
    private String loginXLSX;
    private String materiasXLSX;
    private String plan_estudiosXLSX;
    private String uso_aula_grupoXLSX;
    private String usuariosXLSX;

    Scanner entrada = null;

    public void cargarRutas(){
        rutaConfig="src/main/resources/rutas.config";
        String linea="";
        int pos;
        try {

            
			File fGetRuta = new File("rutas.config");
			String rutaAbsoluta = String.valueOf(fGetRuta.getAbsolutePath().substring(0,fGetRuta.getAbsolutePath().indexOf("ruta")));
			rutaConfig=rutaAbsoluta+rutaConfig;
			
			File f = new File(rutaConfig);
			
            entrada = new Scanner(f);
            while (entrada.hasNext()) {
                linea=entrada.nextLine();
                pos=linea.indexOf("=")+1;

                if(pos!=-1 && linea.substring(0,pos).equals("data=")){
                    this.excelData=linea.substring(pos,linea.length());
					this.excelData=rutaAbsoluta+this.excelData;
                }
				if(pos!=-1 && linea.substring(0,pos).equals("gestor=")){
                    this.gestor=linea.substring(pos,linea.length());
                }
				if(pos!=-1 && linea.substring(0,pos).equals("puertoMySQL=")){
                    this.puertoMySQL=linea.substring(pos,linea.length());
                }
                if(pos!=-1 && linea.substring(0,pos).equals("nombreBD=")){
                    this.nombreBD=linea.substring(pos,linea.length());
                }
                if(pos!=-1 && linea.substring(0,pos).equals("user=")){
                    this.user=linea.substring(pos,linea.length());
                }
                if(pos!=-1 && linea.substring(0,pos).equals("password=")){
                    this.password=linea.substring(pos,linea.length());
                }
                if(pos!=-1 && linea.substring(0,pos).equals("scriptLocal=")){
                    this.rutaScriptLocal=linea.substring(pos,linea.length());
					this.rutaScriptLocal=rutaAbsoluta+this.rutaScriptLocal;
                }
				if(pos!=-1 && linea.substring(0,pos).equals("rutaBDTemporal=")){
                    this.rutaBDTemporal=linea.substring(pos,linea.length());
					if(rutaBDTemporal.equals("")){
						this.rutaBDTemporal=rutaAbsoluta+"src/main/resources/mydatabase.db";
					}else{
						this.rutaBDTemporal=rutaAbsoluta+this.rutaBDTemporal;
					}
                    
                }
				
				//txt
                if(pos!=-1 && linea.substring(0,pos).equals("materia_usuarioTXT=")){
                    this.materia_usuarioTXT=linea.substring(pos,linea.length());
                    this.materia_usuarioTXT=rutaAbsoluta+this.materia_usuarioTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("aulasTXT=")){
                    this.aulasTXT=linea.substring(pos,linea.length());
                    this.aulasTXT=rutaAbsoluta+this.aulasTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("aula_equipoTXT=")){
                    this.aulas_equipoTXT=linea.substring(pos,linea.length());
                    this.aulas_equipoTXT=rutaAbsoluta+this.aulas_equipoTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("carreraTXT=")){
                    this.carreraTXT=linea.substring(pos,linea.length());
                    this.carreraTXT=rutaAbsoluta+this.carreraTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("categorias_equipoTXT=")){
                    this.categorias_equipoTXT=linea.substring(pos,linea.length());
                    this.categorias_equipoTXT=rutaAbsoluta+this.categorias_equipoTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("disponibilidadTXT=")){
                    this.disponibilidadTXT=linea.substring(pos,linea.length());
                    this.disponibilidadTXT=rutaAbsoluta+this.disponibilidadTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("equipoTXT=")){
                    this.equipoTXT=linea.substring(pos,linea.length());
                    this.equipoTXT=rutaAbsoluta+this.equipoTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("grupo_materia_profesorTXT=")){
                    this.grupo_materia_profesorTXT=linea.substring(pos,linea.length());
                    this.grupo_materia_profesorTXT=rutaAbsoluta+this.grupo_materia_profesorTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("gruposTXT=")){
                    this.gruposTXT=linea.substring(pos,linea.length());
                    this.gruposTXT=rutaAbsoluta+this.gruposTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("loginTXT=")){
                    this.loginTXT=linea.substring(pos,linea.length());
                    this.loginTXT=rutaAbsoluta+this.loginTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("materiasTXT=")){
                    this.materiasTXT=linea.substring(pos,linea.length());
                    this.materiasTXT=rutaAbsoluta+this.materiasTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("plan_estudiosTXT=")){
                    this.plan_estudiosTXT=linea.substring(pos,linea.length());
                    this.plan_estudiosTXT=rutaAbsoluta+this.plan_estudiosTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("uso_aula_grupoTXT=")){
                    this.uso_aula_grupoTXT=linea.substring(pos,linea.length());
                    this.uso_aula_grupoTXT=rutaAbsoluta+this.uso_aula_grupoTXT;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("usuariosTXT=")){
                    this.usuariosTXT=linea.substring(pos,linea.length());
                    this.usuariosTXT=rutaAbsoluta+this.usuariosTXT;
                }
                //xlsx
                if(pos!=-1 && linea.substring(0,pos).equals("materia_usuarioXLSX=")){
                    this.materia_usuarioXLSX=linea.substring(pos,linea.length());
                    this.materia_usuarioXLSX=rutaAbsoluta+this.materia_usuarioXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("aulasXLSX=")){
                    this.aulasXLSX=linea.substring(pos,linea.length());
                    this.aulasXLSX=rutaAbsoluta+this.aulasXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("aula_equipoXLSX=")){
                    this.aulas_equipoXLSX=linea.substring(pos,linea.length());
                    this.aulas_equipoXLSX=rutaAbsoluta+this.aulas_equipoXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("carreraXLSX=")){
                    this.carreraXLSX=linea.substring(pos,linea.length());
                    this.carreraXLSX=rutaAbsoluta+this.carreraXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("categorias_equipoXLSX=")){
                    this.categorias_equipoXLSX=linea.substring(pos,linea.length());
                    this.categorias_equipoXLSX=rutaAbsoluta+this.categorias_equipoXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("disponibilidadXLSX=")){
                    this.disponibilidadXLSX=linea.substring(pos,linea.length());
                    this.disponibilidadXLSX=rutaAbsoluta+this.disponibilidadXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("equipoXLSX=")){
                    this.equipoXLSX=linea.substring(pos,linea.length());
                    this.equipoXLSX=rutaAbsoluta+this.equipoXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("grupo_materia_profesorXLSX=")){
                    this.grupo_materia_profesorXLSX=linea.substring(pos,linea.length());
                    this.grupo_materia_profesorXLSX=rutaAbsoluta+this.grupo_materia_profesorXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("gruposXLSX=")){
                    this.gruposXLSX=linea.substring(pos,linea.length());
                    this.gruposXLSX=rutaAbsoluta+this.gruposXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("loginXLSX=")){
                    this.loginXLSX=linea.substring(pos,linea.length());
                    this.loginXLSX=rutaAbsoluta+this.loginXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("materiasXLSX=")){
                    this.materiasXLSX=linea.substring(pos,linea.length());
                    this.materiasXLSX=rutaAbsoluta+this.materiasXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("plan_estudiosXLSX=")){
                    this.plan_estudiosXLSX=linea.substring(pos,linea.length());
                    this.plan_estudiosXLSX=rutaAbsoluta+this.plan_estudiosXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("uso_aula_grupoXLSX=")){
                    this.uso_aula_grupoXLSX=linea.substring(pos,linea.length());
                    this.uso_aula_grupoXLSX=rutaAbsoluta+this.uso_aula_grupoXLSX;
                }
                if(pos!=-1 && linea.substring(0,pos).equals("usuariosXLSX=")){
                    this.usuariosXLSX=linea.substring(pos,linea.length());
                    this.usuariosXLSX=rutaAbsoluta+this.usuariosXLSX;
                }
            }
			
			
			
        } catch (FileNotFoundException e) {
            System.out.println(red+"[Error] "+reset+"No se encontró el archivox "+e);
        } catch (NullPointerException e) {
            System.out.println(red+"[Error] "+reset+"No se seleccionó ningun archivo");
        } catch (Exception e) {
            System.out.println(red+"[Error] "+reset+"Error "+e);
        } finally {
            if (entrada != null) {
                entrada.close();
            }
        }
    }
	
    //Getters
	public String getMateriaUsuarioTXT() {
        return materia_usuarioTXT;
    }
	
	public String getRutaBDTemporal(){
		return rutaBDTemporal;
	}
	
	public String getMateriaUsuarioXLSX() {
        return materia_usuarioXLSX;
    }

	public String getPuertoMySQL() {
        return puertoMySQL;
    }

    public String getNombreBD() {
        return nombreBD;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }
	
	public String getGestor() {
        return gestor;
    }
	
    public String getRutaScriptLocal() {
        return rutaScriptLocal;
    }

    public String getAulasTXT() {
        return aulasTXT;
    }

    public String getAulas_equipoTXT() {
        return aulas_equipoTXT;
    }

    public String getCarreraTXT() {
        return carreraTXT;
    }

    public String getCategorias_equipoTXT() {
        return categorias_equipoTXT;
    }

    public String getDisponibilidadTXT() {
        return disponibilidadTXT;
    }

    public String getEquipoTXT() {
        return equipoTXT;
    }

    public String getGrupo_materia_profesorTXT() {
        return grupo_materia_profesorTXT;
    }

    public String getGruposTXT() {
        return gruposTXT;
    }

    public String getLoginTXT() {
        return loginTXT;
    }

    public String getMateriasTXT() {
        return materiasTXT;
    }

    public String getPlan_estudiosTXT() {
        return plan_estudiosTXT;
    }

    public String getUso_aula_grupoTXT() {
        return uso_aula_grupoTXT;
    }

    public String getUsuariosTXT() {
        return usuariosTXT;
    }

    public String getAulasXLSX() {
        return aulasXLSX;
    }

    public String getAulas_equipoXLSX() {
        return aulas_equipoXLSX;
    }

    public String getCarreraXLSX() {
        return carreraXLSX;
    }

    public String getCategorias_equipoXLSX() {
        return categorias_equipoXLSX;
    }

    public String getDisponibilidadXLSX() {
        return disponibilidadXLSX;
    }

    public String getEquipoXLSX() {
        return equipoXLSX;
    }

    public String getGrupo_materia_profesorXLSX() {
        return grupo_materia_profesorXLSX;
    }

    public String getGruposXLSX() {
        return gruposXLSX;
    }

    public String getLoginXLSX() {
        return loginXLSX;
    }

    public String getMateriasXLSX() {
        return materiasXLSX;
    }

    public String getPlan_estudiosXLSX() {
        return plan_estudiosXLSX;
    }

    public String getUso_aula_grupoXLSX() {
        return uso_aula_grupoXLSX;
    }

    public String getUsuariosXLSX() {
        return usuariosXLSX;
    }
}
