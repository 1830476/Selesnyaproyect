package com.selesnyapractica;

import java.io.File;
import java.sql.SQLSyntaxErrorException;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

public class ConexionMySQL {

    private CargarRutas cr = new CargarRutas();
    private Connection conect = null;
    private CRUD crud = new CRUD();
	
    private String nombreBD;
    private String user;
    private String password;
    private String puertoMySQL;
    private String rutaScriptLocal;
    private String linea;

    //Para colores en consola
    private String red = "\033[31m";
    private String green = "\033[32m";
    private String yellow = "\033[33m";
    private String reset = "\u001B[0m";
    private String cyan = "\033[36m";
    private boolean errorSQL=false;
    public Connection conexion() {
        this.limpiarConsola();
        this.cargarRutas();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conect = DriverManager.getConnection("jdbc:mysql://localhost:" + puertoMySQL + "/", user, password);
            if (conect != null) {
                System.out.println(green + "[Conexion establecida con el Servidor]" + reset);

                Statement s = conect.createStatement();
                ResultSet a = s.executeQuery("use " + nombreBD);

                System.out.println(green + "[Conexion establecida con la BD]\n\n" + reset);
				//<------------ TE COMENTÉ ESTA LINEA ------------>
                //crud.menuCRUD(conect);
            }
        } catch (IllegalThreadStateException e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion: " + e);

        } catch (SQLSyntaxErrorException e) {
            if (e.toString().indexOf("Unknow database") == -1) {
                System.out.println(yellow + "ADVERTENCIA: " + reset + "No se encontró una base de datos. Creando una nueva...\n\n");
                this.crearBD();
            } else {
                System.out.println(e);
            }
        } catch (Exception e) {
            System.out.println(yellow + "[Advertencia] " + reset + "No se pudo establecer la conexion al servidor de la BD de MySQL " + e);
            this.errorSQL=true;
            
        } finally {
			return conect;
			
		}
        
    }

    Scanner entrada = null;
	
    public Connection crearBD() {
        limpiarConsola();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conect = DriverManager.getConnection("jdbc:mysql://localhost:" + puertoMySQL + "/", user, password);
            if (conect != null) {

                Statement s = conect.createStatement();
                System.out.println(green + "[Conexion establecida con el Servidor para la creación]" + reset);

                File f = new File(rutaScriptLocal);
                entrada = new Scanner(f);
				linea=entrada.nextLine();
                while (!linea.equals("--<FIN>")) {
					if(!linea.equals("")){
						s.execute(linea);
					}
					linea=entrada.nextLine();
					
                }
				System.out.println(green+"[Exito] "+cyan+"Base de datos creada correctamente."+reset+"\n");
                
            }
        } catch (IllegalThreadStateException e) {
            System.out.println(red + "[Error] " + reset + "Se ha provocado una excepcion: " + e);

        } catch (Exception e) {
            System.out.println(yellow + "[Advertencia] " + reset + "No se pudo establecer la conexion al servidor de la BD de MySQL " + e);
            this.errorSQL=true;
        }
        return conect;
    }

    public void cargarRutas() {
        try {
            cr.cargarRutas();
            this.puertoMySQL = cr.getPuertoMySQL();
            this.nombreBD = cr.getNombreBD();
            this.user = cr.getUser();
            this.password = cr.getPassword();
            this.rutaScriptLocal = cr.getRutaScriptLocal();
			
        } catch (Exception e) {
            System.out.println(red + "[Error] " + reset + "Problema al cargar rutas: " + e);
        }
    }

    public boolean getErrorSQL() {
        return this.errorSQL;
    }

    //Extras
    public void limpiarConsola() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception e) {
        }

    }

    public void esperar() {
        try {
            Thread.sleep(5 * 1000);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}